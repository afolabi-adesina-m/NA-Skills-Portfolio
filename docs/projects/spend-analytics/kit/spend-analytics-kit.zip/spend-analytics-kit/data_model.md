# Data model

A star schema: one fact table of contracts in the middle, lookup (dimension) tables around it, plus one small "snowflake" table for category segments. Every relationship is **many-to-one (*:1)** with **single** cross-filter direction (the lookup filters the fact, never the other way round).

## Grain

**FactContracts = one row per contract** (department + procurement ID) for original awards dated **1 April 2023 to 31 March 2026**, which is fiscal years **FY'24, FY'25 and FY'26** (the Government of Canada fiscal year runs April to March, and FY'24 means April 2023 to March 2024).

The source publishes a new row every time a contract is amended, and each amendment row carries the *amended total*. Adding those rows would double count, so they were rolled up:
- `OriginalValue` = value on the original award record
- `ContractValue` = latest reported total (original plus all amendments published up to the download date)
- `AmendmentValue` = ContractValue minus OriginalValue
- `AmendmentCount` = number of amendment records

Values include taxes, as reported. Standing offer and supply arrangement agreements (reported at $0 by rule) are excluded; call-ups against them are included and flagged with `IsCallUpAgainstStandingOffer`.

## Diagram

```mermaid
erDiagram
    DimDate ||--o{ FactContracts : "DateKey"
    DimVendor ||--o{ FactContracts : "VendorKey"
    DimDepartment ||--o{ FactContracts : "DeptKey"
    DimCategory ||--o{ FactContracts : "CategoryKey"
    DimCategorySegment ||--o{ DimCategory : "CategoryGroupKey"
    DimProcurementMethod ||--o{ FactContracts : "MethodKey"
    DimCommodityType ||--o{ FactContracts : "CommodityTypeCode"
    DimVendor ||--o{ VendorNameMap : "VendorKey"
```

Plain text ("1 ----<" means one-to-many, the arrow end is the many side):

```
DimDate              1 ----< FactContracts   (DateKey)
DimVendor            1 ----< FactContracts   (VendorKey)
DimDepartment        1 ----< FactContracts   (DeptKey)
DimCategory          1 ----< FactContracts   (CategoryKey)
DimCategorySegment   1 ----< DimCategory     (CategoryGroupKey)
DimProcurementMethod 1 ----< FactContracts   (MethodKey)
DimCommodityType     1 ----< FactContracts   (CommodityTypeCode)
DimVendor            1 ----< VendorNameMap   (VendorKey)

Standalone, no relationships:
  dq_vendor_duplicates, dq_rule_summary, dq_vendor_count_stages, segment_rules
```

## Relationships to create (Model view)

| From (many side) | To (one side) | Cardinality | Cross filter |
|---|---|---|---|
| FactContracts[DateKey] | DimDate[DateKey] | Many to one | Single |
| FactContracts[VendorKey] | DimVendor[VendorKey] | Many to one | Single |
| FactContracts[DeptKey] | DimDepartment[DeptKey] | Many to one | Single |
| FactContracts[CategoryKey] | DimCategory[CategoryKey] | Many to one | Single |
| DimCategory[CategoryGroupKey] | DimCategorySegment[CategoryGroupKey] | Many to one | Single |
| FactContracts[MethodKey] | DimProcurementMethod[MethodKey] | Many to one | Single |
| FactContracts[CommodityTypeCode] | DimCommodityType[CommodityTypeCode] | Many to one | Single |
| VendorNameMap[VendorKey] | DimVendor[VendorKey] | Many to one | Single |

Filters flow DimCategorySegment > DimCategory > FactContracts, so a Kraljic segment or tier slicer filters contracts correctly.

Keep `dq_vendor_duplicates`, `dq_rule_summary`, `dq_vendor_count_stages` and `segment_rules` **unrelated**. If Power BI auto-creates a relationship from `dq_vendor_duplicates[VendorKey]` to `DimVendor`, delete it.

All keys were checked in Python: every foreign key has a match (0 orphans, 0 blanks) and every dimension key is unique.

## Tables and columns

### FactContracts (179,829 rows)
| Column | Type | Meaning |
|---|---|---|
| ContractKey | Whole number | Surrogate key |
| ProcurementId | **Text** | Department's procurement/contract number |
| DateKey | Whole number | Original contract date as yyyymmdd |
| VendorKey | Whole number | Joins to DimVendor |
| DeptKey | Whole number | Joins to DimDepartment |
| CategoryKey | Whole number | Joins to DimCategory (economic object code) |
| MethodKey | Whole number | Joins to DimProcurementMethod |
| CommodityTypeCode | Text | G / S / C / U |
| OriginalValue, ContractValue, AmendmentValue | Fixed decimal | C$ incl. taxes |
| AmendmentCount | Whole number | Amendment records |
| IsAmended | 0/1 | Amended or value changed |
| NumberOfBids | Whole number | Blank when not reported |
| IsCallUpAgainstStandingOffer | 0/1 | Call-up against a standing offer or supply arrangement |
| DisclosureRecordCount | Whole number | Source rows for this contract |
| VendorSpellingsOnContract | Whole number | Distinct vendor spellings across this contract's records |
| LimitedTenderingReason | Text | Reason for limited tendering, blank if none |

### DimDate (1,096 rows, 1 Apr 2023 to 31 Mar 2026)
| Column | Example | Notes |
|---|---|---|
| Date | 2023-04-01 | Mark as date table on this column |
| DateKey | 20230401 | Relationship key |
| Year, CalendarQuarter, MonthNumber, MonthName | 2023, Q2, 4, Apr | Calendar hierarchy Year > CalendarQuarter > MonthName (sort MonthName by MonthNumber) |
| MonthStart | 2023-04-01 | First day of month, best for monthly line charts |
| MonthLabel, MonthIndex | Apr '23, 1 | Ready-made "Mmm 'YY" text label; sort it by MonthIndex |
| YearMonth | 2023-04 | |
| FiscalYear | FY2023-24 | Long label, kept for reference |
| **FiscalYearShort** | **FY'24** | Use this one in visuals and slicers |
| FiscalYearStart | 2023 | |
| FiscalQuarter, FiscalQuarterLabel | Q1, FY'24 Q1 | April to June = Q1 |
| FiscalMonthNumber, FiscalMonthName | 1, Apr | April = 1; sort FiscalMonthName by FiscalMonthNumber for a fiscal hierarchy |
| DayOfWeek | Sat | |

### DimVendor (40,297 rows, one per normalized vendor name)
VendorKey, VendorName (most common spelling), NormalizedName, MasterVendorName (suggested golden record), FuzzyClusterId, FuzzyClusterSize, SimilarityToMaster, RawVariantCount, IsPotentialDuplicate, HasMultipleSpellings, HasCountryConflict, HasMissingPostal, PostalFSAValid, DQIssueCount, CountryCode, CountryName, PostalFSA, Province, ProvinceName, and the government-wide Pareto columns:
- **VendorParetoRank**: rank of the master vendor by spend (1 = largest; blank if no contracts)
- **VendorCumulativeSpendPct**: cumulative share of spend down to this master vendor
- **VendorParetoClass**: A / B / C, or "No contracts" for names that only appear on amendments

### DimCategory (400 rows, one per economic object code)
| Column | Meaning |
|---|---|
| CategoryKey | Key |
| EconomicObjectCode | Code as published (some lack the leading zero) |
| ObjectName | Official object name from the Government-wide Chart of Accounts 2025-26 (falls back to the most common description of work) |
| CategoryDescription | Most common "description of work" for the code in the contracts data |
| InChartOfAccounts | 1 if the code (padded to 4 digits) exists in the Chart of Accounts 2025-26 |
| CategoryGroupKey | Joins to DimCategorySegment |

### DimCategorySegment (one row per category group)
The readable category level and its segmentation. Category groups are the "report objects" of the Government-wide Chart of Accounts (for example "Informatics services", "Acquisition of aircraft and ships, including parts"). Codes not found in the chart sit in "Unmapped object code".

| Column | Meaning |
|---|---|
| CategoryGroupKey, CategoryGroup | Key and name |
| StandardObject | Higher level, for example "SO 04 Professional and special services" |
| CategorySpend, ContractCount | Totals for FY'24 to FY'26 |
| ActiveSuppliers | Distinct master vendors in the group |
| SupplierHHI | Supplier concentration inside the group (0 to 10,000) |
| NonCompetitiveSpendShare | Share of group spend awarded non-competitively |
| SingleBidShare | Share of competitive contracts (with 1+ bids reported) that got exactly one bid |
| CompetitiveContractsWithBids | Denominator for SingleBidShare |
| SupplierScarcity | min(1, 10 / ActiveSuppliers) |
| SupplyRiskScore | 0 to 100, see method below |
| SpendLevel, RiskLevel | High / Low |
| KraljicSegment | Strategic, Leverage, Bottleneck, Routine |
| ProcurementTier | Strategic, Tactical, Operational |
| SegmentSort | 1 to 4, for ordering |
| LowDataConfidence | 1 if fewer than 30 contracts |
| CategoryParetoRank, CategoryCumulativeSpendPct, CategoryParetoClass | Government-wide category Pareto |

### segment_rules (4 rows)
The rule behind each segment, in words: SegmentSort, KraljicSegment, ProcurementTier, SpendLevel, RiskLevel, Rule, TypicalApproach.

### DimDepartment (94), DimProcurementMethod (6), DimCommodityType (4)
DeptKey, OrgCode, DepartmentName, DepartmentNameFR / MethodKey, MethodCode, ProcurementMethod, CompetitionType, IsCompetitive / CommodityTypeCode, CommodityType.

### VendorNameMap (53,265 rows)
RawVendorName, VendorKey, RecordCount. Cross-reference from every raw spelling to the cleaned vendor (NormalizedName is available through DimVendor).

### dq_vendor_duplicates, dq_rule_summary (21 rules), dq_vendor_count_stages
Pre-computed data-quality results for the report page.

## Category segmentation method (analyst-defined assumptions)

This is a Kraljic-style matrix adapted to what the data contains. **The thresholds are my assumptions, chosen to be simple and explainable, not an official government classification.**

1. **Unit**: the 85 category groups (report objects of the Chart of Accounts), measured over FY'24 to FY'26.
2. **Spend axis (profit impact proxy)**: a group is **High spend** if it is in **Pareto class A**, meaning it belongs to the groups that together make up the first 80% of spend (10 groups). Everything else is Low spend.
3. **Supply risk axis**: the data has no market or supplier risk ratings, so four proxies are averaged into a **Supply Risk Score** (0 to 100):
   - supplier concentration: SupplierHHI / 10,000
   - non-competitive spend share
   - single-bid share of competitive contracts
   - supplier scarcity: min(1, 10 / number of active suppliers)
   Each proxy is between 0 and 1; the score is their average times 100 (a proxy is skipped if it cannot be computed, for example no competitive contracts with bids).
4. **High risk** = Supply Risk Score **25 or more**. 25 is close to the median score (24.0) of category groups with at least 30 contracts.
5. **Quadrants**: Strategic (high spend, high risk), Leverage (high spend, low risk), Bottleneck (low spend, high risk), Routine (low spend, low risk).
6. **Tiers requested for the report**:
   - **Strategic tier** = Strategic quadrant. Big money and real supply risk: manage with long-term relationships and risk plans.
   - **Tactical tier** = Leverage + Bottleneck. Leverage categories need sharp sourcing (tenders, consolidation, negotiation). Bottleneck categories need supply security (alternative suppliers, standing offers). Both need active, tactical category management but not executive-level partnership.
   - **Operational tier** = Routine. Low value, low risk: simplify and automate (catalogues, call-ups, purchasing cards).
7. **Caveats**: groups with fewer than 30 contracts get noisy scores (flagged `LowDataConfidence`; all 22 such groups land in Bottleneck). Averaging can hide a single strong signal; for example "Repair and maintenance - Buildings" has a supplier HHI of about 4,428 (one supplier holds 66% of its spend) but stays in Leverage because almost all of it was competed.

## Pareto (ABC) method

Items are sorted by spend, largest first. The cumulative share is the running total divided by total spend. An item is classed by the cumulative share *before* it: **A** if under 80%, **B** if under 95%, otherwise **C**. Vendors are grouped by MasterVendorName (so duplicate spellings count once); categories by CategoryGroup.

## Power Query steps

None are required. In Power Query only confirm types:
1. `FactContracts[ProcurementId]` = Text.
2. Value columns = Fixed decimal number.
3. `DimDate[Date]` and `DimDate[MonthStart]` = Date.
4. Key columns = Whole number, except `CommodityTypeCode` = Text.
5. `DimVendor[PostalFSA]`, `[CountryCode]` = Text (Namibia's code is "NA").
6. `DimVendor[VendorCumulativeSpendPct]`, `DimCategorySegment` share columns = Decimal number.

## How the vendor cleansing works

1. **Trim and case-fold**: remove extra spaces, compare in upper case.
2. **Normalize**: strip accents (Limitée to LIMITEE), "&" to AND, remove punctuation, drop trailing legal suffixes (INC, INCORPORATED, LTD, LIMITED, LIMITEE, LTEE, CORP, CORPORATION, CO, COMPANY, LLC, LLP, LP, ULC, PLC, GMBH, SA, AG, BV and similar), drop a leading THE, keep the first half of "English / French" names.
3. **Fuzzy match**: compare normalized names sharing the first 3 characters with RapidFuzz token-sort ratio. Link a pair when the score is 92 or more, any numbers match exactly, and the differing words look like typos of each other.
4. **Cluster**: linked pairs are grouped; the vendor with the most spend becomes the suggested master.

Clusters are suggestions for review. Spot checks show most are genuine (typos, truncation, suffix variants), with some false positives (different harbour authorities with similar names). English/French pairs such as "Canadian Corps of Commissionaires" and "Corps canadien des commissionnaires" are not caught.

## Tableau version

`tableau/` holds flat, pre-joined extracts built from these same tables (see TABLEAU_GUIDE.md). Totals match: the contracts extract sums to the same C$92.6B and 179,829 contracts.
