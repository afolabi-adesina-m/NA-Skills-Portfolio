# Build guide: Canadian Federal Procurement and Supplier Master Data Quality (Power BI)

This guide takes you from an empty Power BI Desktop to a finished six-page report. Every step is small. If a button on your screen looks a little different, that is usually just a newer Power BI version; the names stay the same.

Plan on 4 to 5 hours for the first build. Save often (Ctrl + S).

Open `mockups/00_all_pages.png` first: it shows all six finished pages. Each page section below links its full-size mockup (`mockups/01` to `06`) and gives the exact position and size of every card and visual, so your report can match the picture. Single-chart previews are in `preview/`.

Fiscal years use short labels everywhere: **FY'24** = April 2023 to March 2024, **FY'25** = April 2024 to March 2025, **FY'26** = April 2025 to March 2026.

The six pages:
1. Spend Overview
2. Spend by Category
3. Vendor and Competition
4. Category Segmentation (Strategic / Tactical / Operational)
5. Pareto 80/20
6. Supplier Master Data Quality

---

## Part 0. Get set up (15 minutes)

1. Install **Power BI Desktop** from the Microsoft Store (search "Power BI Desktop", click **Get**). It is free.
2. Unzip `powerbi-kit.zip` to a simple folder, for example `C:\PowerBI\powerbi-kit\` (avoid OneDrive-synced folders).
3. Open Power BI Desktop. You can close any sign-in box; you do not need an account to build and save.
4. Turn off automatic relationships and auto dates:
   - **File** > **Options and settings** > **Options**.
   - Under **CURRENT FILE** click **Data Load**.
   - Untick **Autodetect new relationships after data is loaded**.
   - Untick **Auto date/time** (under Time intelligence).
   - Click **OK**.

---

## Part 1. Load the data (20 minutes)

You will load 13 CSV files from the `data` folder. Skip `raw_sample.csv` (it only shows what the original government file looks like).

For **each** file:
1. **Home** > **Get data** > **Text/CSV**.
2. Pick the file > **Open**.
3. In the preview check **File Origin** = **65001: Unicode (UTF-8)** and **Delimiter** = **Comma**.
4. Click **Load**.

Files, in this order:
1. `FactContracts.csv`
2. `DimVendor.csv`
3. `DimDepartment.csv`
4. `DimDate.csv`
5. `DimCategory.csv`
6. `DimCategorySegment.csv`
7. `DimProcurementMethod.csv`
8. `DimCommodityType.csv`
9. `VendorNameMap.csv`
10. `dq_vendor_duplicates.csv`
11. `dq_rule_summary.csv`
12. `dq_vendor_count_stages.csv`
13. `segment_rules.csv`

### Check data types
Click the **Table view** icon on the far left (small grid).
1. **FactContracts**: click **ProcurementId** > **Column tools** > **Data type** = **Text**. Set **ContractValue**, **OriginalValue**, **AmendmentValue** to **Fixed decimal number**, Format **Currency**.
2. **DimDate**: **Date** and **MonthStart** must be **Date**.
3. **DimVendor**: **PostalFSA** and **CountryCode** = **Text**. **VendorCumulativeSpendPct** = **Decimal number**, Format **Percentage**.
4. **DimCategorySegment**: **CategorySpend** = Currency; **NonCompetitiveSpendShare**, **SingleBidShare**, **CategoryCumulativeSpendPct** = Percentage.

### Stop ID columns from being added up
For each column below: click it > **Column tools** > **Summarization** > **Don't summarize**.
- Every column ending in **Key**, in every table
- DimDate: **Year**, **MonthNumber**, **MonthIndex**, **FiscalYearStart**, **FiscalMonthNumber**
- DimVendor: **FuzzyClusterId**, **FuzzyClusterSize**, **SimilarityToMaster**, **VendorParetoRank**, **VendorCumulativeSpendPct**
- DimCategorySegment: every numeric column (it is a lookup table, so sums would be misleading)
- dq_vendor_duplicates: **FuzzyClusterId**, **VendorKey**, **SimilarityToMaster**
- dq_vendor_count_stages: **StageOrder**; segment_rules: **SegmentSort**

### Sort text columns in the right order
Text sorts alphabetically unless you tell it otherwise. For each pair: click the first column > **Column tools** > **Sort by column** > pick the second.

| Table | Column | Sort by column |
|---|---|---|
| DimDate | MonthName | MonthNumber |
| DimDate | FiscalMonthName | FiscalMonthNumber |
| DimDate | MonthLabel | MonthIndex |
| dq_vendor_count_stages | Stage | StageOrder |
| DimCategorySegment | KraljicSegment | SegmentSort |

(FiscalYearShort sorts correctly on its own: FY'24, FY'25, FY'26.)

### Build a date hierarchy (Year > Quarter > Month)
1. In the **Data** pane, open **DimDate**.
2. Right-click **Year** > **Create hierarchy**. A new "Year Hierarchy" appears.
3. Right-click **CalendarQuarter** > **Add to hierarchy** > **Year Hierarchy**.
4. Right-click **MonthName** > **Add to hierarchy** > **Year Hierarchy**.
5. Right-click the hierarchy > **Rename** > `Calendar Y-Q-M`.

Optional fiscal version: right-click **FiscalYearShort** > **Create hierarchy**, add **FiscalQuarter**, then **FiscalMonthName**. Rename it `Fiscal Y-Q-M`. Because FiscalMonthName is sorted by FiscalMonthNumber, each fiscal year runs Apr to Mar.

On a chart axis, a hierarchy gives you drill buttons (the down arrows at the top of the visual) so you can go from years to quarters to months.

### Format months as Mmm 'YY
For a short, readable axis like **Apr '23**:
1. Click **DimDate > MonthStart**.
2. **Column tools** > **Format** > click into the box and type: `mmm 'yy`
3. Press Enter. In charts where the X-axis **Type** is set to **Categorical** (Format visual > X-axis > Type), labels read Apr '23, May '23 and so on.

If the apostrophe looks odd in your version, use `mmm yy`, or simply put the ready-made **MonthLabel** column on the axis (it already reads Apr '23 and sorts correctly because of the Sort by column step).

---

## Part 2. Build the model (15 minutes)

1. Click **Model view** (three connected boxes, far left).
2. Arrange: **FactContracts** in the middle, Dim tables around it, **DimCategorySegment** next to **DimCategory**, the `dq_` tables and `segment_rules` off to one side.
3. Create each relationship by **dragging the first column onto the second**:

| Drag this | Drop onto this |
|---|---|
| FactContracts > DateKey | DimDate > DateKey |
| FactContracts > VendorKey | DimVendor > VendorKey |
| FactContracts > DeptKey | DimDepartment > DeptKey |
| FactContracts > CategoryKey | DimCategory > CategoryKey |
| DimCategory > CategoryGroupKey | DimCategorySegment > CategoryGroupKey |
| FactContracts > MethodKey | DimProcurementMethod > MethodKey |
| FactContracts > CommodityTypeCode | DimCommodityType > CommodityTypeCode |
| VendorNameMap > VendorKey | DimVendor > VendorKey |

4. In each **New relationship** window check **Many to one (\*:1)**, **Single**, **active**, then **Save**.
5. The `dq_` tables and `segment_rules` have no lines. Delete any extra line Power BI added (right-click > **Delete**).

### Mark the date table
Click **DimDate** > **Table tools** > **Mark as date table** > pick **Date** > **Save**.

### Hide technical columns
Right-click > **Hide in report view**: all **Key** columns in FactContracts, **DimDate > DateKey**, **DimCategory > CategoryGroupKey**.

---

## Part 3. Create the measures (25 minutes)

1. **Report view** (top icon on the left).
2. **Home** > **Enter data** > name it `_Measures` > **Load**.
3. Open `dax_measures.md`. For each measure: right-click **_Measures** > **New measure** > paste the whole block > **Enter**. Then set the format in **Measure tools**.
4. Delete **Column1** from `_Measures` once your first measure exists.

Quick test: a **Card** with **Total Spend** should show about **$92.56bn**. Every measure in `dax_measures.md` has an expected value to check against.

---

## Part 4. Theme, canvas and the shared page frame (15 minutes)

Every page uses the same frame, so build it once on page 1 and copy it. The pictures in `mockups/` show exactly what each finished page looks like; open `mockups/00_all_pages.png` to see all six at once.

All positions below are in Power BI's own units on the default 16:9 canvas (1280 wide x 720 tall). To place anything exactly: select it > **Format** pane > **General** > **Properties** > **Size** (Height, Width) and **Position** (Horizontal = X, Vertical = Y). Type the numbers from the tables.

1. **View** > **Themes** dropdown > **Browse for themes** > pick `powerbi-theme.json`.
2. Canvas: click an empty spot > **Format page** (paint roller) > **Canvas settings** > Type **16:9** (1280 x 720). **Canvas background** > colour `#F2F4F7`, transparency **0%**.
3. Build the frame:

| Element | How to make it | X | Y | Width | Height |
|---|---|---|---|---|---|
| Header band | **Insert** > **Shapes** > **Rectangle**, fill navy `#1F3A5F`, no border | 0 | 0 | 1280 | 44 |
| Report title | **Insert** > **Text box**: `Government of Canada Contract Spend \| FY'24 to FY'26`, white, bold, size 16, no background | 8 | 4 | 700 | 36 |
| Page tabs | **Insert** > **Buttons** > **Navigator** > **Page navigator**. Format > Style: Default fill `#DCE6F1` with navy text; State **Selected**: fill `#3E6A9E`, white bold text | 0 | 44 | 1280 | 26 |
| Fiscal Year slicer | DimDate > **FiscalYearShort**, Slicer settings > Style **Tile** | 16 | 78 | 250 | 40 |
| Department slicer | DimDepartment > **DepartmentName**, Style **Dropdown** | 278 | 78 | 330 | 40 |
| Commodity type slicer | DimCommodityType > **CommodityType**, Style **Dropdown** | 620 | 78 | 250 | 40 |
| KPI card row | One card per KPI, sizes in each page section | 16 | 126 | see page | 70 |
| Visual area | Visuals in a grid, positions in each page section | 16 | 206 | 1248 | 488 |
| Source footer | Text box, size 8, grey: `Source: Government of Canada, Proactive Publication - Contracts (open.canada.ca), Open Government Licence - Canada. Downloaded 6 Oct 2026. Contracts over $10K awarded Apr 2023 to Mar 2026; values include amendments and taxes.` | 8 | 698 | 1264 | 22 |

4. Slicers: if the tiles feel cramped at 40 high, turn **Slicer header** off and set the visual **Title** to the slicer name instead. Then **View** > **Sync slicers** and tick every page, so one choice filters the whole report.
5. White "tile" look for every card and visual (this is what makes the mockups look like a dashboard): select the visual > **Format** > **General** > **Effects** > **Background** white, **Visual border** on, colour `#D9DFE7`, **Rounded corners** 4. Title on, size 11, bold, navy `#1F3A5F`.
6. KPI cards: use the **Card (new)** visual. Callout value bold navy (size 20 on pages with 5 or 6 cards, 18 on page 1 with 9 cards); label size 9 grey; turn on **Accent bar** (left, navy, width 4) if your version has it, otherwise put a 4-wide navy rectangle on the card's left edge. The small grey line under each value is a **Reference label** (Format > Reference labels > Add > pick the measure). Rename a field for the card by double-clicking it in the field well, so titles match the mockups.
7. Select everything in the frame (header, title, navigator, slicers, footer) > Ctrl + C. On each new page, Ctrl + V; Power BI pastes in the same position.

Tip for every visual: click an empty spot on the canvas first, then a visual icon in **Visualizations**, then drag fields from **Data** into the wells.

---

## Part 5. Page 1: Spend Overview

Mockup: `mockups/01_spend_overview.png`

![Spend Overview](mockups/01_spend_overview.png)

Rename the page `Spend Overview`.

### KPI cards (9 cards, each 128 wide x 70 high, 12 apart)

| Card title | Measure | Reference label (small grey line) | X | Expected |
|---|---|---|---|---|
| Total Spend | Total Spend | text: Apr 2023 to Mar 2026 (a text box) | 16 | C$92.6B |
| Contracts | Contract Count | | 156 | 179,829 |
| Active Suppliers | Active Suppliers | | 296 | 38,370 |
| Avg Contract Value | Avg Contract Value | Median Contract Value | 436 | C$514.7K (median C$25.9K) |
| Goods Spend | Goods Spend | Goods Share % | 576 | C$19.9B (21.5%) |
| Services Spend | Services Spend | Services Share % | 716 | C$60.7B (65.6%) |
| Construction Spend | Construction Spend | Construction Share % | 856 | C$12.0B (13.0%) |
| Spend YoY, FY'26 | Spend YoY % Latest FY | text: vs FY'25 (C$48.3B) | 996 | -66.9% |
| Non-Competitive | Non-Competitive Spend % | Non-Competitive Contract % | 1136 | 18.9% (38.1% of contracts) |

All cards: Y 126, Width 128, Height 70. Display units for money cards: **Billions**, 1 decimal (Avg Contract Value: **Thousands**, 1 decimal).

The three split cards (Goods, Services, Construction) sit right after the totals so a reader sees the total and where it goes in one glance.

### Visuals (2 x 2 grid)

| Visual | Type | X | Y | Width | Height |
|---|---|---|---|---|---|
| Monthly Spend, FY'24 to FY'26 | Line chart | 16 | 206 | 816 | 240 |
| Spend by Fiscal Year | Clustered column chart | 844 | 206 | 420 | 240 |
| Top 10 Departments by Spend | Clustered bar chart | 16 | 454 | 816 | 240 |
| Spend by Commodity Type | Donut chart | 844 | 454 | 420 | 240 |

**Monthly Spend (line chart)**
1. **X-axis**: DimDate > **MonthStart**. In the well, click the arrow on MonthStart and pick **MonthStart** (not Date Hierarchy). **Y-axis**: **Total Spend**.
2. Pick one of two ways to get the fiscal-year bands and Mmm 'YY labels shown in the mockup:
   - **Way A (shaded bands, as in the mockup)**: Format visual > **X-axis** > **Type**: **Continuous**. Then **Analytics** pane > **X-Axis Constant Line** > Add > Value **1 April 2024**, **Shade area**: **Before**, colour `#EAF1F8`, transparency 0. Add a second constant line at **1 April 2025**, **Shade area**: **After**. FY'24 and FY'26 are now shaded and FY'25 is white. Add three small text boxes `FY'24`, `FY'25`, `FY'26` (size 9, bold, `#3E6A9E`) at the top of each band. On a continuous axis Power BI may choose its own date labels (for example "Jul 2023") instead of `mmm 'yy`; that is normal.
   - **Way B (exact Apr '23 labels)**: put **MonthLabel** on the X-axis instead (it reads Apr '23 and sorts by MonthIndex), keep **Type**: **Categorical**, and drag **FiscalYearShort** into **Legend** so each fiscal year's line gets its own colour. Constant lines are not available on a categorical axis, so the colours do the job of the bands.
3. Either way, the title stays `Monthly Spend, FY'24 to FY'26`.
4. Markers on (Format > Markers), line colour navy.
5. The three spikes (Mar '25 C$21.2B, May '24 C$12.5B, Dec '23 C$7.9B) each come from one big award. Label them with three small text boxes (white background, light blue border), as in the mockup. Tooltip: add **Contract Count**.
6. Try the hierarchy: replace MonthStart with **Calendar Y-Q-M** and use the drill arrows. Switch back to MonthStart for the finished page.
7. Optional: duplicate the page and add a visual-level filter **FactContracts > ContractValue** is less than 1000000000 to show the monthly pattern without the 10 mega-contracts.

**Spend by Fiscal Year (clustered column)**
1. **X-axis**: **FiscalYearShort**. **Y-axis**: **Total Spend**. Data labels on (Billions, 1 decimal).
2. Colours (Format > Columns > Colors, **Show all**): FY'24 `#9DB9D8`, FY'25 `#1F3A5F`, FY'26 `#3E6A9E`.
3. Year-over-year inside the bars: Format > **Data labels** > **Detail** > add **Spend YoY %** (shows +70.5% on FY'25 and -66.9% on FY'26; FY'24 has no prior year). If your version has no Detail option, put Spend YoY % in **Tooltips**.
4. Add **Contract Count** to Tooltips (59,475, 58,030 and 62,324 contracts).

**Top 10 Departments by Spend (clustered bar)**
1. **Y-axis**: **DepartmentName**. **X-axis**: **Total Spend**.
2. Filters pane > DepartmentName > **Top N** > Top **10** by **Total Spend** > Apply.
3. Data labels on. Bars `#3E6A9E`, with National Defence (C$49.8B, 53.8%) in navy (Format > Bars > Colors > Show all).
4. Tooltips: **Contract Count**, **Median Contract Value**, **Non-Competitive Spend %**.

**Spend by Commodity Type (donut)**
1. **Legend**: **CommodityType**. **Values**: **Total Spend**.
2. Colours: Services navy `#1F3A5F`, Goods `#3E6A9E`, Construction amber `#E3A33B`. Legend on the right; Detail labels: **Category, percent of total**.
3. Centre label: a small **Card (new)** with **Total Spend**, no background and no border, placed over the donut hole (about X 920, Y 545, Width 130, Height 50).

---

## Part 6. Page 2: Spend by Category

Mockup: `mockups/02_spend_by_category.png`

![Spend by Category](mockups/02_spend_by_category.png)

New page (**+** at the bottom), name it `Spend by Category`, paste the frame.

### KPI cards (5 cards, each 240 wide x 70 high, 12 apart, Y 126)

| Card title | Measure | Reference label | X | Expected |
|---|---|---|---|---|
| Total Spend | Total Spend | Contract Count | 16 | C$92.6B |
| Category Groups | Category Count | text: 26 standard objects | 268 | 85 |
| Top Category Share | Top Category Share | text: Aircraft and ships, C$30.1B | 520 | 32.6% |
| Top 15 Categories Share | Top 15 Category Share | | 772 | 89.3% |
| Groups Making 80% of Spend | Class A Categories | | 1024 | 10 |

### Visuals

| Visual | Type | X | Y | Width | Height |
|---|---|---|---|---|---|
| Spend by Category Group (top 15) | Clustered bar chart, full width | 16 | 206 | 1248 | 268 |
| Treemap: Standard Object > Category Group | Treemap, full width | 16 | 482 | 1248 | 212 |

**Spend by Category Group (full-width bar)**
1. **Clustered bar chart**. **Y-axis**: DimCategorySegment > **CategoryGroup**. **X-axis**: **Total Spend**.
2. Filters pane > CategoryGroup > **Top N** = **15** by **Total Spend**.
3. Bars navy, data labels on. Data labels > **Detail**: **% of Total Spend** (or put it in Tooltips). Tooltips: **Contract Count**, **Median Contract Value**.
4. Optional page filter: drag **DimCategorySegment > CategoryGroup** to **Filters on this page** and untick **Unmapped object code** (0.2% of spend whose codes are not in the Chart of Accounts). The mockup numbers include it.

**Treemap**
1. **Treemap**. **Category**: **StandardObject**. **Details**: **CategoryGroup**. **Values**: **Total Spend**.
2. Colours by standard object: Machinery and equipment navy, Professional and special services `#3E6A9E`, Repair and maintenance `#5B8C85`, Rentals `#E3A33B`, everything else grey.
3. Data labels on. Small tiles hide their labels automatically; the tooltip shows the name and spend.

### Optional extras (not in the mockup; add to a separate details page if you like)
- **Matrix**: rows StandardObject > CategoryGroup > ObjectName, values Total Spend, % of Total Spend, Contract Count, Non-Competitive Spend %. Turn on Format > Row headers > **+/- icons** to expand.
- **Stacked bar**: CategoryGroup (Top N 10) by Total Spend with CommodityType as the legend.

---

## Part 7. Page 3: Vendor and Competition

Mockup: `mockups/03_vendor_competition.png`

![Vendor and Competition](mockups/03_vendor_competition.png)

New page `Vendor and Competition`, paste the frame.

### KPI cards (6 cards, each 198 wide x 70 high, 12 apart, Y 126)

| Card title | Measure | Reference label | X | Expected |
|---|---|---|---|---|
| Top 10 Supplier Share | Top 10 Vendor Share | | 16 | 49.2% |
| Supplier HHI | Vendor HHI | | 226 | 387 |
| Non-Competitive Spend | Non-Competitive Spend % | Non-Competitive Contract % | 436 | 18.9% (38.1% of contracts) |
| Single-Bid Rate | Single-Bid Rate (Competitive) | | 646 | 44.9% |
| Amendment Rate | Amendment Rate | | 856 | 11.6% |
| Amendment Value Growth | Amendment Value Growth % | | 1066 | 11.1% |

### Visuals

| Visual | Type | X | Y | Width | Height |
|---|---|---|---|---|---|
| Top 10 Suppliers by Spend | Clustered bar chart | 16 | 206 | 616 | 488 |
| Spend by Procurement Method | Clustered bar chart | 644 | 206 | 620 | 240 |
| Competitive vs Non-Competitive Spend by Year | 100% stacked column chart | 644 | 454 | 620 | 240 |

**Top 10 Suppliers**: Y-axis **MasterVendorName**, X-axis **Total Spend**, Top N 10 by Total Spend. Data labels on; detail **% of Total Spend**. Tooltips **Contract Count**, **Amendment Rate**. SkyAlyne (C$11.2B, 12.1%) in navy, others `#3E6A9E`.

**Spend by Procurement Method**: Y-axis **ProcurementMethod**, X-axis **Total Spend**, tooltips **Contract Count**, **Median Contract Value**. Colours: the three competitive methods navy, Non-Competitive and Advance Contract Award Notice amber `#E3A33B`.

**Competitive vs Non-Competitive by Year**: **100% stacked column**. X-axis **FiscalYearShort**, Y-axis **Total Spend**, Legend **CompetitionType**. Data labels on (they show the share). Colours: Competitive navy, Non-competitive amber, Non-competitive (ACAN) light amber `#F0C987`. Expected competitive share of spend: FY'24 78.7%, FY'25 86.8%, FY'26 68.0%.

### Optional extras (not in the mockup)
- **Matrix**: rows **DepartmentName**; values Contract Count, Total Spend, Non-Competitive Contract %, Single-Bid Rate (Competitive), Vendor HHI, with background colour on Non-Competitive Contract %.
- **Azure Maps** with DimVendor > **ProvinceName** in Location and Total Spend in Size (if disabled: File > Options and settings > Options > GLOBAL > Security). Maps may not appear in some exports, so a ProvinceName x CommodityType matrix is a good backup.
- **Table**: **LimitedTenderingReason**, Contract Count, Total Spend, filtered to LimitedTenderingReason **is not blank**.

---

## Part 8. Page 4: Category Segmentation (Strategic / Tactical / Operational)

Mockup: `mockups/04_category_segmentation.png`

![Category Segmentation](mockups/04_category_segmentation.png)

New page `Category Segmentation`, paste the frame.

### KPI cards (5 cards, each 240 wide x 70 high, 12 apart, Y 126)

| Card title | Measure | Reference label | X | Expected |
|---|---|---|---|---|
| Strategic Tier | Strategic Tier Spend % | text: 4 groups, C$25.8B | 16 | 27.8% |
| Tactical Tier | Tactical Tier Spend % | text: 54 groups (Leverage 6 + Bottleneck 48) | 268 | 63.2% |
| Operational Tier | Operational Tier Spend % | text: 27 groups, C$8.3B | 520 | 8.9% |
| High-Risk Threshold | Risk Threshold | text: Supply Risk Score; analyst-defined | 772 | 25 |
| Low-Confidence Groups | Low-Confidence Groups | text: fewer than 30 contracts | 1024 | 22 |

### Visuals

| Visual | Type | X | Y | Width | Height |
|---|---|---|---|---|---|
| Spend vs Supply Risk (Kraljic 2x2) | Scatter chart | 16 | 206 | 760 | 488 |
| Segment Summary | Matrix (plus 2 lines of text) | 788 | 206 | 476 | 226 |
| Segment Rules and Typical Approach | Table | 788 | 440 | 476 | 254 |

**The 2x2 matrix (scatter chart)**
1. **Scatter chart**. **Values** (sometimes called Details): DimCategorySegment > **CategoryGroup**.
2. **X-axis**: **Total Spend**. **Y-axis**: **Category Supply Risk Score**.
3. **Legend**: DimCategorySegment > **KraljicSegment** (Strategic navy, Leverage `#3E6A9E`, Bottleneck amber `#E3A33B`, Routine teal `#5B8C85`). **Size**: **Contract Count**.
4. Format visual > **X-axis** > **Scale type**: **Log** (spend ranges from thousands to billions). Y-axis range 0 to 100.
5. **Analytics** pane (magnifying-glass icon) > **X-Axis Constant Line** > Add > Value `1800000000` (C$1.8B; any value between C$1.57B and C$2.08B splits the groups the same way). Dashed, grey. Optional: **Shade area** **After** in `#EAF1F8` (the mockup shades the Strategic corner).
6. **Analytics** > **Y-Axis Constant Line** > Add > Value `25`. Dashed, grey.
7. Four text boxes in the corners, bold, size 11, in the segment colour: top right `STRATEGIC (Strategic tier)`, bottom right `LEVERAGE (Tactical tier)`, top left `BOTTLENECK (Tactical tier)`, bottom left `ROUTINE (Operational tier)`.
8. Category labels: Format > **Category label** on shows every name and gets crowded; the mockup labels only the large categories, so leave it off and rely on tooltips, or add a few text boxes.
9. Tooltips: **ActiveSuppliers**, **SupplierHHI**, **NonCompetitiveSpendShare**, **SingleBidShare** (set each to "Average" in the well).

**Segment Summary (matrix)**: Rows **ProcurementTier**, then **KraljicSegment**. Values **Category Count**, **Total Spend**, **% of Total Spend**, and **% of contracts** (add a quick measure: Contract Count as % of grand total). Below it, inside the same tile, two text boxes (size 8):
- `Strategic = class A spend + risk 25 or more. Tactical = Leverage + Bottleneck.` (grey)
- `Thresholds are analyst-defined assumptions, not official classifications.` (red, italic)

**Segment Rules table**: **Table** from `segment_rules`: **KraljicSegment**, **ProcurementTier**, **Rule**, **TypicalApproach**. Turn on word wrap (Format > Values > Text wrap).

Optional: a slicer on DimCategorySegment > **LowDataConfidence** so viewers can hide the 22 tiny categories (fewer than 30 contracts, hollow dots in the mockup).

---

## Part 9. Page 5: Pareto 80/20

Mockup: `mockups/05_pareto.png`

![Pareto 80/20](mockups/05_pareto.png)

New page `Pareto 80/20`, paste the frame.

### KPI cards (5 cards, each 240 wide x 70 high, 12 apart, Y 126)

| Card title | Measure | Reference label | X | Expected |
|---|---|---|---|---|
| Class A Suppliers | Class A Vendors | Share of Vendors for 80% of Spend | 16 | 244 (0.64% of suppliers = 80.0% of spend) |
| Class B Suppliers | Class B Vendors | | 268 | 2,283 (15.0% of spend) |
| Class C Suppliers | Class C Vendors | | 520 | 35,843 (5.0% of spend) |
| Suppliers Making Half of Spend | Suppliers for Half of Spend | text: out of 38,370 suppliers | 772 | 11 |
| Class A Category Groups | Class A Categories | text: 82.0% of spend | 1024 | 10 of 85 |

### Visuals

| Visual | Type | X | Y | Width | Height |
|---|---|---|---|---|---|
| Supplier Pareto (top 400 of 38,370) | Line and clustered column chart | 16 | 206 | 616 | 330 |
| Category Pareto (top 25 of 85 groups) | Line and clustered column chart | 644 | 206 | 620 | 330 |
| Supplier ABC Summary | Matrix | 16 | 544 | 616 | 150 |
| Category ABC Summary | Matrix | 644 | 544 | 620 | 150 |

**Supplier Pareto (bars plus line)**
1. **Line and clustered column chart**. X-axis: **MasterVendorName**. Column y-axis: **Total Spend**. Line y-axis: **Vendor Cumulative % (Static)** and **80% Line**.
2. Filters on this visual: **DimVendor > VendorParetoRank** > Advanced filtering > **is less than or equal to** `400`. (The static cumulative column is government-wide, so filtering to the top 400 does not distort it.)
3. Sort descending by **Total Spend**. Format > Y-axis (columns) > **Scale type**: **Log**, so the long tail is visible. X-axis labels off (400 names do not fit).
4. Colour the 244 class A bars navy and the rest light blue: Columns > Colors > **fx** > Format style **Rules** based on **Vendor Pareto Class** (or VendorParetoClass): A = `#1F3A5F`, otherwise `#9DB9D8`.
5. Line colours: cumulative amber `#E3A33B`; 80% Line red, dashed (Format > Lines > pick the series > Line style **Dashed**).

**Category Pareto (bars plus line)**
1. **Line and clustered column chart**. X-axis: DimCategorySegment > **CategoryGroup**. Column: **Total Spend**. Line: **Category Cumulative Spend %** and **80% Line**.
2. Sort: **...** on the visual > **Sort axis** > **Total Spend** > **Sort descending**.
3. Leave Top N filters off this visual so the cumulative line uses all 85 groups (the axis will scroll; the mockup shows the first 25). A Top N filter would turn the line into "share of the top N" instead of share of all spend.
4. Bar colours by **CategoryParetoClass** (A navy, B light blue, C grey), line formatting as above.

**ABC summaries (two matrices)**
- Supplier: Rows **DimVendor > VendorParetoClass**; Values **Active Suppliers**, **Total Spend**, **% of Total Spend**. Filter out "No contracts". Expected: A 244 / 80.0%, B 2,283 / 15.0%, C 35,843 / 5.0%.
- Category: Rows **DimCategorySegment > CategoryParetoClass**; Values **Category Count**, **Total Spend**, **% of Total Spend**. Expected: A 10 / 82.0%, B 13 / 13.3%, C 62 / 4.7%.
- Font colour on the class column: A navy, B `#3E6A9E`, C grey.

Tip: the dynamic measures (**Vendor Cumulative Spend %**, **Vendor Pareto Class**) respond to slicers, so you can show "the 80/20 inside National Defence". Use them on a visual filtered to one department; across all 38,370 suppliers at once they can be slow.

---

## Part 10. Page 6: Supplier Master Data Quality

Mockup: `mockups/06_supplier_data_quality.png`

![Supplier Master Data Quality](mockups/06_supplier_data_quality.png)

New page `Supplier Master Data Quality`, paste the frame.

### KPI cards (5 cards, each 240 wide x 70 high, 12 apart, Y 126)

| Card title | Measure | Reference label | X | Expected |
|---|---|---|---|---|
| Raw Vendor Names | Vendor Names Raw | text: distinct spellings as published | 16 | 53,265 |
| Suggested Master Suppliers | Vendors After Cleansing | Vendor Reduction % | 268 | 38,514 (27.7% fewer) |
| Duplicate Vendor Rate | Duplicate Vendor Rate | | 520 | 7.7% |
| Spend Tied to Duplicates | Spend at Risk (Duplicates) | Spend at Risk % | 772 | C$13.9B (15.0%) |
| Names Cut at 35 Characters | Names Cut at 35 Characters | text: vs 791 names at 36 characters | 1024 | 7,963 |

### Visuals

| Visual | Type | X | Y | Width | Height |
|---|---|---|---|---|---|
| Vendor Clean-up Funnel | Funnel | 16 | 206 | 400 | 240 |
| Duplicate Cluster Sample | Table | 428 | 206 | 836 | 240 |
| Data-Quality Rules | Table | 16 | 454 | 1248 | 240 |

**Vendor Clean-up Funnel**: **Funnel** visual. **Category**: `dq_vendor_count_stages` > **Stage**. **Values**: **VendorCount** (Sum). Data labels: value and percent of first. The funnel sorts largest first, which matches the stage order (53,265, 47,070, 40,297, 38,514). Colours per stage (Show all): amber, light blue, `#3E6A9E`, navy.

**Duplicate Cluster Sample (table)** from dq_vendor_duplicates: **FuzzyClusterId**, **MasterVendorName**, **VendorName**, **SimilarityToMaster**, **ContractCount**, **Spend**. Filter FuzzyClusterId **is greater than** 0; sort by FuzzyClusterId, then Spend descending. Add **RawVariants** to Tooltips. The mockup shows clusters 3 (General Dynamics Ordnance and Tactical Systems, 15 records, C$861.6M) and 4 (Canadian Corps of Commissionaires, 16 records, C$447.8M). Optional slicer on **DuplicateType**, or a text filter on MasterVendorName for "COMMISSIONAIRES".

**Data-Quality Rules (table)** from dq_rule_summary: **RuleId**, **Rule**, **RecordsChecked**, **RecordsFailed**, **PctFailed**, **SpendAffected**, **Severity**. Sort by **PctFailed** descending (the first rows are DQ21 52.1%, DQ19 26.5%, DQ12 25.4%). Data bars on PctFailed (Values well arrow > Conditional formatting > Data bars, colour `#9DB9D8`); font colour rules on Severity (High red `#C0504D`, Medium amber `#E3A33B`, Low grey). All 21 rules are in the table; the mockup shows the first 8 rows and the rest scroll.

Optional extra: a bar of **Active Vendors** by DimVendor > **DQIssueCount**.

---

## Part 11. Polish

- Same card sizes and positions on every page (use the X / Y / Width / Height tables, or **Format** > **Align**).
- **Edit interactions** (Format tab) to control which visuals filter each other.
- Turn on **drill through**: on the Spend by Category page, drag **CategoryGroup** into **Drill through** in the Visualizations pane. Now right-clicking a category anywhere offers "Drill through > Spend by Category".

---

## Part 12. Save, export, share

- **Save**: **File** > **Save as** > `Federal_Procurement_Supplier_MDM.pbix`.
- **PDF**: **File** > **Export** > **Export to PDF**.
- **Screenshots**: **Windows + Shift + S**. **Focus mode** on a visual gives clean close-ups.
- **GitHub**: a public repository with the .pbix, `data/`, screenshots and a README (reuse the blurb in insights.md).
- **Publish to web (optional)**: **Home** > **Publish** needs a **work or school Microsoft account** with Power BI (personal Gmail or Outlook.com accounts cannot sign up). Then in the service: **File** > **Embed report** > **Publish to web (public)**, if your admin allows it. **Anyone on the internet can see everything** in a Publish to web report. Fine for this public open data; never for an employer's or client's data.
- Prefer a free public option? See `tableau/TABLEAU_GUIDE.md` to build the same story on Tableau Public.

---

## If something goes wrong

- **Card much bigger than expected**: a relationship is missing or points the wrong way.
- **Spend YoY % blank everywhere**: mark DimDate as a date table and pick one fiscal year.
- **Segment slicer does nothing**: check the DimCategory > DimCategorySegment relationship.
- **Months in the wrong order**: redo Sort by column.
- **IDs being summed**: set Summarization to Don't summarize.
- **Strange characters**: reload the file with File Origin 65001: Unicode (UTF-8).

Build it once by following the steps, then a second time from memory. The second build is when it sticks.
