# Tableau Public guide: Canadian Federal Procurement and Supplier Master Data Quality

This is the same story as the Power BI report, built in **Tableau Public** (free). Tableau Public saves your work to your public profile on the web, which makes it easy to share a link in applications and on LinkedIn.

Plan on 3 to 4 hours for the first build. The full-page mockups in `../mockups/` (start with `00_all_pages.png`) show exactly what the finished dashboards look like. They apply to both tools: one Tableau dashboard per mockup, same cards, same charts, same positions (Part 4 gives the pixel positions). Single-chart previews are in `../preview/`.

Fiscal years use short labels: **FY'24** = April 2023 to March 2024, **FY'25** = April 2024 to March 2025, **FY'26** = April 2025 to March 2026.

---

## The files in this folder

All files are flat (already joined), so you never have to build joins. Each is well under 15 MB.

| File | Rows | One row is | Use it for |
|---|---|---|---|
| `contracts_flat.csv` | 55,919 | One month x department x category x commodity type x competition type x duplicate flag x contract size, with totals | Spend trend, categories, departments, competition, YoY |
| `vendor_pareto.csv` | 38,370 | One supplier (grouped by suggested master vendor) | Top suppliers, supplier Pareto, ABC class, duplicate rate |
| `category_segments.csv` | 85 | One category group | Kraljic 2x2 scatter, category Pareto |
| `dq_rule_summary.csv` | 21 | One data-quality rule | Data quality table |
| `dq_vendor_count_stages.csv` | 4 | One cleansing stage | Before vs after bar |
| `dq_duplicate_clusters.csv` | 3,135 | One supplier record in a near-duplicate cluster | Duplicate clusters table |
| `procurement_methods.csv` | 2,080 | One fiscal year x department x commodity type x procurement method, with totals | Procurement method bar |
| `segment_rules.csv` | 4 | One Kraljic segment rule | Segment rules table |

Why `contracts_flat.csv` is summarized instead of one row per contract: a fully joined contract-level file would be over 30 MB. Summing to month level keeps every total exact (C$92.6B, 179,829 contracts) while staying small. Supplier names live in `vendor_pareto.csv`.

Key columns in `contracts_flat.csv`:
- Dimensions: **MonthStart** (date, first day of the month), **FiscalYear** (FY'24, FY'25, FY'26), **Department**, **CategoryGroup**, **KraljicSegment** (Strategic, Leverage, Bottleneck, Routine), **ProcurementTier** (Strategic, Tactical, Operational), **SupplyRiskScore**, **CategoryParetoClass** (A/B/C), **CommodityType** (Goods, Services, Construction), **CompetitionType**, **IsCompetitive** (1/0), **DuplicateVendorFlag** (Likely duplicate / No duplicate found), **ContractSize** (Under C$1B / C$1B or more)
- Measures: **Spend**, **OriginalValue**, **AmendmentValue**, **Contracts**, **AmendedContracts**, **CompetitiveWithBidCount**, **SingleBidContracts**

---

## Part 0. Install and sign up (15 minutes)

1. Go to public.tableau.com, create a free account (top right: **Sign Up**).
2. Download **Tableau Public** desktop for Windows and install it.
3. Open Tableau Public and sign in when asked (you need to be signed in to save).

---

## Part 1. Connect to the data (15 minutes)

1. On the start page, under **Connect** > **To a File**, click **Text file**.
2. Pick `contracts_flat.csv` > **Open**. The Data Source page opens with a preview.
3. Check the data types (the small icon above each column in the preview; click it to change):
   - **MonthStart**: **Date** (calendar icon)
   - **Spend**, **OriginalValue**, **AmendmentValue**, **SupplyRiskScore**: **Number (decimal)**
   - **Contracts**, **AmendedContracts**, **CompetitiveWithBidCount**, **SingleBidContracts**, **IsCompetitive**: **Number (whole)**
   - Everything else: **String** (Abc)
4. Rename the data source at the top left: double-click the name > `Contracts`.
5. Add the other files as **separate data sources** (do not drag them onto the same canvas): menu **Data** > **New Data Source** > **Text file** > pick the file. Do this for `vendor_pareto.csv` (rename `Vendors`), `category_segments.csv` (`Categories`), `dq_rule_summary.csv` (`DQ Rules`), `dq_vendor_count_stages.csv` (`DQ Stages`), `dq_duplicate_clusters.csv` (`DQ Clusters`), `procurement_methods.csv` (`Methods`) and `segment_rules.csv` (`Rules`).
   - In `Vendors`: **SpendSharePct** and **CumulativeSpendPct** should be Number (decimal); **IsPotentialDuplicate** Number (whole).
   - In `Categories`: the share columns and **SupplyRiskScore** should be Number (decimal).
6. Click **Sheet 1** at the bottom to start building. The **Data** pane on the left lists all data sources; click one to work with it.

### Set number formats once (saves time later)
In the Data pane (Contracts source), right-click **Spend** > **Default Properties** > **Number Format** > **Currency (Custom)** > Decimal places 0, Display units **Billions (B)**, Prefix `C$`. Repeat for OriginalValue and AmendmentValue. Do the same for **Spend** in the Vendors source.

---

## Part 2. Calculated fields (20 minutes)

To create one: right-click an empty spot in the Data pane > **Create Calculated Field**. Type the name at the top, paste the formula, click **OK**. Make sure you are in the right data source first.

### In the Contracts data source

**Avg Contract Value**
```
SUM([Spend]) / SUM([Contracts])
```
Expected: C$514,735 with no filters.

**Non-Competitive Spend %**
```
SUM(IF [IsCompetitive] = 0 THEN [Spend] END) / SUM([Spend])
```
Expected: 18.9%. (Right-click the new field > Default Properties > Number Format > Percentage, 1 decimal. Do this for every % field.)

**Non-Competitive Contract %**
```
SUM(IF [IsCompetitive] = 0 THEN [Contracts] END) / SUM([Contracts])
```
Expected: 38.1%.

**Single-Bid Rate**
```
SUM([SingleBidContracts]) / SUM([CompetitiveWithBidCount])
```
Expected: 44.9% (competitive contracts that reported a bid count).

**Amendment Rate**
```
SUM([AmendedContracts]) / SUM([Contracts])
```
Expected: 11.6%.

**Amendment Value Growth %**
```
SUM([AmendmentValue]) / SUM([OriginalValue])
```
Expected: 11.1%.

**Spend at Risk (Duplicates)**
```
SUM(IF [DuplicateVendorFlag] = "Likely duplicate" THEN [Spend] END)
```
Expected: C$13.9B.

**Spend at Risk %**
```
[Spend at Risk (Duplicates)] / SUM([Spend])
```
Expected: 15.0%.

**Goods Spend**, **Services Spend**, **Construction Spend** (three fields, for a KPI split row)
```
SUM(IF [CommodityType] = "Goods" THEN [Spend] END)
```
Make the other two the same way with "Services" and "Construction". Expected: C$19.9B, C$60.7B, C$12.0B.

**Spend YoY %** (a table calculation)
```
(SUM([Spend]) - LOOKUP(SUM([Spend]), -1)) / ABS(LOOKUP(SUM([Spend]), -1))
```
LOOKUP(..., -1) means "the previous value along the table". Put **FiscalYear** on Columns and this field on Text or Rows. Expected: FY'25 +70.5%, FY'26 -66.9% (FY'24 is blank because there is no earlier year).

**Cumulative Spend %** (table calculation, for Pareto charts)
```
RUNNING_SUM(SUM([Spend])) / TOTAL(SUM([Spend]))
```
RUNNING_SUM adds up spend from the first bar to the current one; TOTAL is the grand total. The bars must be sorted by spend, largest first.

**ABC Class** (table calculation)
```
IF RUNNING_SUM(SUM([Spend])) / TOTAL(SUM([Spend])) - SUM([Spend]) / TOTAL(SUM([Spend])) < 0.80 THEN "A"
ELSEIF RUNNING_SUM(SUM([Spend])) / TOTAL(SUM([Spend])) - SUM([Spend]) / TOTAL(SUM([Spend])) < 0.95 THEN "B"
ELSE "C"
END
```
A = the items making up the first 80% of spend, B = the next 15%, C = the last 5%. The item that crosses 80% still counts as A, because the test uses the share *before* it.

**80% Line**
```
0.8
```

### In the Vendors data source

**Duplicate Vendor Rate**
```
SUM(IF [IsPotentialDuplicate] = 1 THEN [VendorRecords] END) / SUM([VendorRecords])
```
Share of supplier records that sit in a near-duplicate cluster. Expected: 7.8% (3,135 of 40,153 records). The Power BI measure shows 7.7% because it counts only records with their own contracts.

**Active Suppliers**
```
COUNTD([MasterVendorName])
```
Expected: 38,370 suppliers with at least one contract (after grouping duplicate spellings).

**Class A Suppliers**
```
SUM(IF [ParetoClass] = "A" THEN 1 ELSE 0 END)
```
Expected: 244 (which is 0.64% of 38,370 suppliers).

`CumulativeSpendPct` and `ParetoClass` are already in the file, government-wide. The table-calc versions above give the same answer and also respond to filters.

---

## Part 3. Build the sheets

Rename each sheet by double-clicking its tab at the bottom. To add a sheet: the small icon to the right of the last tab.

### Sheet "KPI Total Spend" (and the other KPI cards)
1. Data source: Contracts.
2. Drag **Spend** onto **Text** on the Marks card. Change the mark type dropdown to **Text**.
3. Click **Text** on the Marks card > **...** > edit to: `Total Spend` on line 1 and `<SUM(Spend)>` on line 2. Make line 2 size 24, bold, navy (#1F3A5F).
4. Duplicate the sheet (right-click tab > **Duplicate**) to make cards for **Contracts** (SUM), **Avg Contract Value**, **Non-Competitive Spend %**, **Single-Bid Rate**, **Spend at Risk %**.
5. Make a second row of cards that splits spend: **Goods Spend**, **Services Spend**, **Construction Spend**, plus an **Active Suppliers** card from the Vendors source. A total card followed by its split is an easy way for a reader to see where the money goes in one glance.
6. For **Spend YoY %**: put **FiscalYear** on Columns and the YoY field on Text; you get one number per year.

### Sheet "Monthly Spend" (line, Mmm 'YY axis)
1. Drag **MonthStart** to **Columns**. Click the arrow on the pill and choose the second **Month** option (the one showing "May 2015", which is continuous, a green pill).
2. Drag **Spend** to **Rows**. Mark type: **Line**.
3. Format the axis: right-click the date axis > **Format** > **Scale** tab > **Dates** > **Custom** > type `mmm 'yy`. Labels read Apr '23, Jul '23 and so on. (If the apostrophe does not show, type `mmm "'"yy`.)
4. To control tick spacing: right-click the axis > **Edit Axis** > **Tick Marks** tab > **Fixed**, tick interval **3 months** (or 1 month).
5. Fiscal-year bands: right-click the axis > **Add Reference Line**, choose **Band**, scope **Entire Table**, from 1 Apr 2024 to 31 Mar 2025, fill light grey. That shades FY'25 so the three fiscal years are easy to tell apart.
6. Two big spikes (May '24 and Mar '25) come from single multi-billion awards. Duplicate the sheet, name it "Monthly Spend excl. C$1B+", and drag **ContractSize** to **Filters** > keep only **Under C$1B**. Put both on the dashboard, one above the other.
7. Title (double-click the title): `Monthly Spend, FY'24 to FY'26`.

### Sheet "Spend by Category" (bar)
1. **CategoryGroup** to Rows, **Spend** to Columns.
2. Sort descending (toolbar sort button, or the sort icon on the axis).
3. Drag **CategoryGroup** to **Filters** > **Top** tab > **By field**: Top **15** by **Spend** (Sum) > OK.
4. Drag **Contracts** to **Label**, and **Spend** to Label as well, so each bar shows "C$30.1B, 3,228".
5. Optional: **CommodityType** to **Color** to see goods vs services vs construction.
6. Exclude the catch-all bucket: drag **CategoryGroup** to Filters again (or use the same filter) > **General** tab > **Exclude** > tick **Unmapped object code** (only 0.2% of spend). Note it in the caption.
7. Title: `Top 15 Categories by Spend`.

### Sheet "Spend by Department" (bar)
Same pattern: **Department** on Rows, **Spend** on Columns, Top 10 filter, tooltip **Non-Competitive Spend %** and **Single-Bid Rate**.

### Sheet "Segment Summary" (table)
**ProcurementTier** and **KraljicSegment** on Rows; **Spend**, **Contracts** and **Non-Competitive Spend %** as Measure Values (drag them onto the table). Quick table calc for spend share: right-click SUM(Spend) > **Quick Table Calculation** > **Percent of Total**.

### Sheet "Kraljic 2x2" (scatter with reference lines)
1. Data source: **Categories**.
2. **CategorySpend** to **Columns**, **SupplyRiskScore** to **Rows**.
3. Drag **CategoryGroup** to **Detail** (so you get one dot per category).
4. **KraljicSegment** to **Color** (set colours: Strategic navy #1F3A5F, Leverage #3E6A9E, Bottleneck amber #E3A33B, Routine teal #5B8C85). **ContractCount** to **Size**.
5. Log scale: right-click the CategorySpend axis > **Edit Axis** > tick **Logarithmic**.
6. Vertical reference line: right-click the CategorySpend axis > **Add Reference Line** > Scope **Entire Table** > Value: **Constant** `1800000000` > Label **Custom**: `High spend (Pareto class A)` > dashed grey line. (Any value between C$1.57B and C$2.08B splits the groups the same way.)
7. Horizontal reference line: right-click the SupplyRiskScore axis > **Add Reference Line** > Constant `25` > Label `High supply risk`.
8. Quadrant labels: **Worksheet** > **Show Title** off if you like, then right-click in the view > **Annotate** > **Area** to type `STRATEGIC (Strategic tier)` top right, `LEVERAGE (Tactical tier)` bottom right, `BOTTLENECK (Tactical tier)` top left, `ROUTINE (Operational tier)` bottom left.
9. **LowDataConfidence** to **Filters** (keep 0) if you want to hide the 22 tiny categories with noisy scores.
10. Tooltip: add **ActiveSuppliers**, **SupplierHHI**, **NonCompetitiveSpendShare**, **SingleBidShare**.
11. Caption (Worksheet > Show Caption): `Thresholds are analyst-defined assumptions: high spend = Pareto class A categories; high risk = Supply Risk Score 25 or more.`

### Sheet "Category Pareto" (bars plus line, dual axis)
1. Data source: Contracts.
2. **CategoryGroup** to Columns. **Spend** to Rows. Sort CategoryGroup descending by Spend (click the pill arrow > **Sort** > By **Field** > Spend, Descending).
3. Drag **Cumulative Spend %** to Rows as well (right of Spend). You now have two charts stacked.
4. Right-click the Cumulative Spend % pill > **Compute Using** > **CategoryGroup**.
5. Right-click the Cumulative Spend % pill > **Dual Axis**. On the Marks card set **SUM(Spend)** to **Bar** and **Cumulative Spend %** to **Line**.
6. Right-click the right axis > **Edit Axis** > Fixed 0 to 1. (Do **not** synchronize axes; they use different units.)
7. 80% line: right-click the right axis > **Add Reference Line** > Constant **0.8** > red dashed > Label `80%`.
8. Colour the bars by class: drag **ABC Class** to **Color** on the SUM(Spend) marks card, then set its Compute Using to CategoryGroup too. Class A bars dark navy, B light blue, C grey.
9. Title: `Category Pareto: 80% of Spend`. Expected: 10 of 85 groups reach 80%.

### Sheet "Supplier Pareto" (bars plus line, dual axis)
1. Data source: **Vendors**.
2. **MasterVendorName** to Columns, **Spend** to Rows, sorted descending by Spend.
3. **CumulativeSpendPct** to Rows (use **Attribute** or **Max**: click the pill arrow > Measure > **Maximum**). This column is already the government-wide running share.
4. **Dual Axis**, bars for Spend, line for CumulativeSpendPct, right axis fixed 0 to 1, reference line at 0.8.
5. Filter **VendorRank** to **at most 400** (drag VendorRank to Filters > Range of values > 1 to 400) so the chart stays readable; the line still shows the true government-wide share.
6. **ParetoClass** to Color. Hide the long name labels: right-click the bottom header > uncheck **Show Header**.
7. Title: `Supplier Pareto: 244 suppliers (0.6%) = 80% of spend`.

### Sheet "Top 10 Suppliers"
Vendors source: **MasterVendorName** to Rows, **Spend** to Columns, filter **VendorRank** at most 10, sort descending. Tooltip **TopDepartment**, **TopCategoryGroup**, **RawSpellings**.

### Sheet "Vendor Clean-up" (before vs after bar)
DQ Stages source: **Stage** to Columns, **VendorCount** to Rows, sort Stage by **StageOrder** (pill arrow > Sort > By field > StageOrder ascending). Labels on.

### Sheet "Data Quality Rules" (table)
DQ Rules source: drag **RuleId**, **Rule**, **Severity** to Rows; **RecordsChecked**, **RecordsFailed**, **PctFailed** as Measure Values. PctFailed is already in percent units (1.62 means 1.62%), so format it as Number with suffix `%`, not as Percentage. Add **WhyItMatters** to Tooltip. Colour **Severity** (drag to Color, mark type Square or Text): High red, Medium amber, Low grey.

### Sheet "Duplicate Clusters" (table)
DQ Clusters source: **FuzzyClusterId**, **MasterVendorName**, **VendorName** to Rows; **SimilarityToMaster**, **RawVariantCount**, **Spend** as Measure Values. Set FuzzyClusterId to a **Dimension** (right-click > Convert to Dimension) and sort ascending. Add **RawVariants** to Tooltip.

---

### Part 3b. Extra sheets and cards to match the mockups

### Extra calculated fields for the mockup KPI cards

In the **Contracts** source:
```
// Spend YoY Latest FY  (expected -66.9%)
(SUM(IF [FiscalYear] = "FY'26" THEN [Spend] END) - SUM(IF [FiscalYear] = "FY'25" THEN [Spend] END))
/ SUM(IF [FiscalYear] = "FY'25" THEN [Spend] END)
```
```
// Strategic Tier %  (expected 27.8%; make Tactical Tier % 63.2% and Operational Tier % 8.9% the same way)
SUM(IF [ProcurementTier] = "Strategic" THEN [Spend] END) / SUM([Spend])
```
```
// Goods Share %  (expected 21.5%; Services 65.6%, Construction 13.0%)
SUM(IF [CommodityType] = "Goods" THEN [Spend] END) / SUM([Spend])
```

In the **Vendors** source (these use the government-wide shares in the file, so read them with no filters):
```
// Top 10 Supplier Share  (expected 49.2%)
SUM(IF [VendorRank] <= 10 THEN [Spend] END) / SUM([Spend])
```
```
// Supplier HHI  (expected 387)
SUM(POWER([SpendSharePct] * 100, 2))
```
```
// Class B Suppliers  (expected 2,283; Class C Suppliers 35,843 with "C")
SUM(IF [ParetoClass] = "B" THEN 1 ELSE 0 END)
```
```
// Suppliers for Half of Spend  (expected 11)
SUM(IF [CumulativeSpendPct] - [SpendSharePct] < 0.5 THEN 1 ELSE 0 END)
```

In the **Categories** source:
```
// Top Category Share  (expected 32.6%)
SUM(IF [CategoryParetoRank] = 1 THEN [CategorySpend] END) / SUM([CategorySpend])
```
```
// Top 15 Category Share  (expected 89.3%)
SUM(IF [CategoryParetoRank] <= 15 THEN [CategorySpend] END) / SUM([CategorySpend])
```
```
// Class A Categories  (expected 10)
SUM(IF [CategoryParetoClass] = "A" THEN 1 ELSE 0 END)
```
```
// Low-Confidence Groups  (expected 22)
SUM([LowDataConfidence])
```
Category Groups is simply **COUNTD([CategoryGroup])** (85).

In **DQ Stages**: `Raw Vendor Names` = `MAX(IF [StageOrder] = 1 THEN [VendorCount] END)` (53,265) and `Suggested Masters` = `MAX(IF [StageOrder] = 4 THEN [VendorCount] END)` (38,514).
In **DQ Rules**: `Names Cut at 35 Characters` = `SUM(IF [RuleId] = "DQ18" THEN [RecordsFailed] END)` (7,963).

Note: the Duplicate Vendor Rate card shows 7.8% in Tableau and 7.7% in the Power BI mockup, because the Tableau version also counts records of suppliers whose own records have no contracts (see Part 2).

### Sheet "Spend by Fiscal Year" (column)
**FiscalYear** to Columns, **Spend** to Rows, mark type **Bar**. **FiscalYear** to Color (FY'24 `#9DB9D8`, FY'25 `#1F3A5F`, FY'26 `#3E6A9E`). Drag **Spend** and **Spend YoY %** to Label (the YoY calc runs across FiscalYear: +70.5% and -66.9%). **Contracts** to Tooltip.

### Sheet "Commodity Donut"
1. In the Rows shelf, double-click and type `MIN(0)`, press Enter. Do it again so there are two MIN(0) pills.
2. Right-click the second pill > **Dual Axis**, then right-click the axis > **Synchronize Axis**. Hide both axes (right-click > uncheck **Show Header**).
3. First Marks card: type **Pie**, **CommodityType** to Color (Services navy, Goods `#3E6A9E`, Construction amber `#E3A33B`), **Spend** to Angle, **CommodityType** and **Spend** (Quick table calc: Percent of Total) to Label.
4. Second Marks card: type **Circle**, Color white, make it smaller than the pie with the Size slider, **Spend** to Label (shows C$92.6B in the hole).

### Sheet "Category Treemap" (Categories source)
Mark type **Square**. **CategorySpend** to Size, **StandardObject** to Color (Machinery and equipment navy, Professional and special services `#3E6A9E`, Repair and maintenance `#5B8C85`, Rentals `#E3A33B`, the rest grey), **CategoryGroup** and **CategorySpend** to Label.

### Sheet "Procurement Method" (Methods source)
**ProcurementMethod** to Rows, **Spend** to Columns, sort descending, **CompetitionType** to Color (Competitive navy, Non-competitive amber), **Contracts** to Label.

### Sheet "Competition by Year" (100% stacked column)
**FiscalYear** to Columns, **Spend** to Rows, **CompetitionType** to Color. Right-click the SUM(Spend) pill > **Quick Table Calculation** > **Percent of Total**, then > **Compute Using** > **CompetitionType**, so each column adds to 100%. Labels on. Expected competitive share: FY'24 78.7%, FY'25 86.8%, FY'26 68.0%.

### Sheet "Segment Rules" (Rules source)
**KraljicSegment**, **ProcurementTier**, **Rule**, **TypicalApproach** to Rows (a text table). Format > Cell > text wrap on; widen the columns.

### Sheets "Supplier ABC" (Vendors) and "Category ABC" (Categories)
Supplier ABC: **ParetoClass** to Rows; drag **MasterVendorName** to Text and set it to **Count (Distinct)**, then add **Spend** and Spend as Percent of Total (Measure Values). Category ABC: **CategoryParetoClass** to Rows with **CategoryGroup** (Count), **CategorySpend** and its Percent of Total.

### Turning "Vendor Clean-up" into a funnel
In DQ Stages, create `Negative VendorCount` = `-[VendorCount]`. Put **Stage** on Rows (sorted by StageOrder), then **Negative VendorCount** and **VendorCount** on Columns, both as bars in the same colour per stage. The mirrored bars make a centred funnel. Hide both axes and label the right-hand bars.

---

## Part 4. Dashboards (one per mockup)

Make six dashboards (the icon with four squares next to the sheet tabs), named like the Power BI pages: Spend Overview, Spend by Category, Vendor and Competition, Category Segmentation, Pareto 80/20, Supplier Master Data Quality.

For each: on the left, **Size** > **Fixed size** > **Custom** > **1600 x 900** (the mockup size). Make every object **Floating** (bottom of the Objects pane), then select it and type its position in the **Layout** pane > **Position** (x, y) and **Size** (w, h). The numbers are the Power BI positions from BUILD_GUIDE.md multiplied by 1.25.

Shared frame on every dashboard:

| Element | How to make it | X | Y | Width | Height |
|---|---|---|---|---|---|
| Header band and title | **Text** object: `Government of Canada Contract Spend \| FY'24 to FY'26`, white bold 18; Layout > Background navy `#1F3A5F` | 0 | 0 | 1600 | 55 |
| Page tabs | Six **Navigation** buttons (one per dashboard), background `#DCE6F1`, current page `#3E6A9E` with white text | 0 | 55 | 1600 | 33 |
| Fiscal Year filter | Filter card for **FiscalYear**, style **Single Value (list)** or multiple values, shown horizontally | 20 | 98 | 312 | 50 |
| Department filter | Filter card for **Department**, style **Single Value (dropdown)** | 348 | 98 | 412 | 50 |
| Commodity type filter | Filter card for **CommodityType**, dropdown | 775 | 98 | 312 | 50 |
| Source footer | Text object, size 8, grey: `Source: Government of Canada, Proactive Publication - Contracts (open.canada.ca), Open Government Licence - Canada. Downloaded 6 Oct 2026.` | 10 | 873 | 1580 | 27 |

Dashboard background: Dashboard menu > **Format** > Dashboard shading `#F2F4F7`. Give every sheet a white background with a light border (`#D9DFE7`) and 4 px inner padding, so each one reads as a tile like in the mockups.

KPI cards are the "KPI ..." text sheets from Part 3: label on line 1 (size 9, grey), value on line 2 (size 20, bold, navy), small grey note on line 3. Fit: **Entire View**.

**Dashboard 1: Spend Overview** (mockup `../mockups/01_spend_overview.png`)

| Mockup element | Tableau sheet (data source if not Contracts) | X | Y | Width | Height |
|---|---|---|---|---|---|
| Total Spend | KPI Total Spend | 20 | 158 | 160 | 88 |
| Contracts | KPI Contracts | 195 | 158 | 160 | 88 |
| Active Suppliers | KPI Active Suppliers (Vendors) | 370 | 158 | 160 | 88 |
| Avg Contract Value | KPI Avg Contract Value | 545 | 158 | 160 | 88 |
| Goods Spend | KPI Goods | 720 | 158 | 160 | 88 |
| Services Spend | KPI Services | 895 | 158 | 160 | 88 |
| Construction Spend | KPI Construction | 1070 | 158 | 160 | 88 |
| Spend YoY, FY'26 | KPI YoY FY'26 | 1245 | 158 | 160 | 88 |
| Non-Competitive | KPI Non-Competitive | 1420 | 158 | 160 | 88 |
| Monthly Spend, FY'24 to FY'26 | Monthly Spend | 20 | 258 | 1020 | 300 |
| Spend by Fiscal Year | Spend by Fiscal Year | 1055 | 258 | 525 | 300 |
| Top 10 Departments by Spend | Spend by Department | 20 | 568 | 1020 | 300 |
| Spend by Commodity Type | Commodity Donut | 1055 | 568 | 525 | 300 |

**Dashboard 2: Spend by Category** (mockup `../mockups/02_spend_by_category.png`)

| Mockup element | Tableau sheet (data source if not Contracts) | X | Y | Width | Height |
|---|---|---|---|---|---|
| Total Spend | KPI Total Spend | 20 | 158 | 300 | 88 |
| Category Groups | KPI Category Groups (Categories) | 335 | 158 | 300 | 88 |
| Top Category Share | KPI Top Category Share (Categories) | 650 | 158 | 300 | 88 |
| Top 15 Categories Share | KPI Top 15 Share (Categories) | 965 | 158 | 300 | 88 |
| Groups Making 80% of Spend | KPI Class A Categories (Categories) | 1280 | 158 | 300 | 88 |
| Spend by Category Group (top 15) | Spend by Category | 20 | 258 | 1560 | 335 |
| Treemap: Standard Object > Category Group | Category Treemap (Categories) | 20 | 602 | 1560 | 265 |

**Dashboard 3: Vendor and Competition** (mockup `../mockups/03_vendor_competition.png`)

| Mockup element | Tableau sheet (data source if not Contracts) | X | Y | Width | Height |
|---|---|---|---|---|---|
| Top 10 Supplier Share | KPI Top 10 Supplier Share (Vendors) | 20 | 158 | 248 | 88 |
| Supplier HHI | KPI Supplier HHI (Vendors) | 282 | 158 | 248 | 88 |
| Non-Competitive Spend | KPI Non-Competitive | 545 | 158 | 248 | 88 |
| Single-Bid Rate | KPI Single-Bid Rate | 808 | 158 | 248 | 88 |
| Amendment Rate | KPI Amendment Rate | 1070 | 158 | 248 | 88 |
| Amendment Value Growth | KPI Amendment Value Growth | 1332 | 158 | 248 | 88 |
| Top 10 Suppliers by Spend | Top 10 Suppliers (Vendors) | 20 | 258 | 770 | 610 |
| Spend by Procurement Method | Procurement Method (Methods) | 805 | 258 | 775 | 300 |
| Competitive vs Non-Competitive Spend by Year | Competition by Year | 805 | 568 | 775 | 300 |

**Dashboard 4: Category Segmentation** (mockup `../mockups/04_category_segmentation.png`)

| Mockup element | Tableau sheet (data source if not Contracts) | X | Y | Width | Height |
|---|---|---|---|---|---|
| Strategic Tier | KPI Strategic Tier | 20 | 158 | 300 | 88 |
| Tactical Tier | KPI Tactical Tier | 335 | 158 | 300 | 88 |
| Operational Tier | KPI Operational Tier | 650 | 158 | 300 | 88 |
| High-Risk Threshold | Text object: 25, Supply Risk Score; analyst-defined | 965 | 158 | 300 | 88 |
| Low-Confidence Groups | KPI Low-Confidence Groups (Categories) | 1280 | 158 | 300 | 88 |
| Spend vs Supply Risk (Kraljic 2x2) | Kraljic 2x2 (Categories) | 20 | 258 | 950 | 610 |
| Segment Summary | Segment Summary | 985 | 258 | 595 | 282 |
| Segment Rules and Typical Approach | Segment Rules (Rules) | 985 | 550 | 595 | 318 |

**Dashboard 5: Pareto 80/20** (mockup `../mockups/05_pareto.png`)

| Mockup element | Tableau sheet (data source if not Contracts) | X | Y | Width | Height |
|---|---|---|---|---|---|
| Class A Suppliers | KPI Class A Suppliers (Vendors) | 20 | 158 | 300 | 88 |
| Class B Suppliers | KPI Class B Suppliers (Vendors) | 335 | 158 | 300 | 88 |
| Class C Suppliers | KPI Class C Suppliers (Vendors) | 650 | 158 | 300 | 88 |
| Suppliers Making Half of Spend | KPI Half of Spend (Vendors) | 965 | 158 | 300 | 88 |
| Class A Category Groups | KPI Class A Categories (Categories) | 1280 | 158 | 300 | 88 |
| Supplier Pareto (top 400 of 38,370) | Supplier Pareto (Vendors) | 20 | 258 | 770 | 412 |
| Category Pareto (top 25 of 85 groups) | Category Pareto | 805 | 258 | 775 | 412 |
| Supplier ABC Summary | Supplier ABC (Vendors) | 20 | 680 | 770 | 188 |
| Category ABC Summary | Category ABC (Categories) | 805 | 680 | 775 | 188 |

**Dashboard 6: Supplier Master Data Quality** (mockup `../mockups/06_supplier_data_quality.png`)

| Mockup element | Tableau sheet (data source if not Contracts) | X | Y | Width | Height |
|---|---|---|---|---|---|
| Raw Vendor Names | KPI Raw Names (DQ Stages) | 20 | 158 | 300 | 88 |
| Suggested Master Suppliers | KPI Masters (DQ Stages) | 335 | 158 | 300 | 88 |
| Duplicate Vendor Rate | KPI Duplicate Rate (Vendors) | 650 | 158 | 300 | 88 |
| Spend Tied to Duplicates | KPI Spend at Risk | 965 | 158 | 300 | 88 |
| Names Cut at 35 Characters | KPI Names Cut at 35 (DQ Rules) | 1280 | 158 | 300 | 88 |
| Vendor Clean-up Funnel | Vendor Clean-up Funnel (DQ Stages) | 20 | 258 | 500 | 300 |
| Duplicate Cluster Sample (suggested master and its variants) | Duplicate Clusters (DQ Clusters) | 535 | 258 | 1045 | 300 |
| Data-Quality Rules (8 of 21, highest failure rate first) | Data Quality Rules (DQ Rules) | 20 | 568 | 1560 | 300 |

### Filters
On the Spend Overview dashboard, click the Monthly Spend sheet > its small down arrow > **Filters** > **FiscalYear**, then again for **CommodityType** and **Department**. On each filter card: arrow > **Apply to Worksheets** > **All Using Related Data Sources** (the Methods source has the same field names, so it follows along; if it does not, use **Data** > **Edit Blend Relationships** and match FiscalYear, Department and CommodityType). Sheets from the Vendors, Categories and DQ sources show government-wide numbers and are not filtered by these three filters; say so in a small note on those dashboards.

### Actions (click a bar to filter)
**Dashboard** menu > **Actions** > **Add Action** > **Filter**. Source sheet: **Spend by Category**. Target sheets: **Monthly Spend**, **Spend by Department**. Run action on: **Select**. Clearing the selection: **Show all values**. Now clicking a category bar shows that category's monthly trend and departments.

Optional: a **Highlight** action on KraljicSegment so hovering a legend item highlights that quadrant.

### Navigation
The six Navigation buttons in the page tabs strip jump between the dashboards. In Tableau Public, also tick **Show sheets as tabs** when publishing if you want Tableau's own tabs.

---

## Part 5. Publish to Tableau Public

1. **File** > **Save to Tableau Public As...**
2. Sign in if asked. Name it `Canadian Federal Procurement and Supplier Master Data Quality`.
3. Your browser opens the published workbook. Click **Edit Details** (pencil icon near the title):
   - **Title**: `Canadian Federal Procurement and Supplier Master Data Quality, FY'24 to FY'26`
   - **Description** (copy and adjust):
     `Spend, competition, category segmentation (Strategic / Tactical / Operational), Pareto 80/20 and supplier master data quality analysis of 179,829 Government of Canada contracts over $10,000 (C$92.6B, April 2023 to March 2026). Data: Government of Canada, Proactive Publication - Contracts (open.canada.ca), downloaded 6 Oct 2026. Contains information licensed under the Open Government Licence - Canada. Category labels from the Government-wide Chart of Accounts (open.canada.ca). Segment thresholds and vendor matching rules are my own analyst-defined assumptions.`
   - Add 3 to 5 tags: `procurement`, `spend analysis`, `master data`, `Canada`, `open data`.
4. Under **Settings**, decide whether to allow downloads of the workbook (fine for this public data).
5. Copy the link for your portfolio, CV and LinkedIn.

Everything on Tableau Public is visible to anyone. That is fine for this open government data; never publish an employer's or client's data there.

---

## If something goes wrong

- **Totals look too big**: check you used SUM, not COUNT, and that you are in the right data source.
- **Cumulative line looks wrong**: the bars must be sorted descending, and the table calculation must be computed using the category (or supplier) field.
- **YoY shows odd numbers**: make sure FiscalYear is on Columns and the calc runs across the table (Compute Using > FiscalYear).
- **Months in alphabetical order**: use MonthStart as a continuous date, not a text field.
- **Accents look strange**: the files are UTF-8; in the Data Source page, click the file's dropdown > **Text File Properties** > Character Set **UTF-8**.
