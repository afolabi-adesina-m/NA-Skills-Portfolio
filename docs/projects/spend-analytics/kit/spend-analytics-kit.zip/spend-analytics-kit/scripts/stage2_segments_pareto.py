# Stage 2: category segmentation (Kraljic + Strategic/Tactical/Operational) and Pareto ABC
import pandas as pd, numpy as np, json
D='/workspace/powerbi-kit/data/'
f=pd.read_csv(D+'FactContracts.csv',dtype={'ProcurementId':str}); v=pd.read_csv(D+'DimVendor.csv',keep_default_na=False,na_values=[''])
c=pd.read_csv(D+'DimCategory.csv',dtype={'EconomicObjectCode':str}); m=pd.read_csv(D+'DimProcurementMethod.csv')
v['CountryCode']=v.CountryCode.fillna('')  # keep Namibia 'NA' as text
x=f.merge(v[['VendorKey','MasterVendorName']],on='VendorKey').merge(c[['CategoryKey','CategoryGroup','StandardObject']],on='CategoryKey').merge(m[['MethodKey','IsCompetitive']],on='MethodKey')

# ---------- assumptions (analyst-defined) ----------
HIGH_SPEND_RULE='Category group is in Pareto class A (the groups that together make up the first 80% of spend)'
RISK_THRESHOLD=25.0   # Supply Risk Score >= 25 = high risk
SCARCITY_N=10         # scarcity = min(1, 10 / active suppliers)
MIN_CONTRACTS=30      # below this the scores are flagged as low confidence

def pareto(spend):
    s=spend.sort_values(ascending=False); tot=s.sum()
    cum=s.cumsum()/tot; prev=cum-s/tot
    cls=np.where(prev<0.80,'A',np.where(prev<0.95,'B','C'))
    return pd.DataFrame({'Spend':s,'Rank':np.arange(1,len(s)+1),'CumulativeSpendPct':cum.round(6),'ParetoClass':cls})

# ---------- category groups ----------
def met(g):
    s=g.ContractValue.sum(); vs=g.groupby('MasterVendorName').ContractValue.sum().clip(lower=0)
    hhi=((vs/vs.sum()*100)**2).sum() if vs.sum()>0 else np.nan
    nc=g.loc[g.IsCompetitive==0,'ContractValue'].sum()/s if s>0 else np.nan
    cb=g[(g.IsCompetitive==1)&(g.NumberOfBids>=1)]
    sb=(cb.NumberOfBids==1).mean() if len(cb) else np.nan
    n=g.MasterVendorName.nunique()
    return pd.Series(dict(ContractCount=len(g),ActiveSuppliers=n,SupplierHHI=hhi,NonCompetitiveSpendShare=nc,SingleBidShare=sb,CompetitiveContractsWithBids=len(cb),SupplierScarcity=min(1,SCARCITY_N/n)))
G=x.groupby('CategoryGroup').apply(met,include_groups=False)
G['SupplyRiskScore']=(100*pd.concat([G.SupplierHHI/10000,G.NonCompetitiveSpendShare,G.SingleBidShare,G.SupplierScarcity],axis=1).mean(axis=1,skipna=True)).round(1)
P=pareto(x.groupby('CategoryGroup').ContractValue.sum())
G=G.join(P).sort_values('Rank')
G['SpendLevel']=np.where(G.ParetoClass=='A','High','Low')
G['RiskLevel']=np.where(G.SupplyRiskScore>=RISK_THRESHOLD,'High','Low')
seg={('High','High'):'Strategic',('High','Low'):'Leverage',('Low','High'):'Bottleneck',('Low','Low'):'Routine'}
G['KraljicSegment']=[seg[(a,b)] for a,b in zip(G.SpendLevel,G.RiskLevel)]
G['ProcurementTier']=G.KraljicSegment.map({'Strategic':'Strategic','Leverage':'Tactical','Bottleneck':'Tactical','Routine':'Operational'})
G['SegmentSort']=G.KraljicSegment.map({'Strategic':1,'Leverage':2,'Bottleneck':3,'Routine':4})
G['LowDataConfidence']=(G.ContractCount<MIN_CONTRACTS).astype(int)
so=x.groupby('CategoryGroup').StandardObject.agg(lambda s:s.value_counts().index[0])
G['StandardObject']=so
G=G.reset_index().rename(columns={'CategoryGroup':'CategoryGroup','Rank':'CategoryParetoRank','CumulativeSpendPct':'CategoryCumulativeSpendPct','ParetoClass':'CategoryParetoClass','Spend':'CategorySpend'})
G.insert(0,'CategoryGroupKey',np.arange(1,len(G)+1))
for col in ['SupplierHHI']: G[col]=G[col].round(1)
for col in ['NonCompetitiveSpendShare','SingleBidShare','SupplierScarcity']: G[col]=G[col].round(4)
G['CategorySpend']=G.CategorySpend.round(2)
DimCategorySegment=G[['CategoryGroupKey','CategoryGroup','StandardObject','CategorySpend','ContractCount','ActiveSuppliers','SupplierHHI','NonCompetitiveSpendShare','SingleBidShare','CompetitiveContractsWithBids','SupplierScarcity','SupplyRiskScore','SpendLevel','RiskLevel','KraljicSegment','ProcurementTier','SegmentSort','LowDataConfidence','CategoryParetoRank','CategoryCumulativeSpendPct','CategoryParetoClass']]
# groups with no contracts in window (none expected) -> keep DimCategory keys valid
c=c.drop(columns=[k for k in ['CategoryGroupKey'] if k in c.columns])
c=c.merge(G[['CategoryGroup','CategoryGroupKey']],on='CategoryGroup',how='left')
missing=c.CategoryGroupKey.isna()
if missing.any():
    extra=pd.DataFrame({'CategoryGroup':sorted(c.loc[missing,'CategoryGroup'].unique())})
    extra['CategoryGroupKey']=np.arange(len(G)+1,len(G)+1+len(extra))
    for col in DimCategorySegment.columns:
        if col not in extra: extra[col]=np.nan
    extra['KraljicSegment']='No contracts in window'; extra['ProcurementTier']='No contracts in window'; extra['SegmentSort']=5; extra['LowDataConfidence']=1
    DimCategorySegment=pd.concat([DimCategorySegment,extra[DimCategorySegment.columns]])
    c=c.drop(columns='CategoryGroupKey').merge(DimCategorySegment[['CategoryGroup','CategoryGroupKey']],on='CategoryGroup',how='left')
c['CategoryGroupKey']=c.CategoryGroupKey.astype(int)
# CategoryGroup / StandardObject now live in DimCategorySegment (avoid duplicate fields)
c['ObjectName']=c.ObjectName.fillna('Not described'); c['CategoryDescription']=c.CategoryDescription.fillna('Not described')
c.drop(columns=['CategoryGroup','StandardObject']).to_csv(D+'DimCategory.csv',index=False)
DimCategorySegment.to_csv(D+'DimCategorySegment.csv',index=False)

rules=pd.DataFrame([
 dict(SegmentSort=1,KraljicSegment='Strategic',ProcurementTier='Strategic',SpendLevel='High',RiskLevel='High',Rule=f'{HIGH_SPEND_RULE}; Supply Risk Score >= {RISK_THRESHOLD:g}',TypicalApproach='Long-term partnerships, joint planning, supplier performance and risk management'),
 dict(SegmentSort=2,KraljicSegment='Leverage',ProcurementTier='Tactical',SpendLevel='High',RiskLevel='Low',Rule=f'{HIGH_SPEND_RULE}; Supply Risk Score < {RISK_THRESHOLD:g}',TypicalApproach='Competitive tenders, volume consolidation, price negotiation'),
 dict(SegmentSort=3,KraljicSegment='Bottleneck',ProcurementTier='Tactical',SpendLevel='Low',RiskLevel='High',Rule=f'Not Pareto class A; Supply Risk Score >= {RISK_THRESHOLD:g}',TypicalApproach='Secure supply: qualify alternative suppliers, standing offers, safety stock'),
 dict(SegmentSort=4,KraljicSegment='Routine',ProcurementTier='Operational',SpendLevel='Low',RiskLevel='Low',Rule=f'Not Pareto class A; Supply Risk Score < {RISK_THRESHOLD:g}',TypicalApproach='Simplify and automate: catalogues, call-ups, purchasing cards'),
])
rules.to_csv(D+'segment_rules.csv',index=False)

# ---------- vendor Pareto (by suggested master vendor) ----------
VP=pareto(x.groupby('MasterVendorName').ContractValue.sum())
v=v.drop(columns=[k for k in ['VendorParetoRank','VendorCumulativeSpendPct','VendorParetoClass'] if k in v.columns])
v['VendorParetoRank']=v.MasterVendorName.map(VP.Rank).astype('Int64')
v['VendorCumulativeSpendPct']=v.MasterVendorName.map(VP.CumulativeSpendPct)
v['VendorParetoClass']=v.MasterVendorName.map(VP.ParetoClass).fillna('No contracts')
v.to_csv(D+'DimVendor.csv',index=False)

# ---------- numbers ----------
R={}
nV=len(VP); a=(VP.ParetoClass=='A').sum(); b=(VP.ParetoClass=='B').sum()
R['vendors']=dict(n=int(nV),A=int(a),B=int(b),C=int(nV-a-b),A_pct=a/nV*100,B_pct=b/nV*100,C_pct=(nV-a-b)/nV*100,
   spendA=VP.loc[VP.ParetoClass=='A','Spend'].sum()/VP.Spend.sum()*100,spendB=VP.loc[VP.ParetoClass=='B','Spend'].sum()/VP.Spend.sum()*100)
R['vendors']['n_to_80']=int((VP.CumulativeSpendPct<0.80).sum()+1); R['vendors']['pct_to_80']=R['vendors']['n_to_80']/nV*100
R['vendors']['n_to_50']=int((VP.CumulativeSpendPct<0.50).sum()+1)
nC=len(P); R['categories']=dict(n=int(nC),A=int((P.ParetoClass=='A').sum()),B=int((P.ParetoClass=='B').sum()),C=int((P.ParetoClass=='C').sum()))
R['categories']['n_to_80']=int((P.CumulativeSpendPct<0.80).sum()+1); R['categories']['pct_to_80']=R['categories']['n_to_80']/nC*100
R['categories']['A_spend']=P.loc[P.ParetoClass=='A','Spend'].sum()/P.Spend.sum()*100
# object-code level too
PO=pareto(x.groupby('CategoryKey').ContractValue.sum()); R['object_codes']=dict(n=int(len(PO)),n_to_80=int((PO.CumulativeSpendPct<0.80).sum()+1))
R['object_codes']['pct_to_80']=R['object_codes']['n_to_80']/len(PO)*100
tot=x.ContractValue.sum()
segsum=G.groupby('KraljicSegment').agg(groups=('CategoryGroup','count'),spend=('CategorySpend','sum'),contracts=('ContractCount','sum'),lowdata=('LowDataConfidence','sum'))
segsum['spend_pct']=segsum.spend/tot*100; segsum['contract_pct']=segsum.contracts/len(x)*100
tier=G.groupby('ProcurementTier').agg(groups=('CategoryGroup','count'),spend=('CategorySpend','sum'),contracts=('ContractCount','sum')); tier['spend_pct']=tier.spend/tot*100; tier['contract_pct']=tier.contracts/len(x)*100
R['segments']=segsum.round(3).reset_index().to_dict('records'); R['tiers']=tier.round(3).reset_index().to_dict('records')
R['reliable_median_risk']=float(G.loc[G.ContractCount>=MIN_CONTRACTS,'SupplyRiskScore'].median())
R['seg_members']={s:G.loc[G.KraljicSegment==s,['CategoryGroup','CategorySpend','SupplyRiskScore','SupplierHHI','NonCompetitiveSpendShare','SingleBidShare']].round(3).values.tolist() for s in ['Strategic','Leverage']}
R['bottleneck_reliable']=G.loc[(G.KraljicSegment=='Bottleneck')&(G.LowDataConfidence==0),['CategoryGroup','CategorySpend','SupplyRiskScore']].round(2).values.tolist()
json.dump(R,open('/workspace/src/stage2_numbers.json','w'),indent=1,default=float)
print(json.dumps({k:R[k] for k in ['vendors','categories','object_codes','reliable_median_risk']},indent=1,default=float))
print(segsum.round(2)); print(tier.round(2))
for s,l in R['seg_members'].items(): print(s); [print('  ',r) for r in l]
print('bottleneck reliable', len(R['bottleneck_reliable'])); [print('  ',r) for r in R['bottleneck_reliable'][:15]]
