# Full-page dashboard mockups (1600x900 PNG) built from the kit data.
# Layout is defined on Power BI's default 1280 x 720 canvas and rendered at 1.25x,
# so every X / Y / Width / Height below can be typed straight into Power BI
# (Format > General > Properties > Size and position).
import json, pandas as pd, numpy as np, matplotlib, squarify
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.ticker import FuncFormatter, PercentFormatter
import matplotlib.dates as mdates
D='/workspace/powerbi-kit/data/'; OUT='/workspace/powerbi-kit/mockups/'
NAVY='#1F3A5F'; MID='#3E6A9E'; LIGHT='#9DB9D8'; PALE='#EAF1F8'; AMBER='#E3A33B'; TEAL='#5B8C85'; RED='#C0504D'; GREY='#5B6573'
CANVAS='#F2F4F7'; BORDER='#D9DFE7'; GRID='#E6EAF0'
SEGC={'Strategic':NAVY,'Leverage':MID,'Bottleneck':AMBER,'Routine':TEAL}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.spines.top':False,'axes.spines.right':False,
  'axes.edgecolor':'#C8CFD8','axes.labelcolor':GREY,'xtick.color':GREY,'ytick.color':GREY,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'text.parse_math':False})
REPORT_TITLE="Government of Canada Contract Spend | FY'24 to FY'26"
PAGES=['Spend Overview','Spend by Category','Vendor and Competition','Category Segmentation','Pareto 80/20','Supplier Master Data Quality']
SRC=("Source: Government of Canada, Proactive Publication - Contracts (open.canada.ca), Open Government Licence - Canada. Downloaded 6 Oct 2026. "
     "Contracts over $10K awarded Apr 2023 to Mar 2026; values include amendments and taxes.")
LAYOUT={}
def money(v,d=1):
    a=abs(v)
    if a>=1e9: return f'C${v/1e9:,.{d}f}B'
    if a>=1e6: return f'C${v/1e6:,.{d}f}M'
    if a>=1e3: return f'C${v/1e3:,.{d}f}K'
    return f'C${v:,.0f}'
def trunc(s,n): return s if len(s)<=n else s[:n-3].rstrip()+'...'

# ---------------- data ----------------
rd=lambda n,**k: pd.read_csv(D+n,encoding='utf-8-sig',**k)
f=rd('FactContracts.csv'); dd=rd('DimDate.csv'); v=rd('DimVendor.csv',keep_default_na=False,na_values=[''])
dept=rd('DimDepartment.csv'); meth=rd('DimProcurementMethod.csv'); com=rd('DimCommodityType.csv')
cat=rd('DimCategory.csv',dtype={'EconomicObjectCode':str}); cs=rd('DimCategorySegment.csv'); rules=rd('segment_rules.csv')
dups=rd('dq_vendor_duplicates.csv',keep_default_na=False,na_values=['']); dq=rd('dq_rule_summary.csv'); st=rd('dq_vendor_count_stages.csv')
x=(f.merge(dd[['DateKey','MonthStart','FiscalYearShort']],on='DateKey').merge(v[['VendorKey','VendorName','MasterVendorName','IsPotentialDuplicate']],on='VendorKey')
    .merge(dept[['DeptKey','DepartmentName']],on='DeptKey').merge(meth,on='MethodKey').merge(com,on='CommodityTypeCode')
    .merge(cat[['CategoryKey','CategoryGroupKey']],on='CategoryKey').merge(cs[['CategoryGroupKey','CategoryGroup','StandardObject','KraljicSegment','ProcurementTier']],on='CategoryGroupKey'))
x['MonthStart']=pd.to_datetime(x.MonthStart)
TOT=x.ContractValue.sum(); N=len(x)
fy=x.groupby('FiscalYearShort').agg(sp=('ContractValue','sum'),n=('ContractKey','count'))
yoy26=fy.sp["FY'26"]/fy.sp["FY'25"]-1
comm=x.groupby('CommodityType').ContractValue.sum()
masters=x.groupby('MasterVendorName').ContractValue.sum().sort_values(ascending=False)
nc=x[x.IsCompetitive==0]
comp=x[x.IsCompetitive==1]; cb=comp[comp.NumberOfBids.notna()]
single=(cb.NumberOfBids==1).mean()
hhi=((masters/TOT*100)**2).sum()
amend=x.IsAmended.mean(); agrow=x.AmendmentValue.sum()/x.OriginalValue.sum()
active_vendor_records=x.VendorKey.nunique(); duprate=x[x.IsPotentialDuplicate==1].VendorKey.nunique()/active_vendor_records
risk=x[x.IsPotentialDuplicate==1].ContractValue.sum()
catsp=x.groupby('CategoryGroup').agg(sp=('ContractValue','sum'),n=('ContractKey','count')).sort_values('sp',ascending=False)
before=(masters.cumsum()-masters)/TOT; vcls=pd.Series(np.where(before<0.8,'A',np.where(before<0.95,'B','C')),index=masters.index)
cbefore=(catsp.sp.cumsum()-catsp.sp)/TOT; ccls=pd.Series(np.where(cbefore<0.8,'A',np.where(cbefore<0.95,'B','C')),index=catsp.index)
namelen=json.load(open('/workspace/src/namelen.json'))
N=len(x)
K={}  # every number printed on the mockups, for the report / verification

# ---------------- drawing helpers ----------------
def R(x0,y0,w,h): return [x0/1280, 1-(y0+h)/720, w/1280, h/720]
def box(fig,x0,y0,w,h,fc='white',ec=BORDER,lw=0.8,r=0.004):
    l,b,ww,hh=R(x0,y0,w,h)
    fig.patches.append(FancyBboxPatch((l,b),ww,hh,boxstyle=f'round,pad=0,rounding_size={r}',transform=fig.transFigure,fc=fc,ec=ec,lw=lw,zorder=-1))
def T(fig,x0,y0,s,**k): fig.text(x0/1280,1-y0/720,s,**k)
def frame(page):
    fig=plt.figure(figsize=(16,9),dpi=100,facecolor=CANVAS)
    # header band
    fig.patches.append(Rectangle((0,1-44/720),1,44/720,transform=fig.transFigure,fc=NAVY,ec='none'))
    T(fig,16,22,REPORT_TITLE,fontsize=15,fontweight='bold',color='white',va='center')
    T(fig,1264,22,'Data: open.canada.ca  |  refreshed 6 Oct 2026',fontsize=8,color='#C9D6E6',va='center',ha='right')
    # page tabs strip (page navigator)
    fig.patches.append(Rectangle((0,1-70/720),1,26/720,transform=fig.transFigure,fc='#DCE6F1',ec='none'))
    xx=16
    for i,p in enumerate(PAGES):
        w=len(p)*6.1+26
        if i==page:
            fig.patches.append(Rectangle(R(xx,46,w,24)[:2],w/1280,24/720,transform=fig.transFigure,fc=MID,ec='none'))
        T(fig,xx+w/2,58,p,fontsize=8.3,color='white' if i==page else NAVY,ha='center',va='center',fontweight='bold' if i==page else 'normal')
        xx+=w+6
    LAYOUT.setdefault(PAGES[page],[]).extend([('Header band (rectangle + title)',0,0,1280,44),('Page navigator',0,44,1280,26)])
    # slicer bar
    sl=[('Fiscal Year',16,250,['All',"FY'24","FY'25","FY'26"]),('Department',278,330,None),('Commodity type',620,250,None)]
    for name,x0,w,tiles in sl:
        box(fig,x0,78,w,40)
        T(fig,x0+8,87,name,fontsize=7,color=GREY,va='center')
        if tiles:
            tw=(w-16-3*4)/4
            for j,t in enumerate(tiles):
                tx=x0+8+j*(tw+4)
                box(fig,tx,95,tw,17,fc=NAVY if j==0 else 'white',ec=NAVY if j==0 else BORDER,r=0.002)
                T(fig,tx+tw/2,103.5,t,fontsize=7.5,color='white' if j==0 else NAVY,ha='center',va='center')
        else:
            box(fig,x0+8,95,w-16,17,ec=BORDER,r=0.002)
            T(fig,x0+14,103.5,'All',fontsize=7.8,color=NAVY,va='center'); T(fig,x0+w-14,103.5,'\u25be',fontsize=9,color=GREY,va='center',ha='right')
        LAYOUT[PAGES[page]].append((f'Slicer: {name}',x0,78,w,40))
    T(fig,1264,98,'Slicers are synced across all pages',fontsize=7,color=GREY,ha='right',va='center',style='italic')
    # footer
    T(fig,16,709,SRC,fontsize=6.8,color=GREY,va='center')
    T(fig,1264,709,f'Page {page+1} of 6',fontsize=7,color=GREY,va='center',ha='right')
    return fig
def cards(fig,page,items,y0=126,h=70):
    n=len(items); gap=12; w=(1248-gap*(n-1))/n
    for i,(lab,val,sub) in enumerate(items):
        x0=16+i*(w+gap); box(fig,x0,y0,w,h)
        fig.patches.append(Rectangle(R(x0,y0,4,h)[:2],4/1280,h/720,transform=fig.transFigure,fc=NAVY,ec='none'))
        T(fig,x0+12,y0+13,lab,fontsize=7.6,color=GREY,va='center')
        T(fig,x0+12,y0+36,val,fontsize=17 if w>150 else 15.5,color=NAVY,fontweight='bold',va='center')
        if sub: T(fig,x0+12,y0+58,sub,fontsize=6.7,color=GREY,va='center')
        LAYOUT[PAGES[page]].append((f'Card: {lab}',round(x0),y0,round(w),h))
def panel(fig,page,title,x0,y0,w,h,pad=(46,30,14,26),sub=None,axes=True):
    """pad = left, top, right, bottom (canvas units) for the inner axes"""
    box(fig,x0,y0,w,h)
    T(fig,x0+10,y0+12,title,fontsize=9.5,color=NAVY,fontweight='bold',va='center')
    if sub: T(fig,x0+w-10,y0+12,sub,fontsize=6.8,color=GREY,va='center',ha='right')
    T(fig,x0+w-10 if not sub else x0+w-10,y0+12,'',fontsize=7)
    LAYOUT[PAGES[page]].append((f'Visual: {title}',x0,y0,w,h))
    if not axes: return None
    l,t,r,b=pad
    ax=fig.add_axes(R(x0+l,y0+t,w-l-r,h-t-b)); ax.set_facecolor('white')
    return ax
def grid(ax,axis='y'): ax.grid(axis=axis,color=GRID,lw=0.7); ax.set_axisbelow(True)
def table(fig,x0,y0,w,cols,rows,rowh=19,head=20,bar=None,colors=None,fs=7.3):
    """cols: list of (header, width_units, align). bar: (col_index, max) draws a data bar. colors: {col_index: func(value)->color}"""
    xx=x0; 
    fig.patches.append(Rectangle(R(x0,y0,w,head)[:2],w/1280,head/720,transform=fig.transFigure,fc=PALE,ec='none'))
    for hname,cw,al in cols:
        T(fig,xx+(6 if al=='left' else cw-6),y0+head/2,hname,fontsize=fs,fontweight='bold',color=NAVY,va='center',ha=al); xx+=cw
    for i,row in enumerate(rows):
        yy=y0+head+i*rowh; xx=x0
        if i%2==1: fig.patches.append(Rectangle(R(x0,yy,w,rowh)[:2],w/1280,rowh/720,transform=fig.transFigure,fc='#F7F9FB',ec='none'))
        for j,((hname,cw,al),val) in enumerate(zip(cols,row)):
            if bar and j==bar[0]:
                frac=float(val[1])/bar[1]
                fig.patches.append(Rectangle(R(xx+4,yy+4,(cw-8)*frac,rowh-8)[:2],(cw-8)*frac/1280,(rowh-8)/720,transform=fig.transFigure,fc=LIGHT,ec='none'))
                val=val[0]
            c=colors[j](val) if colors and j in colors else '#2B2F36'
            T(fig,xx+(6 if al=='left' else cw-6),yy+rowh/2,str(val),fontsize=fs,color=c,va='center',ha=al,
              fontweight='bold' if (colors and j in colors and c!='#2B2F36') else 'normal'); xx+=cw
        fig.patches.append(Rectangle(R(x0,yy+rowh-0.5,w,0.5)[:2],w/1280,0.5/720,transform=fig.transFigure,fc=GRID,ec='none'))
def save(fig,name): fig.savefig(OUT+name,dpi=100,facecolor=CANVAS); plt.close(fig)
def fybands(ax,months,label=True):
    for i,(fyl,s0) in enumerate([("FY'24",'2023-04-01'),("FY'25",'2024-04-01'),("FY'26",'2025-04-01')]):
        s0=pd.Timestamp(s0); e0=s0+pd.DateOffset(years=1)
        ax.axvspan(s0-pd.Timedelta(days=15),e0-pd.Timedelta(days=15),color=PALE if i%2==0 else 'white',zorder=0)
        if label: ax.text(s0+pd.Timedelta(days=165),0.97,fyl,transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=8,fontweight='bold',color=MID)

# ======================= PAGE 1: Spend Overview =======================
fig=frame(0)
K['Total Spend']=money(TOT); K['Contracts']=f'{N:,}'; K['Active Suppliers']=f'{len(masters):,}'
cards(fig,0,[('Total Spend',money(TOT),'Apr 2023 to Mar 2026'),
            ('Contracts',f'{N:,}','one row per contract'),
            ('Active Suppliers',f'{len(masters):,}','suggested master suppliers'),
            ('Avg Contract Value',money(TOT/N),f'median {money(x.ContractValue.median())}'),
            ('Goods Spend',money(comm['Goods']),f"{comm['Goods']/TOT:.1%} of spend"),
            ('Services Spend',money(comm['Services']),f"{comm['Services']/TOT:.1%} of spend"),
            ('Construction Spend',money(comm['Construction']),f"{comm['Construction']/TOT:.1%} of spend"),
            ("Spend YoY, FY'26",f'{yoy26:+.1%}',f"vs FY'25 ({money(fy.sp[chr(70)+chr(89)+chr(39)+'25'])})"),
            ('Non-Competitive',f'{nc.ContractValue.sum()/TOT:.1%}',f'of spend; {len(nc)/N:.1%} of contracts')])
months=pd.date_range('2023-04-01','2026-03-01',freq='MS')
allm=x.groupby('MonthStart').ContractValue.sum().reindex(months,fill_value=0)
ax=panel(fig,0,"Monthly Spend, FY'24 to FY'26",16,206,816,240,pad=(50,30,16,26),sub='X-axis: MonthStart (Mmm \'YY), Y: Total Spend')
fybands(ax,months); ax.plot(months,allm/1e9,color=NAVY,lw=1.8,marker='o',ms=2.6,zorder=3)
ax.set_ylim(0,25); ax.yaxis.set_major_formatter(FuncFormatter(lambda y,_:f'C${y:.0f}B')); grid(ax)
for mth,val in allm.nlargest(3).items():
    lc=x[x.MonthStart==mth].nlargest(1,'ContractValue').iloc[0]
    nm=lc.MasterVendorName; nm=nm.title() if nm.isupper() else nm
    nm=trunc(nm.replace(' Limited Partnership','').replace(' Ltd','').replace(' Inc.',''),24)
    ax.annotate(f"{mth:%b '%y}: {money(val)}\n({nm} {money(lc.ContractValue)})",(mth,val/1e9),xytext=(7,-2),textcoords='offset points',fontsize=6.8,color=NAVY,va='top',
                bbox=dict(boxstyle='round,pad=0.25',fc='white',ec=LIGHT,lw=0.6),zorder=5)
ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1,4,7,10])); ax.xaxis.set_major_formatter(mdates.DateFormatter("%b '%y"))
ax.set_xlim(months[0]-pd.Timedelta(days=20),months[-1]+pd.Timedelta(days=20))
ax=panel(fig,0,'Spend by Fiscal Year',844,206,420,240,pad=(46,34,14,40),sub='Column chart: FiscalYearShort')
b=ax.bar(fy.index,fy.sp/1e9,color=[LIGHT,NAVY,MID],width=0.55)
for i,(lab,r0) in enumerate(fy.iterrows()):
    ax.text(i,r0.sp/1e9+0.8,money(r0.sp),ha='center',fontsize=8.5,fontweight='bold',color=NAVY)
    if i>0:
        ch=r0.sp/fy.sp.iloc[i-1]-1; ax.text(i,r0.sp/1e9/2,f'{ch:+.1%}\nvs prior FY',ha='center',va='center',fontsize=7,color='white',fontweight='bold')
    ax.text(i,-0.13,f'{int(r0.n):,} contracts',transform=ax.get_xaxis_transform(),ha='center',fontsize=6.8,color=GREY)
ax.set_ylim(0,fy.sp.max()/1e9*1.2); ax.yaxis.set_major_formatter(FuncFormatter(lambda y,_:f'C${y:.0f}B')); grid(ax); ax.tick_params(axis='x',labelsize=8.5)
K['FY spend']={k:money(v) for k,v in fy.sp.items()}
dp=x.groupby('DepartmentName').ContractValue.sum().nlargest(10).iloc[::-1]
ax=panel(fig,0,'Top 10 Departments by Spend',16,454,816,240,pad=(250,28,60,22),sub='Bar chart: DepartmentName, Top N 10')
b=ax.barh([trunc(d,44) for d in dp.index],dp.values/1e9,color=MID,height=0.68); b[-1].set_color(NAVY)
for r0,val in zip(b,dp.values): ax.text(r0.get_width()+0.3,r0.get_y()+r0.get_height()/2,f'{money(val)}  ({val/TOT:.1%})',va='center',fontsize=7,color=GREY)
ax.set_xlim(0,dp.max()/1e9*1.22); ax.xaxis.set_major_formatter(FuncFormatter(lambda y,_:f'C${y:.0f}B')); grid(ax,'x'); ax.tick_params(axis='y',labelsize=7.3)
K['Top dept']=(dp.index[-1],money(dp.iloc[-1]),f'{dp.iloc[-1]/TOT:.1%}')
ax=panel(fig,0,'Spend by Commodity Type',844,454,420,240,pad=(10,26,150,10),sub='Donut: CommodityType')
order=['Services','Goods','Construction']; cols3=[NAVY,MID,AMBER]
ax.pie([comm[o] for o in order],colors=cols3,startangle=90,counterclock=False,wedgeprops=dict(width=0.36,edgecolor='white',lw=1.5))
ax.text(0,0.08,money(TOT),ha='center',va='center',fontsize=12,fontweight='bold',color=NAVY); ax.text(0,-0.16,'total spend',ha='center',va='center',fontsize=7,color=GREY)
ax.set_aspect('equal')
for i,o in enumerate(order):
    yy=530+i*42
    fig.patches.append(Rectangle(R(1124,yy,10,10)[:2],10/1280,10/720,transform=fig.transFigure,fc=cols3[i],ec='none'))
    T(fig,1140,yy+5,o,fontsize=8.3,color=NAVY,fontweight='bold',va='center')
    T(fig,1140,yy+20,f'{money(comm[o])}  |  {comm[o]/TOT:.1%}',fontsize=7.5,color=GREY,va='center')
save(fig,'01_spend_overview.png')

# ======================= PAGE 2: Spend by Category =======================
fig=frame(1)
nA=int((ccls=='A').sum())
cards(fig,1,[('Total Spend',money(TOT),f'{N:,} contracts'),
            ('Category Groups',f'{len(catsp)}',f"{cs.StandardObject.nunique()} standard objects (top-level rollup)"),
            ('Top Category Share',f'{catsp.sp.iloc[0]/TOT:.1%}',f'Aircraft and ships, {money(catsp.sp.iloc[0])}'),
            ('Top 15 Categories Share',f'{catsp.sp.head(15).sum()/TOT:.1%}',f'of spend in 15 of {len(catsp)} groups'),
            ('Groups Making 80% of Spend',f'{nA}',f'{nA/len(catsp):.1%} of category groups (Pareto class A)')])
t15=catsp.head(15).iloc[::-1]
ax=panel(fig,1,'Spend by Category Group (top 15)',16,206,1248,268,pad=(330,28,40,20),sub='Bar chart: CategoryGroup by Total Spend, Top N 15 (optional page filter can exclude "Unmapped object code")')
segcol=cs.set_index('CategoryGroup').KraljicSegment
b=ax.barh([trunc(n,60) for n in t15.index],t15.sp/1e9,color=NAVY,height=0.7)
for r0,(nm,row) in zip(b,t15.iterrows()):
    ax.text(r0.get_width()+0.2,r0.get_y()+r0.get_height()/2,f'{money(row.sp)}  |  {row.sp/TOT:.1%}  |  {int(row.n):,} contracts',va='center',fontsize=7,color=GREY)
ax.set_xlim(0,t15.sp.max()/1e9*1.25); ax.xaxis.set_major_formatter(FuncFormatter(lambda y,_:f'C${y:.0f}B')); grid(ax,'x'); ax.tick_params(axis='y',labelsize=7.2)
ax=panel(fig,1,'Treemap: Standard Object > Category Group',16,482,1248,212,pad=(10,26,10,8),sub='Treemap: StandardObject > CategoryGroup')
so=x.groupby('StandardObject').ContractValue.sum().sort_values(ascending=False)
topso=list(so.index[:4]); socol=dict(zip(topso,[NAVY,MID,TEAL,AMBER]))
tm=x.groupby(['StandardObject','CategoryGroup']).ContractValue.sum().reset_index()
tm['so']=np.where(tm.StandardObject.isin(topso),tm.StandardObject,'Other standard objects')
tm=tm.sort_values('ContractValue',ascending=False)
keep=tm.head(24); rest=tm.iloc[24:]
items=[(r0.so,r0.CategoryGroup,r0.ContractValue) for r0 in keep.itertuples()]+[('Other standard objects',f'{len(rest)} smaller groups',rest.ContractValue.sum())]
sop=['Other standard objects']+topso[::-1]
items=sorted(items,key=lambda t:(-[i for i,_ in enumerate(topso+['Other standard objects']) if _==t[0]][0],t[2]),reverse=True)
items=sorted(items,key=lambda t:((topso+['Other standard objects']).index(t[0]),-t[2]))
W,H=1228,178
vals=squarify.normalize_sizes([i[2] for i in items],W,H); rects=squarify.squarify(vals,0,0,W,H)
ax.set_xlim(0,W); ax.set_ylim(H,0); ax.axis('off')
for (s_,nm,val),rc in zip(items,rects):
    colr=socol.get(s_,'#8C96A3')
    ax.add_patch(Rectangle((rc['x'],rc['y']),rc['dx'],rc['dy'],fc=colr,ec='white',lw=1.2,alpha=0.92))
    if rc['dx']>60 and rc['dy']>22:
        mx=int(rc['dx']/5.6)
        ax.text(rc['x']+4,rc['y']+4,trunc(nm,mx),fontsize=7 if rc['dx']>120 else 6.2,color='white',va='top',fontweight='bold')
        ax.text(rc['x']+4,rc['y']+16,f'{money(val)} ({val/TOT:.1%})',fontsize=6.5,color='white',va='top')
lx=16+10; ly=488
for s_ in topso+['Other standard objects']:
    pass
leg=' '.join([])
SOSHORT={'SO 09':'Machinery and equipment','SO 04':'Professional and special services','SO 06':'Repair and maintenance','SO 05':'Rentals'}
legend_items=[(SOSHORT.get(s_[:5],trunc(s_,26))+f' {so[s_]/TOT:.1%}',socol[s_]) for s_ in topso]+[('Other standard objects','#8C96A3')]
xx=330
for lab,colr in legend_items:
    fig.patches.append(Rectangle(R(xx,490,9,9)[:2],9/1280,9/720,transform=fig.transFigure,fc=colr,ec='none'))
    T(fig,xx+12,494.5,lab,fontsize=6.6,color=GREY,va='center'); xx+=len(lab)*4.4+28
save(fig,'02_spend_by_category.png')
K['SO shares']={s_:f'{so[s_]/TOT:.1%}' for s_ in topso}

# ======================= PAGE 3: Vendor and Competition =======================
fig=frame(2)
top10=masters.head(10)
cards(fig,2,[('Top 10 Supplier Share',f'{top10.sum()/TOT:.1%}',f'{money(top10.sum())} of {money(TOT)}'),
            ('Supplier HHI',f'{hhi:,.0f}','government-wide; DFO 3,178'),
            ('Non-Competitive Spend',f'{nc.ContractValue.sum()/TOT:.1%}',f'{len(nc)/N:.1%} of contracts'),
            ('Single-Bid Rate',f'{single:.1%}','competitive contracts reporting bids'),
            ('Amendment Rate',f'{amend:.1%}','of contracts amended after award'),
            ('Amendment Value Growth',f'{agrow:.1%}',f'{money(x.AmendmentValue.sum())} added after award')])
ax=panel(fig,2,'Top 10 Suppliers by Spend',16,206,616,488,pad=(230,30,70,24),sub='Bar: MasterVendorName, Top N 10')
t=top10.iloc[::-1]
b=ax.barh([trunc(n,38) for n in t.index],t.values/1e9,color=MID,height=0.66); b[-1].set_color(NAVY)
for r0,val in zip(b,t.values): ax.text(r0.get_width()+0.15,r0.get_y()+r0.get_height()/2,f'{money(val)}\n{val/TOT:.1%}',va='center',fontsize=7,color=GREY)
ax.set_xlim(0,t.max()/1e9*1.25); ax.xaxis.set_major_formatter(FuncFormatter(lambda y,_:f'C${y:.0f}B')); grid(ax,'x'); ax.tick_params(axis='y',labelsize=7.4)
pm=x.groupby('ProcurementMethod').agg(sp=('ContractValue','sum'),n=('ContractKey','count')).sort_values('sp')
ax=panel(fig,2,'Spend by Procurement Method',644,206,620,240,pad=(214,30,96,24),sub='Bar: ProcurementMethod; label = contracts')
colm=[NAVY if 'Competitive -' in i else (AMBER if 'Non' in i or 'Advance' in i else '#8C96A3') for i in pm.index]
b=ax.barh([trunc(i,40) for i in pm.index],pm.sp/1e9,color=colm,height=0.62)
for r0,(nm,row) in zip(b,pm.iterrows()): ax.text(r0.get_width()+0.4,r0.get_y()+r0.get_height()/2,f'{money(row.sp)} | {int(row.n):,} contracts',va='center',fontsize=6.8,color=GREY)
ax.set_xlim(0,pm.sp.max()/1e9*1.45); ax.xaxis.set_major_formatter(FuncFormatter(lambda y,_:f'C${y:.0f}B')); grid(ax,'x'); ax.tick_params(axis='y',labelsize=7.2)
cy=x.groupby(['FiscalYearShort','CompetitionType']).ContractValue.sum().unstack(fill_value=0)
cy=cy.div(cy.sum(axis=1),axis=0)
ax=panel(fig,2,'Competitive vs Non-Competitive Spend by Year',644,454,620,240,pad=(46,46,150,24),sub='100% stacked column: Legend = CompetitionType')
order=[c_ for c_ in ['Competitive','Non-competitive','Non-competitive (ACAN)','Not reported'] if c_ in cy.columns]
cc_={'Competitive':NAVY,'Non-competitive':AMBER,'Non-competitive (ACAN)':'#F0C987','Not reported':'#B8C0CA'}
bot=np.zeros(len(cy))
for o in order:
    ax.bar(cy.index,cy[o],bottom=bot,color=cc_[o],width=0.55,label=o)
    for i,(vv,bb) in enumerate(zip(cy[o],bot)):
        if vv>0.05: ax.text(i,bb+vv/2,f'{vv:.1%}',ha='center',va='center',fontsize=7.3,color='white',fontweight='bold')
    bot+=cy[o].values
ax.yaxis.set_major_formatter(PercentFormatter(1.0)); ax.set_ylim(0,1); ax.tick_params(axis='x',labelsize=8.5)
ax.legend(frameon=False,fontsize=7,loc='center left',bbox_to_anchor=(1.02,0.5))
K['Comp by year']=cy.round(3).to_dict()
save(fig,'03_vendor_competition.png')

# ======================= PAGE 4: Category Segmentation =======================
fig=frame(3)
seg=x.groupby('KraljicSegment').agg(sp=('ContractValue','sum'),n=('ContractKey','count'))
tier=x.groupby('ProcurementTier').ContractValue.sum()
gcount=cs.KraljicSegment.value_counts()
cards(fig,3,[('Strategic Tier',f"{tier['Strategic']/TOT:.1%}",f"{gcount['Strategic']} groups, {money(tier['Strategic'])}"),
            ('Tactical Tier',f"{tier['Tactical']/TOT:.1%}",f"{gcount['Leverage']+gcount['Bottleneck']} groups (Leverage {gcount['Leverage']} + Bottleneck {gcount['Bottleneck']})"),
            ('Operational Tier',f"{tier['Operational']/TOT:.1%}",f"{gcount['Routine']} groups, {money(tier['Operational'])}"),
            ('High-Risk Threshold','25','Supply Risk Score; analyst-defined'),
            ('Low-Confidence Groups',f'{int(cs.LowDataConfidence.sum())}','fewer than 30 contracts; hollow dots')])
k=cs[cs.CategorySpend>0].copy()
aMin=k.loc[k.CategoryParetoClass=='A','CategorySpend'].min(); bMax=k.loc[k.CategoryParetoClass!='A','CategorySpend'].max(); xcut=np.sqrt(aMin*bMax)
ax=panel(fig,3,'Spend vs Supply Risk (Kraljic 2x2)',16,206,760,488,pad=(52,40,16,40),sub='Scatter: X = Total Spend (log), Y = Category Supply Risk Score, Size = Contract Count')
ax.set_xscale('log'); ax.set_xlim(1e4,2e11); ax.set_ylim(0,104)
ax.fill_between([xcut,2e11],25,104,color=PALE,zorder=0)
ax.axvline(xcut,color=GREY,ls='--',lw=0.9); ax.axhline(25,color=GREY,ls='--',lw=0.9)
for s_,col in SEGC.items():
    d=k[k.KraljicSegment==s_]; rel=d[d.LowDataConfidence==0]; low=d[d.LowDataConfidence==1]
    sz=lambda q:12+np.sqrt(q.ContractCount)*2.6
    ax.scatter(rel.CategorySpend,rel.SupplyRiskScore,s=sz(rel),color=col,alpha=0.85,edgecolor='white',lw=0.6,zorder=3,label=s_)
    ax.scatter(low.CategorySpend,low.SupplyRiskScore,s=sz(low),facecolor='none',edgecolor=col,lw=1,zorder=3)
LBL={'Other services':('Other services',1.6e10,50,'left'),
 'Repair and maintenance - Machinery and equipment':('R&M machinery and equipment',5e9,66,'center'),
 'Rental of informatics equipment':('Rental of informatics equipment',5e8,50,'right'),
 'Arms and ammunition':('Arms and ammunition',5e8,42,'right'),
 'Acquisition of aircraft and ships, including parts':('Aircraft and ships',6e10,16,'center'),
 'Engineering and architectural services':('Engineering and architectural',1.4e10,7,'right'),
 'Informatics services':('Informatics services',1.6e10,13,'left')}
for r0 in k[k.CategoryGroup.isin(LBL)].itertuples():
    nm,tx,ty,ha=LBL[r0.CategoryGroup]
    ax.annotate(nm,(r0.CategorySpend,r0.SupplyRiskScore),xytext=(tx,ty),textcoords='data',ha=ha,va='center',fontsize=6.8,color=NAVY,zorder=6,
                bbox=dict(boxstyle='round,pad=0.15',fc='white',ec='none',alpha=0.8),arrowprops=dict(arrowstyle='-',color=GREY,lw=0.6))
qs=dict(fontsize=10,fontweight='bold',alpha=0.9)
ax.text(1.8e11,101,'STRATEGIC\n(Strategic tier)',color=NAVY,ha='right',va='top',**qs)
ax.text(1.8e11,2,'LEVERAGE\n(Tactical tier)',color=MID,ha='right',va='bottom',**qs)
ax.text(3e5,101,'BOTTLENECK\n(Tactical tier)',color=AMBER,ha='center',va='top',**qs)
ax.text(3e5,2,'ROUTINE\n(Operational tier)',color=TEAL,ha='center',va='bottom',**qs)
ax.xaxis.set_major_formatter(FuncFormatter(lambda vv,_:money(vv,0) if vv>=1e6 else f'C${vv/1e3:,.0f}K'))
ax.set_xlabel('Category spend (log scale); dashed line = C$1.8B',fontsize=7); ax.set_ylabel('Supply Risk Score (0 to 100)',fontsize=7)
ax.legend(frameon=False,loc='lower left',ncol=4,bbox_to_anchor=(0,1.0),fontsize=7)
panel(fig,3,'Segment Summary',788,206,476,226,axes=False,sub='Matrix: ProcurementTier > KraljicSegment')
rows=[]
for s_,tr in [('Strategic','Strategic'),('Leverage','Tactical'),('Bottleneck','Tactical'),('Routine','Operational')]:
    rows.append([tr,s_,f'{gcount[s_]}',money(seg.sp[s_]),f'{seg.sp[s_]/TOT:.1%}',f'{seg.n[s_]/N:.1%}'])
rows.append(['Total','',f'{len(cs)}',money(TOT),'100.0%','100.0%'])
table(fig,796,236,460,[('Tier',86,'left'),('Segment',92,'left'),('Groups',58,'right'),('Spend',80,'right'),('% Spend',72,'right'),('% Contracts',72,'right')],rows,rowh=26,head=24,
      colors={1:lambda s_:SEGC.get(s_,'#2B2F36')},fs=7.8)
T(fig,796,410,"Strategic = class A spend + risk 25 or more. Tactical = Leverage + Bottleneck.",fontsize=6.8,color=GREY,va='center')
T(fig,796,423,'Thresholds are analyst-defined assumptions, not official classifications.',fontsize=6.8,color=RED,va='center',style='italic')
panel(fig,3,'Segment Rules and Typical Approach',788,440,476,254,axes=False,sub='Table: segment_rules')
import textwrap
rr=[]
shortrule={'Strategic':'Class A spend; risk >= 25','Leverage':'Class A spend; risk < 25','Bottleneck':'Not class A; risk >= 25','Routine':'Not class A; risk < 25'}
yy=468
fig.patches.append(Rectangle(R(796,yy,460,22)[:2],460/1280,22/720,transform=fig.transFigure,fc=PALE,ec='none'))
for hx,hn in [(802,'Segment'),(880,'Rule'),(1030,'Typical approach')]: T(fig,hx,yy+11,hn,fontsize=7.6,fontweight='bold',color=NAVY,va='center')
yy+=22
for r0 in rules.itertuples():
    T(fig,802,yy+10,r0.KraljicSegment,fontsize=7.6,color=SEGC[r0.KraljicSegment],fontweight='bold',va='top')
    T(fig,802,yy+22,f'({r0.ProcurementTier})',fontsize=6.6,color=GREY,va='top')
    T(fig,880,yy+10,shortrule[r0.KraljicSegment],fontsize=7.2,color='#2B2F36',va='top')
    T(fig,1030,yy+10,'\n'.join(textwrap.wrap(r0.TypicalApproach,40)),fontsize=7,color='#2B2F36',va='top',linespacing=1.3)
    yy+=48
    fig.patches.append(Rectangle(R(796,yy-1,460,0.6)[:2],460/1280,0.6/720,transform=fig.transFigure,fc=GRID,ec='none'))
save(fig,'04_category_segmentation.png')
K['Tier']={t_:f'{tier[t_]/TOT:.1%}' for t_ in tier.index}

# ======================= PAGE 5: Pareto 80/20 =======================
fig=frame(4)
vc=vcls.value_counts(); vs=masters.groupby(vcls).sum()
n50=int(((masters.cumsum()-masters)/TOT<0.5).sum())
cs_sp=catsp.sp.groupby(ccls).sum(); cc_n=ccls.value_counts()
cards(fig,4,[('Class A Suppliers',f"{vc['A']:,}",f"{vc['A']/len(masters):.2%} of suppliers = {vs['A']/TOT:.1%} of spend"),
            ('Class B Suppliers',f"{vc['B']:,}",f"{vc['B']/len(masters):.1%} of suppliers = {vs['B']/TOT:.1%} of spend"),
            ('Class C Suppliers',f"{vc['C']:,}",f"{vc['C']/len(masters):.1%} of suppliers = {vs['C']/TOT:.1%} of spend"),
            ('Suppliers Making Half of Spend',f'{n50}',f'out of {len(masters):,} suppliers'),
            ('Class A Category Groups',f"{cc_n['A']} of {len(catsp)}",f"{cc_n['A']/len(catsp):.1%} of groups = {cs_sp['A']/TOT:.1%} of spend")])
SHOW=400; cum=masters.cumsum()/TOT; n80=int(vc['A'])
ax=panel(fig,4,'Supplier Pareto (top 400 of 38,370)',16,206,616,330,pad=(54,30,52,34),sub='Line and column: VendorParetoRank <= 400')
rk=np.arange(1,SHOW+1)
ax.bar(rk,masters.values[:SHOW]/1e9,width=1.0,color=[NAVY if i<=n80 else LIGHT for i in rk])
ax.set_yscale('log'); ax.yaxis.set_major_formatter(FuncFormatter(lambda y,_:f'C${y:g}B')); ax.set_xlabel('Supplier rank by spend',fontsize=7); ax.set_xlim(0,SHOW+1)
a2=ax.twinx(); a2.plot(rk,cum.values[:SHOW],color=AMBER,lw=2); a2.set_ylim(0,1.02); a2.yaxis.set_major_formatter(PercentFormatter(1.0,decimals=0)); a2.spines['top'].set_visible(False)
a2.axhline(0.8,color=RED,ls='--',lw=1); a2.text(SHOW,0.815,'80%',color=RED,ha='right',fontsize=7.5)
a2.axvline(n80,color=GREY,ls=':',lw=0.9); a2.annotate(f'Rank {n80}: 80% reached',(n80,0.8),xytext=(14,-48),textcoords='offset points',fontsize=7.3,color=NAVY,arrowprops=dict(arrowstyle='->',color=GREY,lw=0.8))
a2.tick_params(labelsize=7.5)
SH=25; ccum=catsp.sp.cumsum()/TOT
ax=panel(fig,4,'Category Pareto (top 25 of 85 groups)',644,206,620,330,pad=(50,30,46,112),sub='Line and column: CategoryGroup, sorted by spend')
ax.bar(range(SH),catsp.sp.values[:SH]/1e9,color=[NAVY if c_=='A' else (LIGHT if c_=='B' else '#C9D1DB') for c_ in ccls.values[:SH]])
ax.set_xticks(range(SH)); ax.set_xticklabels([trunc(nm,30) for nm in catsp.index[:SH]],rotation=60,ha='right',fontsize=6)
ax.yaxis.set_major_formatter(FuncFormatter(lambda y,_:f'C${y:.0f}B'))
a2=ax.twinx(); a2.plot(range(SH),ccum.values[:SH],color=AMBER,lw=2,marker='o',ms=2.5); a2.set_ylim(0,1.02); a2.yaxis.set_major_formatter(PercentFormatter(1.0,decimals=0)); a2.spines['top'].set_visible(False)
a2.axhline(0.8,color=RED,ls='--',lw=1); a2.text(SH-0.5,0.815,'80%',color=RED,ha='right',fontsize=7.5); a2.tick_params(labelsize=7.5)
panel(fig,4,'Supplier ABC Summary',16,544,616,150,axes=False,sub='Matrix: VendorParetoClass')
rows=[[c_,f'{vc[c_]:,}',f'{vc[c_]/len(masters):.2%}' if vc[c_]/len(masters)<0.01 else f'{vc[c_]/len(masters):.1%}',money(vs[c_]),f'{vs[c_]/TOT:.1%}'] for c_ in 'ABC']+[['Total',f'{len(masters):,}','100.0%',money(TOT),'100.0%']]
table(fig,24,572,600,[('Class',150,'left'),('Suppliers',110,'right'),('% of suppliers',120,'right'),('Spend',110,'right'),('% of spend',110,'right')],rows,rowh=22,head=22,fs=7.8,
      colors={0:lambda s_:{'A':NAVY,'B':MID,'C':GREY}.get(s_,'#2B2F36')})
panel(fig,4,'Category ABC Summary',644,544,620,150,axes=False,sub='Matrix: CategoryParetoClass')
rows=[[c_,f'{cc_n[c_]}',f'{cc_n[c_]/len(catsp):.1%}',money(cs_sp[c_]),f'{cs_sp[c_]/TOT:.1%}'] for c_ in 'ABC']+[['Total',f'{len(catsp)}','100.0%',money(TOT),'100.0%']]
table(fig,652,572,604,[('Class',150,'left'),('Groups',110,'right'),('% of groups',124,'right'),('Spend',110,'right'),('% of spend',110,'right')],rows,rowh=22,head=22,fs=7.8,
      colors={0:lambda s_:{'A':NAVY,'B':MID,'C':GREY}.get(s_,'#2B2F36')})
T(fig,24,690-0,'',fontsize=6)
save(fig,'05_pareto.png')
K['Pareto']=dict(A=int(vc['A']),B=int(vc['B']),C=int(vc['C']),n50=n50,catA=int(cc_n['A']),catB=int(cc_n['B']),catC=int(cc_n['C']),catAshare=f"{cs_sp['A']/TOT:.1%}")

# ======================= PAGE 6: Supplier Master Data Quality =======================
fig=frame(5)
raw=int(st.VendorCount.iloc[0]); final=int(st.VendorCount.iloc[-1])
cards(fig,5,[('Raw Vendor Names',f'{raw:,}','distinct spellings as published'),
            ('Suggested Master Suppliers',f'{final:,}',f'{1-final/raw:.1%} fewer after clean-up'),
            ('Duplicate Vendor Rate',f'{duprate:.1%}','of active vendor records'),
            ('Spend Tied to Duplicates',money(risk),f'{risk/TOT:.1%} of all spend'),
            ('Names Cut at 35 Characters',f"{namelen['35']:,}",f"vs {namelen['36']:,} names at 36 characters")])
panel(fig,5,'Vendor Clean-up Funnel',16,206,400,240,axes=False,sub='Funnel: Stage, VendorCount')
labs=['Raw names (as published)','After trim, spacing, case','After accents, punctuation, suffixes','After fuzzy clustering']
fc_=[AMBER,LIGHT,MID,NAVY]
for i,(lab,val) in enumerate(zip(labs,st.VendorCount)):
    w=330*val/raw; yy=236+i*51
    box(fig,216-w/2,yy,w,34,fc=fc_[i],ec='none',r=0.002)
    T(fig,216,yy+12,f'{val:,}',fontsize=10,fontweight='bold',color='white' if i else NAVY,ha='center',va='center')
    T(fig,216,yy+26,f'{lab}  |  {val/raw:.0%}',fontsize=6.6,color='white' if i else NAVY,ha='center',va='center')
panel(fig,5,'Duplicate Cluster Sample (suggested master and its variants)',428,206,836,240,axes=False,sub='Table: dq_vendor_duplicates, FuzzyClusterId > 0')
smp=pd.concat([dups[dups.FuzzyClusterId==3].nlargest(5,'Spend'),dups[dups.FuzzyClusterId==4].nlargest(3,'Spend')])
rows=[[int(r0.FuzzyClusterId),trunc(r0.MasterVendorName,52),trunc(r0.VendorName,60),f'{r0.SimilarityToMaster:.1f}',f'{int(r0.ContractCount):,}',money(r0.Spend)] for r0 in smp.itertuples()]
table(fig,436,234,820,[('Cluster',56,'right'),('MasterVendorName',250,'left'),('VendorName (variant record)',300,'left'),('Similarity',72,'right'),('Contracts',68,'right'),('Spend',74,'right')],rows,rowh=21,head=22,fs=7.2)
gd=dups[dups.FuzzyClusterId==3]; cm=dups[dups.FuzzyClusterId==4]
T(fig,436,436,f'Cluster 3 has {len(gd)} records worth {money(gd.Spend.sum())}; cluster 4 has {len(cm)} records worth {money(cm.Spend.sum())}. Showing the largest variants only.',fontsize=6.8,color=GREY,va='center',style='italic')
panel(fig,5,'Data-Quality Rules (8 of 21, highest failure rate first)',16,454,1248,240,axes=False,sub='Table: dq_rule_summary; data bars on PctFailed, font colour on Severity')
dqs=dq.sort_values('PctFailed',ascending=False).head(8)
rows=[[r0.RuleId,trunc(r0.Rule,92),f'{int(r0.RecordsChecked):,}',f'{int(r0.RecordsFailed):,}',(f'{r0.PctFailed:.1f}%',r0.PctFailed),money(r0.SpendAffected) if pd.notna(r0.SpendAffected) else '',r0.Severity] for r0 in dqs.itertuples()]
table(fig,24,482,1232,[('RuleId',54,'left'),('Rule',560,'left'),('Records checked',110,'right'),('Records failed',104,'right'),('% failed',170,'left'),('Spend affected',124,'right'),('Severity',110,'left')],rows,rowh=24,head=24,
      bar=(4,dq.PctFailed.max()),colors={6:lambda s_:{'High':RED,'Medium':AMBER}.get(s_,GREY)},fs=7.4)
save(fig,'06_supplier_data_quality.png')
K['DQ']=dict(raw=raw,final=final,duprate=f'{duprate:.1%}',risk=money(risk),n35=namelen['35'],n36=namelen['36'])

# ======================= contact sheet =======================
from PIL import Image, ImageDraw, ImageFont
names=['01_spend_overview.png','02_spend_by_category.png','03_vendor_competition.png','04_category_segmentation.png','05_pareto.png','06_supplier_data_quality.png']
TW,TH=800,450; G=24; top=90
sheet=Image.new('RGB',(3*TW+4*G,top+2*(TH+44)+G+30),'#E9EDF2')
dr=ImageDraw.Draw(sheet)
fb=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',30); fr=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
dr.rectangle([0,0,sheet.width,70],fill=NAVY)
dr.text((G,18),REPORT_TITLE+'  |  all 6 report pages',font=fb,fill='white')
for i,n in enumerate(names):
    im=Image.open(OUT+n).convert('RGB').resize((TW,TH),Image.LANCZOS)
    cx=G+(i%3)*(TW+G); cy=top+(i//3)*(TH+44)
    dr.text((cx,cy),f'Page {i+1}: {PAGES[i]}',font=fr,fill=NAVY)
    sheet.paste(im,(cx,cy+28)); dr.rectangle([cx-1,cy+27,cx+TW,cy+28+TH],outline='#B8C2CE')
dr.text((G,sheet.height-34),'Mockups built from the kit data (Government of Canada Proactive Publication - Contracts, Open Government Licence - Canada). Layout applies to the Power BI and Tableau versions.',font=fr,fill=GREY)
sheet.save(OUT+'00_all_pages.png')
json.dump({p:[list(map(lambda z:z if isinstance(z,str) else int(round(z)),r)) for r in rows_] for p,rows_ in LAYOUT.items()},open('/workspace/src/mockup_layout.json','w'),indent=1)
json.dump(K,open('/workspace/src/mockup_numbers.json','w'),indent=1,default=str)
print('mockups ok'); print(json.dumps(K,indent=1,default=str))
