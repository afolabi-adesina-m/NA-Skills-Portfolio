import pandas as pd, numpy as np, re, json, unicodedata
from unidecode import unidecode
from rapidfuzz import fuzz, process
from collections import defaultdict

OUT='/workspace/powerbi-kit/data'
schema=json.load(open('/workspace/src/contracts_schema.json'))
F={f['id']:f for f in schema['resources'][0]['fields']}
def label(field,code):
    ch=F[field].get('choices',{})
    v=ch.get(code)
    return v.get('en') if isinstance(v,dict) else (v if v else None)

raw=pd.read_parquet('/workspace/src/recent.parquet')
raw=raw.reset_index().rename(columns={'index':'src_row'})
raw=raw[raw.instrument_type!='SOSA'].copy()
raw['key']=raw.owner_org+'|'+raw.procurement_id
raw['cdate']=pd.to_datetime(raw.contract_date,errors='coerce')
raw['val']=pd.to_numeric(raw.contract_value,errors='coerce')
raw['orig']=pd.to_numeric(raw.original_value,errors='coerce')
raw['amd']=pd.to_numeric(raw.amendment_value,errors='coerce')

C=raw[(raw.instrument_type=='C')&(raw.cdate>='2023-04-01')&(raw.cdate<='2026-03-31')]
inkeys=set(C.key)
scope=raw[raw.key.isin(inkeys)].copy()   # all C and A disclosure rows of in-scope contracts
scope=scope.sort_values(['key','reporting_period','cdate','src_row'])
firstC=C.sort_values(['key','cdate','src_row']).groupby('key').head(1).set_index('key')
latest=scope.groupby('key').tail(1).set_index('key')
amdcnt=scope[scope.instrument_type=='A'].groupby('key').size()
nrec=scope.groupby('key').size()

# ---------- vendor normalization ----------
SUFFIX={'INC','INCORPORATED','INCORPOREE','LTD','LTEE','LIMITED','LIMITEE','CORP','CORPORATION','CO','COMPANY','LLC','LLP','LP','ULC','PLC','GMBH','SA','SAS','SARL','AG','BV','NV','ENR','SENC','SENCRL','SRL','SPA','AB','AS','OY','PTY','PC','PLLC','CIE','LTDA','SE','KG','INCORP'}
def basic(s):  # stage 1: trim, collapse spaces, upper
    return re.sub(r'\s+',' ',s.strip()).upper()
def norm(s):   # stage 2: accents, punctuation, & -> AND, legal suffixes, leading THE
    s=s.split(' / ')[0] if ' / ' in s else s
    s=unidecode(s).upper().replace('&',' AND ')
    s=re.sub(r"[\.'`’]",'',s)          # drop dots/apostrophes (I.B.M. -> IBM)
    s=re.sub(r'[^A-Z0-9 ]',' ',s)
    toks=s.split()
    while toks and toks[-1] in SUFFIX: toks.pop()
    while len(toks)>1 and toks[0]=='THE': toks.pop(0)
    while len(toks)>1 and toks[-1] in ('AND',): toks.pop()
    out=' '.join(toks)
    return out if out else basic(s)

names=pd.DataFrame({'raw':scope.vendor_name.unique()})
names['basic']=names.raw.map(basic)
names['norm']=names.raw.map(norm)
counts={'raw_distinct':names.raw.nunique(),'after_trim_case':names.basic.nunique(),'after_full_normalization':names.norm.nunique()}

# vendor-level aggregation (on normalized name) across all scope rows
scope['norm']=scope.vendor_name.map(dict(zip(names.raw,names.norm)))
fact_vendor_raw=firstC.vendor_name  # vendor on original award
# per normalized vendor
vg=scope.groupby('norm')
def mode(s):
    s=s[(s!='')]
    return s.mode().iloc[0] if len(s) else ''
vend=pd.DataFrame({
  'RawVariantCount':vg.vendor_name.nunique(),
  'RawVariants':vg.vendor_name.agg(lambda s:' | '.join(sorted(set(x.strip() for x in s)))[:400]),
  'DisplayName':vg.vendor_name.agg(lambda s:s.str.strip().value_counts().index[0]),
  'CountryCode':vg.country_of_vendor.agg(mode),
  'CountryCodeCount':vg.country_of_vendor.agg(lambda s:s[s!=''].nunique()),
  'PostalFSA':vg.vendor_postal_code.agg(lambda s:mode(s.str.strip().str.upper())),
  'PostalFSACount':vg.vendor_postal_code.agg(lambda s:s[(s.str.strip()!='')&(s.str.upper()!='NA')].str.strip().str.upper().nunique()),
}).reset_index().rename(columns={'norm':'NormalizedName'})

# ---------- fuzzy matching (blocked by first 3 chars) ----------
vn=vend.NormalizedName.tolist()
digits=[re.sub(r'\D','',x) for x in vn]
parent=list(range(len(vn)))
def find(i):
    while parent[i]!=i:
        parent[i]=parent[parent[i]]; i=parent[i]
    return i
blocks=defaultdict(list)
for i,n in enumerate(vn):
    if len(n.replace(' ',''))>=5: blocks[n[:3]].append(i)
pairs=[]
THR=92
def tokens_ok(a,b):
    # reject pairs where BOTH names carry a distinguishing word and those words are not typo-variants
    ta,tb=a.split(),b.split(); sa,sb=set(ta),set(tb)
    da=''.join(t for t in ta if t not in sb); db=''.join(t for t in tb if t not in sa)
    if da and db and max(len(da),len(db))>=4 and fuzz.ratio(da,db)<75: return False
    return True
for b,idx in blocks.items():
    if len(idx)<2: continue
    sub=[vn[i] for i in idx]
    M=process.cdist(sub,sub,scorer=fuzz.token_sort_ratio,score_cutoff=THR,workers=-1)
    ii,jj=np.nonzero(np.triu(M,1))
    for a,c in zip(ii,jj):
        i,j=idx[a],idx[c]
        if digits[i]!=digits[j]: continue   # numbered companies must match exactly
        if not tokens_ok(vn[i],vn[j]): continue
        pairs.append((i,j,float(M[a,c])))
        parent[find(i)]=find(j)
vend['root']=[find(i) for i in range(len(vn))]

# spend per normalized vendor from fact
fact=pd.DataFrame(index=sorted(inkeys))
fact['vendor_raw']=firstC.vendor_name
fact['norm']=fact.vendor_raw.map(dict(zip(names.raw,names.norm)))
fact['val']=latest.val
spend_by_norm=fact.groupby('norm').val.sum()
cnt_by_norm=fact.groupby('norm').size()
vend['Spend']=vend.NormalizedName.map(spend_by_norm).fillna(0)
vend['ContractCount']=vend.NormalizedName.map(cnt_by_norm).fillna(0).astype(int)
csize=vend.groupby('root').size()
vend['FuzzyClusterSize']=vend.root.map(csize)
# canonical per cluster = highest spend then most contracts
vend=vend.sort_values(['root','Spend','ContractCount'],ascending=[True,False,False])
canon=vend.groupby('root').head(1).set_index('root')
vend['MasterVendorName']=vend.root.map(canon.DisplayName)
vend['MasterNormalized']=vend.root.map(canon.NormalizedName)
vend['SimilarityToMaster']=[round(fuzz.token_sort_ratio(a,b),1) for a,b in zip(vend.NormalizedName,vend.MasterNormalized)]
vend=vend.sort_values('Spend',ascending=False).reset_index(drop=True)
vend['VendorKey']=np.arange(1,len(vend)+1)
# cluster ids only for multi-member clusters
multi=vend[vend.FuzzyClusterSize>1]
cid={r:i+1 for i,r in enumerate(multi.groupby('root').Spend.sum().sort_values(ascending=False).index)}
vend['FuzzyClusterId']=vend.root.map(cid).fillna(0).astype(int)
vend['IsPotentialDuplicate']=(vend.FuzzyClusterSize>1).astype(int)
vend['HasMultipleSpellings']=(vend.RawVariantCount>1).astype(int)
vend['HasCountryConflict']=(vend.CountryCodeCount>1).astype(int)
fsa_re=re.compile(r'^[ABCEGHJKLMNPRSTVXY][0-9][A-Z]$')
prov={'A':'NL','B':'NS','C':'PE','E':'NB','G':'QC','H':'QC','J':'QC','K':'ON','L':'ON','M':'ON','N':'ON','P':'ON','R':'MB','S':'SK','T':'AB','V':'BC','X':'NT/NU','Y':'YT'}
vend['PostalFSAValid']=vend.PostalFSA.map(lambda x:1 if fsa_re.match(x or '') else 0)
vend['Province']=[prov.get(f[0],'') if (v==1 and c=='CA') else '' for f,v,c in zip(vend.PostalFSA,vend.PostalFSAValid,vend.CountryCode)]
pname={'NL':'Newfoundland and Labrador','NS':'Nova Scotia','PE':'Prince Edward Island','NB':'New Brunswick','QC':'Quebec','ON':'Ontario','MB':'Manitoba','SK':'Saskatchewan','AB':'Alberta','BC':'British Columbia','NT/NU':'Northwest Territories / Nunavut','YT':'Yukon'}
vend['ProvinceName']=vend.Province.map(pname).fillna('')
vend['CountryName']=vend.CountryCode.map(lambda c:label('country_of_vendor',c) or '')
vend['HasMissingPostal']=vend.PostalFSA.isin(['','NA']).astype(int)
vend['DQIssueCount']=vend[['IsPotentialDuplicate','HasMultipleSpellings','HasCountryConflict']].sum(axis=1)+((vend.CountryCode=='CA')&(vend.PostalFSAValid==0)).astype(int)
counts['after_fuzzy_clustering']=vend.root.nunique()
DimVendor=vend[['VendorKey','DisplayName','NormalizedName','MasterVendorName','FuzzyClusterId','FuzzyClusterSize','SimilarityToMaster','RawVariantCount','IsPotentialDuplicate','HasMultipleSpellings','HasCountryConflict','HasMissingPostal','PostalFSAValid','DQIssueCount','CountryCode','CountryName','PostalFSA','Province','ProvinceName']].rename(columns={'DisplayName':'VendorName'})
norm2key=dict(zip(vend.NormalizedName,vend.VendorKey))

# VendorNameMap (raw spelling -> VendorKey)
rawcnt=scope.vendor_name.value_counts()
VNM=names.assign(VendorKey=names.norm.map(norm2key),RecordCount=names.raw.map(rawcnt)).rename(columns={'raw':'RawVendorName','basic':'TrimmedUpper','norm':'NormalizedName'})
VNM=VNM.drop(columns=['TrimmedUpper','NormalizedName'])
VNM=VNM.sort_values(['VendorKey','RecordCount'],ascending=[True,False])

# ---------- dimensions ----------
depts=scope[['owner_org','owner_org_title']].drop_duplicates('owner_org').sort_values('owner_org').reset_index(drop=True)
depts['DeptKey']=np.arange(1,len(depts)+1)
depts['DepartmentName']=depts.owner_org_title.str.split(' | ',regex=False).str[0].str.strip()
depts['DepartmentNameFR']=depts.owner_org_title.str.split(' | ',regex=False).str[-1].str.strip()
DimDepartment=depts[['DeptKey','owner_org','DepartmentName','DepartmentNameFR']].rename(columns={'owner_org':'OrgCode'})

cat=C.groupby('economic_object_code').description_en.agg(lambda s:s.value_counts().index[0]).reset_index()
cat.columns=['EconomicObjectCode','CategoryDescription']
cat['CategoryKey']=np.arange(1,len(cat)+1)
# official Government-wide Chart of Accounts object codes (2025-26) for readable roll-up
coa=pd.read_csv('/workspace/src/art-obj-2526-eng.csv',dtype=str)
coa.columns=['grp','grp_name','cat','cat_name','subdiv','subdiv_name','so','so_name','so_desc','rep','rep_name','code','name','desc','notes','dept']
coa['so_name']=coa.so_name.astype(object).str.replace('\xa0',' ',regex=False)
coa['so_num']=coa.so_name.str.extract(r'\((?:[Ss]tandard [Oo]bject)\s*(\d+)\)',expand=False)
coa.loc[coa.so_num.isna()&coa.so.isin(['01','02','03','04','05','06']),'so_num']=coa.so
coa['so_name']=coa.so_name.str.replace(r'\s*\((?:[Ss]tandard [Oo]bject)\s*\d+\)','',regex=True).str.strip()
coa['so_label']=np.where(coa.so_num.notna(),'SO '+coa.so_num.fillna('')+' '+coa.so_name,coa.so_name+' (other account group)')
cat['CategoryDescription']=cat.CategoryDescription.str.strip().replace('',np.nan)
cat['code4']=cat.EconomicObjectCode.str.strip().str.zfill(4)
cat=cat.merge(coa[['code','so','so_label','rep_name','name']].drop_duplicates('code'),left_on='code4',right_on='code',how='left')
cat['InChartOfAccounts']=cat.code.notna().astype(int)
cat['ObjectName']=cat.name.fillna(cat.CategoryDescription).fillna('Not described')
cat['CategoryDescription']=cat.CategoryDescription.fillna(cat.ObjectName)
cat['CategoryGroup']=cat.rep_name.fillna('Unmapped object code')
cat['StandardObject']=np.where(cat.code.notna(),cat.so_label,'Unmapped object code')
DimCategory=cat[['CategoryKey','EconomicObjectCode','ObjectName','CategoryDescription','CategoryGroup','StandardObject','InChartOfAccounts']]

meth=pd.DataFrame({'MethodCode':['TC','OB','ST','AC','TN','UNK']})
meth['ProcurementMethod']=[label('solicitation_procedure',c) if c!='UNK' else 'Not reported' for c in meth.MethodCode]
meth['ProcurementMethod']=meth.ProcurementMethod.str.replace('–','-')
meth['CompetitionType']=meth.MethodCode.map({'TC':'Competitive','OB':'Competitive','ST':'Competitive','AC':'Non-competitive (ACAN)','TN':'Non-competitive','UNK':'Not reported'})
meth['IsCompetitive']=meth.MethodCode.isin(['TC','OB','ST']).astype(int)
meth['MethodKey']=np.arange(1,len(meth)+1)
DimProcurementMethod=meth[['MethodKey','MethodCode','ProcurementMethod','CompetitionType','IsCompetitive']]

ct=pd.DataFrame({'CommodityTypeCode':['G','S','C','U'],'CommodityType':['Goods','Services','Construction','Not reported']})
DimCommodityType=ct

# ---------- fact ----------
f=pd.DataFrame(index=sorted(inkeys))
f['ProcurementId']=firstC.procurement_id
f['DateKey']=firstC.cdate.dt.strftime('%Y%m%d').astype(int)
f['VendorKey']=firstC.vendor_name.map(dict(zip(names.raw,names.norm))).map(norm2key)
f['DeptKey']=firstC.owner_org.map(dict(zip(depts.owner_org,depts.DeptKey)))
f['CategoryKey']=firstC.economic_object_code.map(dict(zip(cat.EconomicObjectCode,cat.CategoryKey)))
mc=firstC.solicitation_procedure.replace('', 'UNK')
f['MethodKey']=mc.map(dict(zip(meth.MethodCode,meth.MethodKey)))
f['CommodityTypeCode']=firstC.commodity_type.replace('','U')
f['OriginalValue']=firstC.val.round(2)
f['ContractValue']=latest.val.round(2)
f['AmendmentValue']=(f.ContractValue-f.OriginalValue).round(2)
f['AmendmentCount']=amdcnt.reindex(f.index).fillna(0).astype(int)
f['IsAmended']=((f.AmendmentCount>0)|(f.AmendmentValue.abs()>0.5)).astype(int)
f['NumberOfBids']=pd.to_numeric(firstC.number_of_bids,errors='coerce').astype('Int64')
f['IsCallUpAgainstStandingOffer']=firstC.contracting_entity.isin(['PWSOSA','DSOSA','SSCSOSA']).astype(int)
f['DisclosureRecordCount']=nrec.reindex(f.index).astype(int)
nvk=scope.groupby('key').norm.nunique(); nvr=scope.groupby('key').vendor_name.nunique()
f['VendorSpellingsOnContract']=nvr.reindex(f.index).astype(int)
f['LimitedTenderingReason']=firstC.limited_tendering_reason.map(lambda c:label('limited_tendering_reason',c) if c not in ('','00') else '')
f=f.sort_values(['DateKey','DeptKey']).reset_index(drop=True)
f.insert(0,'ContractKey',np.arange(1,len(f)+1))
FactContracts=f

# DimDate
d=pd.DataFrame({'Date':pd.date_range('2023-04-01','2026-03-31')})
d['DateKey']=d.Date.dt.strftime('%Y%m%d').astype(int)
d['Year']=d.Date.dt.year; d['MonthNumber']=d.Date.dt.month
d['MonthName']=d.Date.dt.strftime('%b'); d['YearMonth']=d.Date.dt.strftime('%Y-%m')
d['MonthStart']=d.Date.dt.to_period('M').dt.start_time.dt.strftime('%Y-%m-%d')
fy=np.where(d.MonthNumber>=4,d.Year,d.Year-1)
d['FiscalYear']=['FY%d-%02d'%(y,(y+1)%100) for y in fy]
d['FiscalYearShort']=["FY'%02d"%((y+1)%100) for y in fy]
d['FiscalYearStart']=fy
d['FiscalMonthNumber']=(d.MonthNumber-4)%12+1
d['FiscalQuarter']=['Q%d'%((m-1)//3+1) for m in d.FiscalMonthNumber]
d['DayOfWeek']=d.Date.dt.strftime('%a')
d['CalendarQuarter']='Q'+d.Date.dt.quarter.astype(str)
d['MonthLabel']=d.Date.dt.strftime("%b '%y")
d['MonthIndex']=(d.Date.dt.year-2023)*12+d.Date.dt.month-3
d['FiscalQuarterLabel']=d.FiscalYearShort+' '+d.FiscalQuarter
d['FiscalMonthName']=d.MonthName
d['Date']=d.Date.dt.strftime('%Y-%m-%d')
DimDate=d

# ---------- DQ ----------
rules=[]
def add(rid,rule,level,field,checked,failed,spend=None,sev='Medium',why=''):
    rules.append(dict(RuleId=rid,Rule=rule,Level=level,Field=field,RecordsChecked=int(checked),RecordsFailed=int(failed),PctFailed=round(100*failed/checked,2) if checked else 0,SpendAffected=round(spend,2) if spend is not None else None,Severity=sev,WhyItMatters=why))
S=scope
ws=S.vendor_name.str.contains(r'^\s|\s$|\s{2,}',regex=True)
add('DQ01','Vendor name has leading, trailing or double spaces','Disclosure record','vendor_name',len(S),ws.sum(),None,'Low','Breaks exact-match lookups and creates silent duplicates')
add('DQ02','Raw vendor spellings that collapse after trim and case-fold','Vendor name','vendor_name',counts['raw_distinct'],counts['raw_distinct']-counts['after_trim_case'],None,'Medium','Same supplier keyed differently only by capitalization or spacing')
add('DQ03','Raw vendor spellings that collapse after full normalization (punctuation, accents, legal suffix)','Vendor name','vendor_name',counts['raw_distinct'],counts['raw_distinct']-counts['after_full_normalization'],None,'Medium','e.g. Inc vs Inc. vs Incorporated for one supplier')
mv=vend[vend.HasMultipleSpellings==1]
add('DQ04','Normalized vendor appears under more than one raw spelling','Vendor','vendor_name',len(vend),len(mv),mv.Spend.sum(),'Medium','One supplier, several master records in practice')
pd_=vend[vend.IsPotentialDuplicate==1]
add('DQ05','Near-duplicate vendor (fuzzy token-sort similarity >= %d, numbers must match)'%THR,'Vendor','vendor_name',len(vend),len(pd_),pd_.Spend.sum(),'High','Possible duplicate supplier records; needs data steward review')
add('DQ06','Same contract reported with different vendor spellings across its records','Contract','vendor_name',len(f),(f.VendorSpellingsOnContract>1).sum(),f.loc[f.VendorSpellingsOnContract>1,'ContractValue'].sum(),'Medium','Even a single contract is not keyed consistently over time')
ca=S[S.country_of_vendor=='CA']
miss=ca.vendor_postal_code.str.strip().str.upper().isin(['','NA'])
add('DQ07','Canadian vendor with missing or NA postal code','Disclosure record','vendor_postal_code',len(ca),miss.sum(),None,'Medium','Cannot geolocate or validate the supplier address')
pc=ca.vendor_postal_code.str.strip().str.upper()
inval=(~miss)&(~pc.str.match(fsa_re.pattern))
add('DQ08','Canadian vendor postal code not a valid FSA format (A9A)','Disclosure record','vendor_postal_code',len(ca),inval.sum(),None,'Medium','Format validation would block this at entry')
nonca=S[(S.country_of_vendor!='CA')&(S.country_of_vendor!='')]
cafsa=nonca.vendor_postal_code.str.strip().str.upper().str.match(fsa_re.pattern)
add('DQ09','Non-Canadian vendor country but Canadian-format postal code','Disclosure record','country_of_vendor / vendor_postal_code',len(nonca),cafsa.sum(),None,'Low','Country and address disagree; may be a Canadian branch or a keying error')
add('DQ10','Missing country of vendor','Disclosure record','country_of_vendor',len(S),(S.country_of_vendor=='').sum(),None,'Medium','Required field for trade agreement reporting')
cc=vend[vend.HasCountryConflict==1]
add('DQ11','Vendor recorded with more than one country code','Vendor','country_of_vendor',len(vend),len(cc),cc.Spend.sum(),'Medium','Conflicting master attribute for one supplier')
comp=f[f.MethodKey.isin(meth.loc[meth.IsCompetitive==1,'MethodKey'])]
add('DQ12','Competitive contract with missing number of bids','Contract','number_of_bids',len(comp),comp.NumberOfBids.isna().sum(),comp.loc[comp.NumberOfBids.isna(),'ContractValue'].sum(),'Medium','Cannot measure real competition')
add('DQ13','Contract value zero or negative','Contract','contract_value',len(f),(f.ContractValue<=0).sum(),None,'High','Value field not usable for spend')
cr=S[S.instrument_type=='C']
mism=(cr.val-(cr.orig.fillna(0)+cr.amd.fillna(0))).abs()>1
add('DQ14','Original award record where contract value differs from original + amendment value','Disclosure record','contract_value',len(cr),mism.sum(),None,'Low','Internal arithmetic check')
st=pd.to_datetime(S.contract_period_start,errors='coerce'); en=pd.to_datetime(S.delivery_date,errors='coerce')
add('DQ15','Contract end/delivery date before start date','Disclosure record','contract_period_start / delivery_date',int((st.notna()&en.notna()).sum()),int((en<st).sum()),None,'Low','Date logic error')
add('DQ16','Missing solicitation procedure','Contract','solicitation_procedure',len(f),(mc=='UNK').sum(),None,'Medium','Cannot classify competitive vs non-competitive')
bil=S.vendor_name.str.contains(' / ',regex=False)
add('DQ17','Compound or bilingual vendor name containing \" / \"','Disclosure record','vendor_name',len(S),bil.sum(),None,'Low','Two names in one field complicate matching')
cb=comp[comp.NumberOfBids.notna()]
add('DQ19','Competitive contract reporting zero bids','Contract','number_of_bids',len(cb),(cb.NumberOfBids==0).sum(),cb.loc[cb.NumberOfBids==0,'ContractValue'].sum(),'Medium','A competitive award with 0 bids is not logically possible; often a call-up reported with the wrong default')
L=S.vendor_name.str.strip().str.len()
inc=f.CategoryKey.isin(cat.loc[cat.InChartOfAccounts==1,'CategoryKey'])
add('DQ20','Economic object code not found in the Government-wide Chart of Accounts 2025-26','Contract','economic_object_code',len(f),(~inc).sum(),f.loc[~inc,'ContractValue'].sum(),'Medium','Spend cannot be rolled up to an official category (possible causes include a dropped digit or a retired code)')
gsin=set(pd.read_csv('/workspace/src/nibs-gsin.csv',dtype=str)['nibs-gsin'].str.upper())
cc=firstC.commodity_code.str.strip().str.upper()
is_gsin=cc.isin(gsin); is_8=cc.str.fullmatch(r'\d{8}')
add('DQ21','Commodity code matches neither the published GSIN list nor the 8-digit UNSPSC format','Contract','commodity_code',len(cc),(~is_gsin&~is_8).sum(),None,'Low','Three coding schemes in one field (GSIN, UNSPSC-format, other) block a clean commodity roll-up')
json.dump({'gsin_match':int(is_gsin.sum()),'unspsc8':int((is_8&~is_gsin).sum()),'other':int((~is_gsin&~is_8).sum()),'n':int(len(cc))},open('/workspace/src/commodity_schemes.json','w'))
add('DQ18','Vendor name exactly 35 characters long (likely cut off by a 35-character field limit)','Disclosure record','vendor_name',len(S),(L==35).sum(),None,'Medium','Truncated names defeat matching; 35 chars is a common vendor-name field length')
json.dump({int(k):int(v) for k,v in L.value_counts().sort_index().items()},open('/workspace/src/namelen.json','w'))
json.dump({k:int(v) for k,v in S[L==35].groupby('owner_org').size().sort_values(ascending=False).head(10).items()},open('/workspace/src/trunc_by_org.json','w'))
dq=pd.DataFrame(rules).sort_values('RuleId')

# duplicates file
dup=vend[(vend.IsPotentialDuplicate==1)|(vend.HasMultipleSpellings==1)].copy()
dup['DuplicateType']=np.select([(dup.IsPotentialDuplicate==1)&(dup.HasMultipleSpellings==1),dup.IsPotentialDuplicate==1],['Fuzzy cluster + multiple spellings','Fuzzy cluster (near-duplicate)'],'Multiple raw spellings (exact after normalization)')
dup=dup.sort_values(['FuzzyClusterId','Spend'],ascending=[True,False])
dup['sortc']=dup.FuzzyClusterId.replace(0,10**9)
dup=dup.sort_values(['sortc','Spend'],ascending=[True,False])
dq_dup=dup[['FuzzyClusterId','MasterVendorName','VendorKey','DisplayName','NormalizedName','SimilarityToMaster','FuzzyClusterSize','RawVariantCount','RawVariants','DuplicateType','ContractCount','Spend','CountryCode','PostalFSA']].rename(columns={'DisplayName':'VendorName'})
dq_dup['Spend']=dq_dup.Spend.round(2)

summary=pd.DataFrame([
 ('1. Raw vendor names (as published)',counts['raw_distinct']),
 ('2. After trim, spacing and case-fold',counts['after_trim_case']),
 ('3. After accents, punctuation and legal suffix normalization',counts['after_full_normalization']),
 ('4. After fuzzy clustering (suggested masters)',counts['after_fuzzy_clustering'])],columns=['Stage','VendorCount'])
summary['StageOrder']=[1,2,3,4]

# write
FactContracts.to_csv(f'{OUT}/FactContracts.csv',index=False)
DimVendor.to_csv(f'{OUT}/DimVendor.csv',index=False)
DimDepartment.to_csv(f'{OUT}/DimDepartment.csv',index=False)
DimDate.to_csv(f'{OUT}/DimDate.csv',index=False)
DimCategory.to_csv(f'{OUT}/DimCategory.csv',index=False)
DimProcurementMethod.to_csv(f'{OUT}/DimProcurementMethod.csv',index=False)
DimCommodityType.to_csv(f'{OUT}/DimCommodityType.csv',index=False)
VNM.to_csv(f'{OUT}/VendorNameMap.csv',index=False)
dq_dup.to_csv(f'{OUT}/dq_vendor_duplicates.csv',index=False)
dq.to_csv(f'{OUT}/dq_rule_summary.csv',index=False)
summary[['StageOrder','Stage','VendorCount']].to_csv(f'{OUT}/dq_vendor_count_stages.csv',index=False)
json.dump({k:int(v) for k,v in counts.items()}|{'pairs':len(pairs),'scope_rows':len(S),'fact_rows':len(f)},open('/workspace/src/counts.json','w'),indent=1)
print(counts, len(pairs), len(S), len(f))
