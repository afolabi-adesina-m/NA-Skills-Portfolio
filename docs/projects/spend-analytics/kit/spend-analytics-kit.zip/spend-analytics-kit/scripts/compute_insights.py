import pandas as pd, numpy as np, json
f=pd.read_csv('FactContracts.csv'); v=pd.read_csv('DimVendor.csv'); dd=pd.read_csv('DimDate.csv'); dep=pd.read_csv('DimDepartment.csv'); m=pd.read_csv('DimProcurementMethod.csv'); cat=pd.read_csv('DimCategory.csv')
print('VendorName ci unique', v.VendorName.str.upper().str.strip().is_unique, 'Master ci-groups', v.MasterVendorName.str.upper().nunique(), 'clusters roots?')
x=f.merge(dd[['DateKey','FiscalYear','YearMonth']],on='DateKey').merge(v,on='VendorKey').merge(dep,on='DeptKey').merge(m,on='MethodKey').merge(cat,on='CategoryKey')
R={}
tot=x.ContractValue.sum(); R['total_spend']=tot; R['contracts']=len(x); R['avg']=x.ContractValue.mean(); R['median']=x.ContractValue.median()
fy=x.groupby('FiscalYear').agg(spend=('ContractValue','sum'),n=('ContractKey','count'),med=('ContractValue','median')); fy['yoy']=fy.spend.pct_change()*100; print(fy)
print('total',tot/1e9,'n',len(x),'avg',R['avg'],'median',R['median'])
# top contracts
print(x.nlargest(5,'ContractValue')[['VendorName','DepartmentName','ContractValue','FiscalYear','CategoryDescription']])
# concentration
sv=x.groupby('VendorName').ContractValue.sum().sort_values(ascending=False)
print('vendors with contracts',len(sv),'top10 share',sv.head(10).sum()/tot*100); print(sv.head(10)/1e9)
sh=sv/tot*100; print('HHI vendor', (sh**2).sum())
sm=x.groupby('MasterVendorName').ContractValue.sum().sort_values(ascending=False); print('master top10 share',sm.head(10).sum()/tot*100,'HHI master',((sm/tot*100)**2).sum(),'n',len(sm))
# top 1% vendors share
k=int(np.ceil(len(sv)*0.01)); print('top1% vendors',k,'share',sv.head(k).sum()/tot*100)
print('ex-top1 contract share top10', (sv.head(10).sum()-x.ContractValue.max())/(tot-x.ContractValue.max())*100)
# dept
sd=x.groupby('DepartmentName').ContractValue.sum().sort_values(ascending=False); print((sd.head(5)/tot*100).round(1), (sd.head(5)/1e9).round(2))
# competition
print(x.groupby('CompetitionType').agg(n=('ContractKey','count'),s=('ContractValue','sum')).assign(pn=lambda d:d.n/d.n.sum()*100,ps=lambda d:d.s/d.s.sum()*100))
nc=x[x.IsCompetitive==0]
print('noncomp by FY',x.groupby('FiscalYear').apply(lambda d:(d.IsCompetitive==0).mean()*100))
dn=x.groupby('DepartmentName').agg(n=('ContractKey','count'),nc=('IsCompetitive',lambda s:(s==0).mean()*100)).query('n>=1000').sort_values('nc',ascending=False); print(dn.head(6)); print(dn.tail(3))
print(nc.LimitedTenderingReason.value_counts().head(5))
# bids
comp=x[x.IsCompetitive==1]; cb=comp[comp.NumberOfBids.notna()]
print('competitive with bids reported',len(cb),'of',len(comp),'one bid share',(cb.NumberOfBids==1).mean()*100,'zero bids',(cb.NumberOfBids==0).mean()*100,'median bids',cb.NumberOfBids.median())
print('one-bid spend share among comp reported',cb.loc[cb.NumberOfBids==1,'ContractValue'].sum()/cb.ContractValue.sum()*100)
# amendments
print('amended rate',x.IsAmended.mean()*100, 'by FY', x.groupby('FiscalYear').IsAmended.mean()*100)
a=x[x.IsAmended==1]; print('amended n',len(a),'orig',a.OriginalValue.sum()/1e9,'final',a.ContractValue.sum()/1e9,'growth%',(a.ContractValue.sum()/a.OriginalValue.sum()-1)*100, 'amendment value total',x.AmendmentValue.sum()/1e9, 'share of total', x.AmendmentValue.sum()/tot*100)
print('median growth pct among amended', ((a.ContractValue/a.OriginalValue.replace(0,np.nan))-1).median()*100)
# commodity
print(x.groupby('CommodityTypeCode').ContractValue.sum()/tot*100, x.CommodityTypeCode.value_counts(normalize=True)*100)
# standing offers
print('callups count share',x.IsCallUpAgainstStandingOffer.mean()*100,'spend share',x.loc[x.IsCallUpAgainstStandingOffer==1,'ContractValue'].sum()/tot*100)
# province
ca=x[x.CountryCode=='CA']; print('CA vendor spend share',ca.ContractValue.sum()/tot*100,'count share',len(ca)/len(x)*100)
pv=x.groupby('ProvinceName').ContractValue.sum().sort_values(ascending=False)/tot*100; print(pv.head(6))
pvn=x.groupby('ProvinceName').size().sort_values(ascending=False)/len(x)*100; print(pvn.head(6))
print('US share', x.loc[x.CountryCode=='US','ContractValue'].sum()/tot*100)
# MDM spend at risk
print('spend potential dup vendors',x.loc[x.IsPotentialDuplicate==1,'ContractValue'].sum()/tot*100, x.loc[x.IsPotentialDuplicate==1,'ContractValue'].sum()/1e9,'contracts',(x.IsPotentialDuplicate==1).sum())
print('spend multiple spellings',x.loc[x.HasMultipleSpellings==1,'ContractValue'].sum()/tot*100)
print('vendors w contracts flagged dup',v[v.VendorKey.isin(x.VendorKey)].IsPotentialDuplicate.mean()*100, v.IsPotentialDuplicate.mean()*100)
# rank change when using master
print('rank master top 15'); print((sm.head(15)/1e9).round(3))
d=pd.read_csv('dq_vendor_duplicates.csv'); big=d[d.FuzzyClusterId>0].groupby('FuzzyClusterId').agg(name=('MasterVendorName','first'),n=('VendorKey','count'),raw=('RawVariantCount','sum'),spend=('Spend','sum')).sort_values('raw',ascending=False); print(big.head(8))
vnm=pd.read_csv('VendorNameMap.csv'); print('max raw variants per normalized', v.RawVariantCount.max(), v.nlargest(5,'RawVariantCount')[['VendorName','RawVariantCount']])
