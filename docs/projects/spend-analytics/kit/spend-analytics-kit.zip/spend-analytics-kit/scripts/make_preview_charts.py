import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, PercentFormatter
import matplotlib.dates as mdates
D='/workspace/powerbi-kit/data/'; P='/workspace/powerbi-kit/preview/'
NAVY='#1F3A5F'; MID='#3E6A9E'; LIGHT='#9DB9D8'; PALE='#EAF1F8'; AMBER='#E3A33B'; TEAL='#5B8C85'; RED='#C0504D'; GREY='#5B6573'
SEGC={'Strategic':NAVY,'Leverage':MID,'Bottleneck':AMBER,'Routine':TEAL}
SRC='Source: Government of Canada, Proactive Publication - Contracts (Open Government Licence - Canada), downloaded 6 Oct 2026. Contracts awarded Apr 2023 to Mar 2026, value incl. amendments.'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#C8CFD8','axes.labelcolor':GREY,'xtick.color':GREY,'ytick.color':GREY,'axes.titlecolor':NAVY})
def bn(y,_=None): return f'${y:,.0f}B' if abs(y)>=1 or y==0 else f'${y:,.1f}B'
def money(v): return f'C${v/1e9:,.1f}B' if abs(v)>=1e9 else f'C${v/1e6:,.0f}M'
def title(fig,t,sub=None):
    fig.text(0.012,0.965,t,fontsize=15,fontweight='bold',color=NAVY,va='top')
    if sub: fig.text(0.012,0.915,sub,fontsize=10,color=GREY,va='top')
def footer(fig,extra=None):
    fig.text(0.012,0.012,SRC+('\n'+extra if extra else ''),fontsize=7.3,color=GREY,va='bottom')
def save(fig,name): fig.savefig(P+name,facecolor='white'); plt.close(fig)

f=pd.read_csv(D+'FactContracts.csv'); dd=pd.read_csv(D+'DimDate.csv'); v=pd.read_csv(D+'DimVendor.csv',keep_default_na=False,na_values=[''])
c=pd.read_csv(D+'DimCategory.csv',dtype={'EconomicObjectCode':str}); cs=pd.read_csv(D+'DimCategorySegment.csv')
tot=f.ContractValue.sum()

# ---------- 01 spend trend ----------
x=f.merge(dd[['DateKey','MonthStart','FiscalYearShort']],on='DateKey').merge(v[['VendorKey','VendorName']],on='VendorKey')
x['MonthStart']=pd.to_datetime(x.MonthStart)
months=pd.date_range('2023-04-01','2026-03-01',freq='MS')
allm=x.groupby('MonthStart').ContractValue.sum().reindex(months,fill_value=0)
big=x.ContractValue>=1e9
small=x[~big].groupby('MonthStart').ContractValue.sum().reindex(months,fill_value=0)
nbig=int(big.sum()); bigshare=x.loc[big,'ContractValue'].sum()/tot*100
fig,(a1,a2)=plt.subplots(2,1,figsize=(12,7.6),dpi=130,sharex=True,gridspec_kw=dict(height_ratios=[1,1],hspace=0.28))
fig.subplots_adjust(left=0.07,right=0.98,top=0.86,bottom=0.12)
title(fig,"Monthly Spend, FY'24 to FY'26",f"Top: all contracts. Bottom: the same months without the {nbig} contracts of C$1B or more ({bigshare:.0f}% of all value).")
for ax in (a1,a2):
    for i,(fy,s0) in enumerate([("FY'24",'2023-04-01'),("FY'25",'2024-04-01'),("FY'26",'2025-04-01')]):
        s0=pd.Timestamp(s0); e0=s0+pd.DateOffset(years=1)
        ax.axvspan(s0-pd.Timedelta(days=15),e0-pd.Timedelta(days=15),color=PALE if i%2==0 else 'white',zorder=0)
        if i>0: ax.axvline(s0-pd.Timedelta(days=15),color='#C8CFD8',lw=1,ls='--',zorder=1)
        if ax is a1: ax.text(s0+pd.Timedelta(days=165),1.02,fy,transform=ax.get_xaxis_transform(),ha='center',va='bottom',fontsize=10,fontweight='bold',color=MID)
a1.plot(months,allm/1e9,color=NAVY,lw=2,marker='o',ms=3.5,zorder=3)
a1.yaxis.set_major_formatter(FuncFormatter(bn)); a1.set_ylim(0,24); a1.set_yticks([0,5,10,15,20]); a1.set_ylabel('All contracts')
top3=allm.nlargest(3)
for mth,val in top3.items():
    lc=x[x.MonthStart==mth].nlargest(1,'ContractValue').iloc[0]
    nm=lc.VendorName.replace(' Inc.','').replace(' Limited Partnership','').replace(' Canada','')
    nm=nm[:26]
    a1.annotate(f"{mth:%b '%y}: {money(val)}\nlargest: {nm} {money(lc.ContractValue)}",(mth,val/1e9),xytext=(10,-4),textcoords='offset points',fontsize=8.3,color=NAVY,va='top',
                bbox=dict(boxstyle='round,pad=0.3',fc='white',ec=LIGHT,lw=0.8))
a2.plot(months,small/1e9,color=MID,lw=2,marker='o',ms=3.5,zorder=3)
a2.fill_between(months,small/1e9,color=LIGHT,alpha=0.35,zorder=2)
a2.set_ylim(0,max(small/1e9)*1.2); a2.yaxis.set_major_formatter(FuncFormatter(lambda y,_:f'${y:,.1f}B')); a2.set_ylabel('Excl. contracts >= C$1B')
a2.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1,4,7,10])); a2.xaxis.set_minor_locator(mdates.MonthLocator())
a2.xaxis.set_major_formatter(mdates.DateFormatter("%b '%y")); a2.set_xlim(months[0]-pd.Timedelta(days=20),months[-1]+pd.Timedelta(days=20))
for ax in (a1,a2): ax.grid(axis='y',color='#E3E8EF',lw=0.8,zorder=0)
footer(fig); save(fig,'01_spend_trend.png')

# ---------- 02 top vendors ----------
xv=f.merge(v[['VendorKey','MasterVendorName']],on='VendorKey')
t=xv.groupby('MasterVendorName').ContractValue.sum().nlargest(10).sort_values()
fig,ax=plt.subplots(figsize=(11,5.8),dpi=130); fig.subplots_adjust(left=0.36,right=0.96,top=0.84,bottom=0.13)
title(fig,"Top 10 Suppliers, FY'24 to FY'26",f"They hold {t.sum()/tot*100:.1f}% of {money(tot)} in contract value (grouped by suggested master vendor)")
b=ax.barh([n if len(n)<=46 else n[:44]+'...' for n in t.index],t.values/1e9,color=[MID]*9+[NAVY])
for r,val in zip(b,t.values): ax.text(r.get_width()+0.12,r.get_y()+r.get_height()/2,f"{money(val)}  ({val/tot*100:.1f}%)",va='center',fontsize=9,color=GREY)
ax.xaxis.set_major_formatter(FuncFormatter(bn)); ax.set_xlim(0,t.max()/1e9*1.3); ax.grid(axis='x',color='#E3E8EF',lw=0.8); ax.set_axisbelow(True)
footer(fig); save(fig,'02_top_vendors.png')

# ---------- 03 dedup ----------
s=pd.read_csv(D+'dq_vendor_count_stages.csv')
labels=['Raw names\n(as published)','After trim,\nspacing, case','After accents,\npunctuation,\nlegal suffixes','After fuzzy\nclustering\n(suggested masters)']
fig,ax=plt.subplots(figsize=(10,5.8),dpi=130); fig.subplots_adjust(left=0.1,right=0.97,top=0.84,bottom=0.2)
r=s.VendorCount
title(fig,'Supplier Master Clean-up',f'{r.iloc[0]:,} vendor names collapse to {r.iloc[-1]:,} suggested master suppliers ({(1-r.iloc[-1]/r.iloc[0])*100:.1f}% fewer)')
b=ax.bar(labels,r,color=[AMBER,LIGHT,MID,NAVY],width=.6)
for rect,val in zip(b,r): ax.text(rect.get_x()+rect.get_width()/2,val+600,f'{val:,}',ha='center',fontsize=11,fontweight='bold',color=NAVY)
ax.set_ylim(0,r.max()*1.15); ax.yaxis.set_major_formatter(FuncFormatter(lambda y,_:f'{y:,.0f}')); ax.set_ylabel('Distinct vendors')
ax.grid(axis='y',color='#E3E8EF',lw=0.8); ax.set_axisbelow(True)
footer(fig); save(fig,'03_vendor_dedup_before_after.png')

# ---------- 04 top categories ----------
xc=f.merge(c[['CategoryKey','CategoryGroupKey']],on='CategoryKey').merge(cs[['CategoryGroupKey','CategoryGroup','KraljicSegment']],on='CategoryGroupKey')
g=xc.groupby(['CategoryGroup','KraljicSegment']).agg(spend=('ContractValue','sum'),n=('ContractKey','count')).reset_index().nlargest(15,'spend').iloc[::-1]
fig,ax=plt.subplots(figsize=(12,7),dpi=130); fig.subplots_adjust(left=0.36,right=0.97,top=0.86,bottom=0.12)
title(fig,"Top 15 Categories by Spend, FY'24 to FY'26",f"These 15 of {cs.CategoryGroup.nunique()} category groups hold {g.spend.sum()/tot*100:.1f}% of spend. Categories follow the Government-wide Chart of Accounts.")
b=ax.barh([n if len(n)<=48 else n[:46]+'...' for n in g.CategoryGroup],g.spend/1e9,color=NAVY)
for rect,sp,n in zip(b,g.spend,g.n): ax.text(rect.get_width()+0.15,rect.get_y()+rect.get_height()/2,f"{money(sp)}  |  {n:,} contracts",va='center',fontsize=8.8,color=GREY)
ax.xaxis.set_major_formatter(FuncFormatter(bn)); ax.set_xlim(0,g.spend.max()/1e9*1.32); ax.grid(axis='x',color='#E3E8EF',lw=0.8); ax.set_axisbelow(True)
footer(fig); save(fig,'04_top_categories.png')

# ---------- 05 Kraljic matrix ----------
k=cs.dropna(subset=['CategorySpend']).copy(); k=k[k.CategorySpend>0]
aMin=k.loc[k.CategoryParetoClass=='A','CategorySpend'].min(); bMax=k.loc[k.CategoryParetoClass!='A','CategorySpend'].max()
xcut=np.sqrt(aMin*bMax); ycut=25
fig=plt.figure(figsize=(14,7.8),dpi=130)
ax=fig.add_axes([0.06,0.17,0.60,0.66])
title(fig,'Category Segmentation: Spend vs Supply Risk',"Kraljic-style 2x2 on 85 category groups, FY'24 to FY'26. Tier in brackets: Strategic / Tactical / Operational.")
ax.set_xscale('log'); ax.set_xlim(1e4,2e11); ax.set_ylim(0,105)
ax.fill_between([xcut,2e11],ycut,105,color=PALE,zorder=0)
ax.axvline(xcut,color=GREY,ls='--',lw=1); ax.axhline(ycut,color=GREY,ls='--',lw=1)
for seg,col in SEGC.items():
    d=k[k.KraljicSegment==seg]; rel=d[d.LowDataConfidence==0]; low=d[d.LowDataConfidence==1]
    sz=lambda q:20+np.sqrt(q.ContractCount)*4
    ax.scatter(rel.CategorySpend,rel.SupplyRiskScore,s=sz(rel),color=col,alpha=0.85,edgecolor='white',lw=0.8,label=seg,zorder=3)
    ax.scatter(low.CategorySpend,low.SupplyRiskScore,s=sz(low),facecolor='none',edgecolor=col,lw=1.2,zorder=3)
lab=pd.concat([k[k.CategoryParetoClass=='A'].sort_values('CategorySpend',ascending=False),
               k[(k.KraljicSegment=='Bottleneck')&(k.LowDataConfidence==0)].nlargest(5,'CategorySpend')])
lines=[]
for i,(_,r0) in enumerate(lab.iterrows(),1):
    ax.annotate(str(i),(r0.CategorySpend,r0.SupplyRiskScore),xytext=(0,9),textcoords='offset points',ha='center',fontsize=8,fontweight='bold',color='black',zorder=5)
    nm=r0.CategoryGroup if len(r0.CategoryGroup)<=44 else r0.CategoryGroup[:42]+'...'
    lines.append((i,nm,r0.KraljicSegment,r0.CategorySpend,r0.SupplyRiskScore))
y=0.83
fig.text(0.685,y+0.01,'Labelled categories',fontsize=10.5,fontweight='bold',color=NAVY,va='bottom')
for i,nm,seg,sp,rs in lines:
    y-=0.042
    fig.text(0.685,y,f'{i:>2}',fontsize=8.6,fontweight='bold',color=SEGC[seg],va='center')
    fig.text(0.705,y,f'{nm}',fontsize=8.4,color=GREY,va='center')
    fig.text(0.985,y,f'{money(sp)} | {rs:.0f}',fontsize=8.4,color=GREY,va='center',ha='right')
fig.text(0.985,0.84,'spend | risk',fontsize=8,color=GREY,ha='right',va='bottom')
qs=dict(fontsize=12,fontweight='bold',alpha=0.9)
ax.text(2.4e10,101,'STRATEGIC\n(Strategic tier)',color=NAVY,ha='center',va='top',**qs)
ax.text(2.4e10,3,'LEVERAGE\n(Tactical tier)',color=MID,ha='center',va='bottom',**qs)
ax.text(3e5,101,'BOTTLENECK\n(Tactical tier)',color=AMBER,ha='center',va='top',**qs)
ax.text(3e5,3,'ROUTINE\n(Operational tier)',color=TEAL,ha='center',va='bottom',**qs)
ax.xaxis.set_major_formatter(FuncFormatter(lambda v,_:money(v).replace('.0B','B') if v>=1e6 else f'C${v/1e3:,.0f}K'))
ax.set_xlabel('Category spend (log scale)'); ax.set_ylabel('Supply Risk Score (0 to 100)')
ax.legend(frameon=False,loc='lower left',ncol=4,bbox_to_anchor=(0,1.0),fontsize=9)
footer(fig,'Thresholds are analyst-defined assumptions: high spend = Pareto class A (groups making up the first 80% of spend); high risk = score >= 25. Score = average of supplier HHI/10,000, non-competitive spend share,\nsingle-bid share and supplier scarcity (min(1, 10 / active suppliers)), x100. Bubble size = contract count; hollow = fewer than 30 contracts (low confidence).')
save(fig,'05_kraljic_matrix.png')

# ---------- 06 Pareto vendors ----------
vp=xv.groupby('MasterVendorName').ContractValue.sum().sort_values(ascending=False)
cum=vp.cumsum()/vp.sum(); n80=int((cum<0.8).sum()+1); N=len(vp); SHOW=400
fig,ax=plt.subplots(figsize=(12,6.4),dpi=130); fig.subplots_adjust(left=0.08,right=0.92,top=0.85,bottom=0.15)
title(fig,'Supplier Pareto: 80% of Spend',f'{n80} of {N:,} suppliers ({n80/N*100:.1f}%) account for 80% of spend. Showing the top {SHOW}; the cumulative line uses all suppliers.')
rk=np.arange(1,SHOW+1)
ax.bar(rk,vp.values[:SHOW]/1e9,width=1.0,color=[NAVY if i<=n80 else LIGHT for i in rk])
ax.set_yscale('log'); ax.set_ylabel('Supplier spend (C$ billions, log scale)'); ax.yaxis.set_major_formatter(FuncFormatter(lambda y,_:f'${y:g}B'))
ax.set_xlabel('Supplier rank by spend'); ax.set_xlim(0,SHOW+1)
a2=ax.twinx(); a2.plot(rk,cum.values[:SHOW],color=AMBER,lw=2.4); a2.set_ylim(0,1.02); a2.yaxis.set_major_formatter(PercentFormatter(1.0)); a2.set_ylabel('Cumulative share of spend')
a2.axhline(0.8,color=RED,ls='--',lw=1.2); a2.text(SHOW,0.81,'80%',color=RED,ha='right',va='bottom',fontsize=9)
a2.axvline(n80,color=GREY,ls=':',lw=1); a2.annotate(f'Rank {n80}: 80% reached\nClass A = {n80} suppliers',(n80,0.8),xytext=(20,-55),textcoords='offset points',fontsize=9,color=NAVY,arrowprops=dict(arrowstyle='->',color=GREY))
a2.spines['top'].set_visible(False)
footer(fig,'Class A = suppliers that make up the first 80% of spend, B = next 15%, C = last 5%. Suppliers grouped by suggested master vendor.'); save(fig,'06_pareto_vendors.png')

# ---------- 07 Pareto categories ----------
cp=cs.dropna(subset=['CategorySpend']).sort_values('CategorySpend',ascending=False)
cc=cp.CategorySpend.cumsum()/cp.CategorySpend.sum(); n80c=int((cc<0.8).sum()+1); SH=25
fig,ax=plt.subplots(figsize=(12,7.4),dpi=130); fig.subplots_adjust(left=0.08,right=0.92,top=0.86,bottom=0.36)
title(fig,'Category Pareto: 80% of Spend',f'{n80c} of {len(cp)} category groups ({n80c/len(cp)*100:.0f}%) account for 80% of spend. Top {SH} shown; cumulative line uses all groups.')
names=[n if len(n)<=34 else n[:32]+'...' for n in cp.CategoryGroup[:SH]]
ax.bar(range(SH),cp.CategorySpend.values[:SH]/1e9,color=[NAVY if i<n80c else LIGHT for i in range(SH)])
ax.set_xticks(range(SH)); ax.set_xticklabels(names,rotation=60,ha='right',fontsize=8)
ax.yaxis.set_major_formatter(FuncFormatter(bn)); ax.set_ylabel('Category spend')
a2=ax.twinx(); a2.plot(range(SH),cc.values[:SH],color=AMBER,lw=2.4,marker='o',ms=3.5); a2.set_ylim(0,1.02); a2.yaxis.set_major_formatter(PercentFormatter(1.0)); a2.set_ylabel('Cumulative share of spend')
a2.axhline(0.8,color=RED,ls='--',lw=1.2); a2.text(SH-0.5,0.81,'80%',color=RED,ha='right',va='bottom',fontsize=9); a2.spines['top'].set_visible(False)
footer(fig,'Dark bars = class A (first 80% of spend). Category groups = report objects in the Government-wide Chart of Accounts 2025-26.'); save(fig,'07_pareto_categories.png')
print('charts ok', n80, N, n80c)
