# Step 0: download the open data and keep the columns and reporting periods the pipeline needs.
# Writes recent.parquet, contracts_schema.json, art-obj-2526-eng.csv and nibs-gsin.csv into SRC.
import os, urllib.request, pandas as pd
SRC = '/workspace/src'          # change to your own working folder
os.makedirs(SRC, exist_ok=True)
FILES = {
    'contracts.csv': 'https://open.canada.ca/data/dataset/d8f85d91-7dec-4fd1-8055-483b77225d8b/resource/fac950c0-00d5-4ec1-a4d3-9cbebf98a305/download/contracts.csv',
    'contracts_schema.json': 'https://open.canada.ca/data/recombinant-published-schema/contracts.json',
    'art-obj-2526-eng.csv': 'https://donnees-data.tpsgc-pwgsc.gc.ca/ba1/art-obj/art-obj-2526-eng.csv',
    'nibs-gsin.csv': 'https://donnees-data.tpsgc-pwgsc.gc.ca/ba2/aev-bas/nibs-gsin.csv',
}
for name, url in FILES.items():
    path = os.path.join(SRC, name)
    if not os.path.exists(path):
        print('downloading', name); urllib.request.urlretrieve(url, path)
COLS = ['reference_number', 'procurement_id', 'vendor_name', 'vendor_postal_code', 'contract_date', 'economic_object_code', 'description_en', 'contract_period_start', 'delivery_date', 'contract_value', 'original_value', 'amendment_value', 'agreement_type_code', 'trade_agreement', 'commodity_type', 'commodity_code', 'country_of_vendor', 'solicitation_procedure', 'limited_tendering_reason', 'indigenous_business', 'former_public_servant', 'contracting_entity', 'standing_offer_number', 'instrument_type', 'number_of_bids', 'award_criteria', 'reporting_period', 'owner_org', 'owner_org_title']
raw = pd.read_csv(os.path.join(SRC, 'contracts.csv'), usecols=COLS, dtype=str, keep_default_na=False, low_memory=False)
# keep well-formed reporting periods (like 2022-2023-Q1) from fiscal 2022-2023 onward; a few malformed rows are dropped
per = raw.reporting_period.str.extract(r'^(\d{4})-(\d{4})-Q[1-4]$')
start = pd.to_numeric(per[0], errors='coerce'); end = pd.to_numeric(per[1], errors='coerce')
keep = start.between(2022, 2030) & (end == start + 1)
recent = raw[keep][COLS].reset_index(drop=True)
recent.to_parquet(os.path.join(SRC, 'recent.parquet'), index=False)
print('recent.parquet rows:', len(recent))
