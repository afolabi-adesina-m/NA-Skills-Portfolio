# Stage 3: flat, pre-joined extracts for Tableau Public
import pandas as pd, numpy as np
D='/workspace/powerbi-kit/data/'; T='/workspace/powerbi-kit/tableau/'
rd=lambda n,**k: pd.read_csv(D+n,keep_default_na=False,na_values=[''],encoding='utf-8-sig',**k)
f=rd('FactContracts.csv',dtype={'ProcurementId':str}); v=rd('DimVendor.csv'); d=rd('DimDate.csv'); dep=rd('DimDepartment.csv')
c=rd('DimCategory.csv',dtype={'EconomicObjectCode':str}); cs=rd('DimCategorySegment.csv'); m=rd('DimProcurementMethod.csv'); ct=rd('DimCommodityType.csv')
x=(f.merge(d[['DateKey','MonthStart','FiscalYearShort']],on='DateKey')
    .merge(v[['VendorKey','MasterVendorName','IsPotentialDuplicate','CountryName','ProvinceName','VendorParetoClass']],on='VendorKey')
    .merge(dep[['DeptKey','DepartmentName']],on='DeptKey')
    .merge(c[['CategoryKey','CategoryGroupKey']],on='CategoryKey')
    .merge(cs[['CategoryGroupKey','CategoryGroup','StandardObject','KraljicSegment','ProcurementTier','SupplyRiskScore','CategoryParetoClass']],on='CategoryGroupKey')
    .merge(m[['MethodKey','ProcurementMethod','CompetitionType','IsCompetitive']],on='MethodKey').merge(ct,on='CommodityTypeCode'))
assert len(x)==len(f)
x['cwb']=((x.IsCompetitive==1)&(x.NumberOfBids.notna())).astype(int)   # same denominator as the Power BI Single-Bid Rate
x['sb']=((x.IsCompetitive==1)&(x.NumberOfBids==1)).astype(int)
x['ContractSize']=np.where(x.ContractValue>=1e9,'C$1B or more','Under C$1B')
x['DuplicateVendorFlag']=np.where(x.IsPotentialDuplicate==1,'Likely duplicate','No duplicate found')
keys=['MonthStart','FiscalYearShort','DepartmentName','CategoryGroup','KraljicSegment','ProcurementTier','SupplyRiskScore','CategoryParetoClass','CommodityType','CompetitionType','IsCompetitive','DuplicateVendorFlag','ContractSize']
g=x.groupby(keys).agg(Spend=('ContractValue','sum'),OriginalValue=('OriginalValue','sum'),AmendmentValue=('AmendmentValue','sum'),
    Contracts=('ContractKey','count'),AmendedContracts=('IsAmended','sum'),CompetitiveWithBidCount=('cwb','sum'),SingleBidContracts=('sb','sum')).reset_index()
for col in ['Spend','OriginalValue','AmendmentValue']: g[col]=g[col].round(2)
g=g.rename(columns={'DepartmentName':'Department','FiscalYearShort':'FiscalYear'})
g.to_csv(T+'contracts_flat.csv',index=False,encoding='utf-8-sig')
# small companion file for the procurement-method visual (field names match contracts_flat, so Tableau filters can apply to both)
pm=x.groupby(['FiscalYearShort','DepartmentName','CommodityType','ProcurementMethod','CompetitionType']).agg(Spend=('ContractValue','sum'),Contracts=('ContractKey','count')).reset_index()
pm['Spend']=pm.Spend.round(2); pm=pm.rename(columns={'DepartmentName':'Department','FiscalYearShort':'FiscalYear'})
assert abs(pm.Spend.sum()-x.ContractValue.sum())<1
pm.to_csv(T+'procurement_methods.csv',index=False,encoding='utf-8-sig')
rd('segment_rules.csv').to_csv(T+'segment_rules.csv',index=False,encoding='utf-8-sig')

# vendor_pareto: one row per suggested master vendor
tot=x.ContractValue.sum()
vg=x.groupby('MasterVendorName')
vp=pd.DataFrame({'Spend':vg.ContractValue.sum(),'Contracts':vg.size(),
  'Departments':vg.DepartmentName.nunique(),
  'TopDepartment':vg.apply(lambda q:q.groupby('DepartmentName').ContractValue.sum().idxmax(),include_groups=False),
  'TopCategoryGroup':vg.apply(lambda q:q.groupby('CategoryGroup').ContractValue.sum().idxmax(),include_groups=False),
  'NonCompetitiveSpend':x[x.IsCompetitive==0].groupby('MasterVendorName').ContractValue.sum()}).fillna({'NonCompetitiveSpend':0})
for fy in ["FY'24","FY'25","FY'26"]:
    vp['Spend_'+fy.replace("'","")]=x[x.FiscalYearShort==fy].groupby('MasterVendorName').ContractValue.sum()
vp=vp.fillna(0)
mv=v.groupby('MasterVendorName').agg(VendorRecords=('VendorKey','count'),RawSpellings=('RawVariantCount','sum'),IsPotentialDuplicate=('IsPotentialDuplicate','max'),
    Country=('CountryName','first'),Province=('ProvinceName','first'))
vp=vp.join(mv)
vp=vp.sort_values('Spend',ascending=False)
vp['VendorRank']=np.arange(1,len(vp)+1)
vp['SpendSharePct']=(vp.Spend/tot).round(8)
vp['CumulativeSpendPct']=(vp.Spend.cumsum()/tot).round(8)
prev=vp.CumulativeSpendPct-vp.SpendSharePct
vp['ParetoClass']=np.where(prev<0.80,'A',np.where(prev<0.95,'B','C'))
chk=v.drop_duplicates('MasterVendorName').set_index('MasterVendorName').VendorParetoClass
assert (vp.ParetoClass==chk.reindex(vp.index)).all(), 'Pareto class mismatch vs DimVendor'
vp=vp.reset_index()
for col in ['Spend','NonCompetitiveSpend','Spend_FY24','Spend_FY25','Spend_FY26']: vp[col]=vp[col].round(2)
vp=vp[['VendorRank','MasterVendorName','Spend','Contracts','SpendSharePct','CumulativeSpendPct','ParetoClass','Spend_FY24','Spend_FY25','Spend_FY26','NonCompetitiveSpend','Departments','TopDepartment','TopCategoryGroup','VendorRecords','RawSpellings','IsPotentialDuplicate','Country','Province']]
vp.to_csv(T+'vendor_pareto.csv',index=False,encoding='utf-8-sig')

cs.to_csv(T+'category_segments.csv',index=False,encoding='utf-8-sig')
rd('dq_rule_summary.csv').to_csv(T+'dq_rule_summary.csv',index=False,encoding='utf-8-sig')
rd('dq_vendor_count_stages.csv').to_csv(T+'dq_vendor_count_stages.csv',index=False,encoding='utf-8-sig')
dup=rd('dq_vendor_duplicates.csv'); dup[dup.FuzzyClusterId>0].to_csv(T+'dq_duplicate_clusters.csv',index=False,encoding='utf-8-sig')
# checks
assert abs(g.Spend.sum()-tot)<1 and g.Contracts.sum()==len(f) and abs(vp.Spend.sum()-tot)<1
print('flat rows',len(g),'vendors',len(vp),'A',(vp.ParetoClass=='A').sum())
