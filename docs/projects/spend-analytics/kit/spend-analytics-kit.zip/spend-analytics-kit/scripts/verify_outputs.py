import pandas as pd, re, glob, os, numpy as np
D='data/'
T={os.path.basename(p)[:-4]:pd.read_csv(p,dtype={'ProcurementId':str},encoding='utf-8-sig',keep_default_na=False,na_values=['']) for p in glob.glob(D+'*.csv')}
assert all(open(p,'rb').read(3)==b'\xef\xbb\xbf' for p in glob.glob(D+'*.csv')+glob.glob('tableau/*.csv')); print('UTF-8 BOM ok on all CSVs')
for n,t in sorted(T.items()): print(f'{n:28s} rows={len(t):>7} cols={t.shape[1]:>3} firstcol={t.columns[0]!r}')
f=T['FactContracts']
for c,d,k in [('DateKey','DimDate','DateKey'),('VendorKey','DimVendor','VendorKey'),('DeptKey','DimDepartment','DeptKey'),('CategoryKey','DimCategory','CategoryKey'),('MethodKey','DimProcurementMethod','MethodKey'),('CommodityTypeCode','DimCommodityType','CommodityTypeCode')]:
    assert T[d][k].is_unique; o=(~f[c].isin(T[d][k])).sum(); assert o==0 and f[c].notna().all(); print('FK ok',c,'->',d)
assert T['VendorNameMap'].VendorKey.isin(T['DimVendor'].VendorKey).all(); print('FK ok VendorNameMap->DimVendor')
assert T['dq_vendor_duplicates'].VendorKey.isin(T['DimVendor'].VendorKey).all()
assert T['DimCategorySegment'].CategoryGroupKey.is_unique and T['DimCategory'].CategoryGroupKey.isin(T['DimCategorySegment'].CategoryGroupKey).all(); print('FK ok DimCategory->DimCategorySegment')
# DAX column refs
dax=open('dax_measures.md').read()
refs=set(re.findall(r"([A-Za-z_]+)\[([A-Za-z0-9_ ]+)\]",dax))
measures=set(re.findall(r"^([A-Za-z0-9 %\(\)\-/]+?) =",dax,re.M))
bad=[]
for t,c in refs:
    if t in T:
        if c not in T[t].columns: bad.append((t,c))
    else: bad.append((t,c))
print('DAX table[column] refs:',len(refs),'missing:',bad)
mrefs=set(re.findall(r"(?<![A-Za-z_\]])\[([^\]]+)\]",dax))-{c for _,c in refs}
print('measure refs not defined:',[m for m in mrefs if m not in {x.strip() for x in measures}])
# also check build guide field refs  Table > Column
bg=open('BUILD_GUIDE.md').read()
for t,c in re.findall(r"(Dim[A-Za-z]+|FactContracts|dq_[a-z_]+|VendorNameMap) > \*\*([A-Za-z]+)\*\*",bg):
    if c not in T[t].columns: print('GUIDE missing',t,c)
# expected values
v=T['DimVendor']; m=T['DimProcurementMethod']; dd=T['DimDate']
x=f.merge(v,on='VendorKey').merge(m,on='MethodKey').merge(dd[['DateKey','FiscalYearShort']],on='DateKey').merge(T['DimCategory'][['CategoryKey','CategoryGroupKey']],on='CategoryKey').merge(T['DimCategorySegment'][['CategoryGroupKey','CategoryGroup','ProcurementTier','KraljicSegment']],on='CategoryGroupKey')
tot=x.ContractValue.sum()
sm=x.groupby('MasterVendorName').ContractValue.sum()
comp=x[x.IsCompetitive==1]; cb=comp[comp.NumberOfBids.notna()]
E={'Total Spend':tot,'Contract Count':len(x),'Avg':tot/len(x),'Median':x.ContractValue.median(),
'Top10 share':sm.nlargest(10).sum()/tot,'HHI':((sm/tot*100)**2).sum(),'NC spend%':x[x.IsCompetitive==0].ContractValue.sum()/tot,
'NC count%':(x.IsCompetitive==0).mean(),'Single bid':(cb.NumberOfBids==1).mean(),'Amend rate':x.IsAmended.mean(),
'Amend growth':x.AmendmentValue.sum()/x.OriginalValue.sum(),'Active vendors':x.VendorKey.nunique(),
'Dup rate':x[x.IsPotentialDuplicate==1].VendorKey.nunique()/x.VendorKey.nunique(),'Spend at risk':x[x.IsPotentialDuplicate==1].ContractValue.sum(),
'Spend at risk %':x[x.IsPotentialDuplicate==1].ContractValue.sum()/tot}
fy=x.groupby('FiscalYearShort').ContractValue.sum(); E["YoY FY'25"]=fy["FY'25"]/fy["FY'24"]-1; E["YoY FY'26"]=fy["FY'26"]/fy["FY'25"]-1
for k,val in x.groupby('CommodityTypeCode').ContractValue.sum().items(): E['Commodity '+str(k)]=val
for k,val in (x.groupby('ProcurementTier').ContractValue.sum()/tot).items(): E['Tier '+k]=val
for k,val in (x.groupby('KraljicSegment').ContractValue.sum()/tot).items(): E['Segment '+k]=val
print(T['DimCategorySegment'].KraljicSegment.value_counts().to_dict())
# Pareto recomputed independently
sv=sm.sort_values(ascending=False); before=(sv.cumsum()-sv)/tot
cls=np.where(before<0.8,'A',np.where(before<0.95,'B','C')); E['Class A vendors']=(cls=='A').sum(); E['Class B vendors']=(cls=='B').sum(); E['Class C vendors']=(cls=='C').sum(); E['Masters with spend']=len(sv)
vc=v[v.VendorParetoClass!='No contracts'].groupby('MasterVendorName').VendorParetoClass.first().reindex(sv.index)
assert (vc.values==cls).all(); print('DimVendor Pareto class matches independent recompute')
sc=x.groupby('CategoryGroup').ContractValue.sum().sort_values(ascending=False); bc=(sc.cumsum()-sc)/tot
E['Category groups']=len(sc); E['Class A categories']=(bc<0.8).sum(); E['Top15 category share']=sc.head(15).sum()/tot
# Tableau totals
tf=pd.read_csv('tableau/contracts_flat.csv',encoding='utf-8-sig'); vp=pd.read_csv('tableau/vendor_pareto.csv',encoding='utf-8-sig',keep_default_na=False,na_values=[''])
assert abs(tf.Spend.sum()-tot)<1 and tf.Contracts.sum()==len(x) and abs(vp.Spend.sum()-tot)<1 and (vp.ParetoClass=='A').sum()==E['Class A vendors']
print('Tableau totals ok', len(tf), len(vp)); E['Tableau dup vendor rate']=vp.loc[vp.IsPotentialDuplicate==1,'VendorRecords'].sum()/vp.VendorRecords.sum()
for p in glob.glob('tableau/*.csv'): assert os.path.getsize(p)<15e6; print(p, os.path.getsize(p))
for k,val in E.items(): print(f'{k:16s} {val:,.4f}')
# no em/en dashes in docs
for p in glob.glob('*.md')+glob.glob('tableau/*.md'):
    s=open(p).read(); print(p,'em/en dashes:',s.count('\u2014')+s.count('\u2013'))
# mockups
from PIL import Image
for n in ['00_all_pages','01_spend_overview','02_spend_by_category','03_vendor_competition','04_category_segmentation','05_pareto','06_supplier_data_quality']:
    im=Image.open(f'mockups/{n}.png'); print('mockup',n,im.size)
    if n!='00_all_pages': assert im.size==(1600,900)
for ref in re.findall(r'\]\((mockups/[^)]+)\)',open('BUILD_GUIDE.md').read()): assert os.path.exists(ref),ref
pmx=pd.read_csv('tableau/procurement_methods.csv',encoding='utf-8-sig'); assert abs(pmx.Spend.sum()-tot)<1 and pmx.Contracts.sum()==len(x); print('procurement_methods totals ok',len(pmx))
# layout tables in BUILD_GUIDE match the mockup layout
import json
L=json.load(open('/workspace/src/mockup_layout.json')); bg=open('BUILD_GUIDE.md').read()
rows=set(tuple(map(int,m)) for m in re.findall(r'\| (\d+) \| (\d+) \| (\d+) \| (\d+) \|\s*$',bg,re.M))
cardx=set(int(m) for m in re.findall(r'\| (\d+) \| [^|]*\|\s*$',bg,re.M))
miss=[]
for p,items in L.items():
    for r0 in items:
        if r0[0].startswith('Visual') and tuple(r0[1:]) not in rows: miss.append((p,r0))
print('BUILD_GUIDE visual positions missing:',miss)
