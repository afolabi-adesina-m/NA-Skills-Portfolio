# Power BI Starter Kit: Canadian Federal Procurement and Supplier Master Data Quality

A portfolio project by Afolabi Adesina that connects procurement spend analysis with supplier master data quality, built on real, openly licensed Government of Canada data.

## Source
- **Dataset**: Proactive Publication - Contracts (resource: "Contracts over $10,000")
- **Publisher**: Treasury Board of Canada Secretariat, via open.canada.ca
- **Dataset page**: https://open.canada.ca/data/en/dataset/d8f85d91-7dec-4fd1-8055-483b77225d8b
- **CSV used**: https://open.canada.ca/data/dataset/d8f85d91-7dec-4fd1-8055-483b77225d8b/resource/fac950c0-00d5-4ec1-a4d3-9cbebf98a305/download/contracts.csv (641,786,551 bytes; resource last modified 6 Oct 2026, 2:54 AM ET)
- **Schema / data dictionary**: https://open.canada.ca/data/recombinant-published-schema/contracts.json
- **Licence**: Open Government Licence - Canada, https://open.canada.ca/en/open-government-licence-canada
- **Attribution**: Contains information licensed under the Open Government Licence - Canada.
- **Downloaded**: 6 October 2026, 1:51 PM ET

Reference lists used for categories and data-quality checks (both Open Government Licence - Canada, published by Public Services and Procurement Canada):
- Government-wide Chart of Accounts 2025-26, object codes: https://donnees-data.tpsgc-pwgsc.gc.ca/ba1/art-obj/art-obj-2526-eng.csv
- GSIN (Goods and Services Identification Number) list: https://donnees-data.tpsgc-pwgsc.gc.ca/ba2/aev-bas/nibs-gsin.csv

The source file is refreshed regularly, so re-running the pipeline later can give slightly different numbers.

## Scope
Original contract awards dated 1 April 2023 to 31 March 2026 (FY'24 to FY'26; FY'24 = April 2023 to March 2024), taken from reporting periods 2022-2023 Q1 onward. Amendment records are rolled up into their contract (latest reported value), so spend is not double counted. Standing offer / supply arrangement agreements (reported at $0) are excluded; call-ups against them are included.

## What is inside
| Path | What it is |
|---|---|
| `BUILD_GUIDE.md` | Click-by-click guide to build the 6-page report in Power BI Desktop (Spend Overview, Spend by Category, Vendor and Competition, Category Segmentation, Pareto, Supplier MDM), with the exact position and size of every card and visual |
| `MOCKUPS.md` | What the finished report looks like, page by page, and which visuals from the earlier PO Spend Analytics report were redone and where |
| `mockups/` | 6 full-page dashboard mockups (1600 x 900), one per report page, plus `00_all_pages.png`; they apply to both Power BI and Tableau |
| `data_model.md` | Star schema, relationships, keys, column dictionary, cleansing, segmentation and Pareto method |
| `dax_measures.md` | 53 DAX measures, copy-paste ready, with plain explanations and expected values |
| `insights.md` | 11 findings with numbers, a portfolio blurb, and the SAP master data connection |
| `powerbi-theme.json` | Navy report theme (View > Themes > Browse for themes) |
| `preview/` | 7 PNG previews: monthly trend, top vendors, vendor clean-up, top categories, Kraljic 2x2, supplier Pareto, category Pareto |
| `data/FactContracts.csv` | One row per contract (179,829) |
| `data/Dim*.csv` | Vendor (with Pareto rank and ABC class), Department, Date (with FY'24 style labels), Category, Category Segment, Procurement Method, Commodity Type |
| `data/DimCategorySegment.csv` | One row per category group (85): spend, supply risk proxies, Kraljic segment, Strategic / Tactical / Operational tier, Pareto class |
| `data/segment_rules.csv` | The 4 segmentation rules in plain words (show this on the segmentation page) |
| `data/VendorNameMap.csv` | Raw vendor spelling to cleaned vendor cross-reference |
| `data/dq_vendor_duplicates.csv` | Near-duplicate clusters and multi-spelling vendors |
| `data/dq_rule_summary.csv` | 21 data-quality rules with failure counts and spend affected |
| `data/dq_vendor_count_stages.csv` | Vendor count before vs after each cleansing stage |
| `data/raw_sample.csv` | 518 random original rows, all columns, for reference |
| `tableau/TABLEAU_GUIDE.md` | Click-by-click guide for Tableau Public desktop (Windows), from connecting the files to publishing |
| `tableau/*.csv` | Pre-joined flat extracts for Tableau: `contracts_flat.csv` (monthly summary with department, category, segment, tier, ABC class, FY label), `vendor_pareto.csv` (one row per master supplier with rank, cumulative %, ABC class), plus category segments, procurement methods, segment rules and data-quality tables |
| `scripts/` | The Python used to build everything (pandas, rapidfuzz, unidecode, matplotlib). Run in order: build_star_schema.py, stage2_segments_pareto.py, stage3_tableau.py, make_preview_charts.py, make_dashboard_mockups.py, verify_outputs.py. Reference copies: input paths point to the original working folder, adjust before re-running |

## Limitations
- Values are as reported by departments. Some contracts report full potential value at award (for example task-authorization contracts), so "contract value" is committed value, not cash paid.
- A contract is identified by department + procurement ID. Where departments reuse or change IDs, a few contracts could be split or merged.
- Contracts awarded before April 2023 but amended during the window are not included.
- Recent contracts have had less time to be amended, so amendment metrics are lower for FY'26.
- Fuzzy clusters are review suggestions with some false positives (for example different harbour authorities with similar names) and miss English/French name pairs.
- Postal codes in the source are only the first 3 characters (FSA), so province is derived from the first letter.
- Category segmentation thresholds (high spend = Pareto class A; high supply risk = score of 25 or more) are analyst-defined assumptions, and the Supply Risk Score uses proxies from the contract data only. Groups with fewer than 30 contracts are flagged LowDataConfidence.
- Category groups use the contract's economic object code; 616 contracts (C$187.7M) have a code that is not in the Chart of Accounts and appear as "Unmapped object code".
- The Tableau `contracts_flat.csv` is summarized by month (not one row per contract) to keep it under 15 MB, so medians cannot be computed from it; supplier-level detail is in `vendor_pareto.csv`.
