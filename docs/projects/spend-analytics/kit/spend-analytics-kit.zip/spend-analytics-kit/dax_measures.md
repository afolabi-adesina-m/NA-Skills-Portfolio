# DAX measures

Copy each block into Power BI as a **New measure** (right-click the `_Measures` table > New measure). Paste the whole block, including the name before the `=` sign, then press Enter.

Tip: create an empty table to hold your measures so they are easy to find. Home > Enter data > name it `_Measures` > Load. After your first measure is in it, delete the default `Column1`.

Every column used below exists in the CSVs in `data/`. The "Expected value" lines show what each measure returns with **no slicers applied**, computed independently in Python from the same files. If your card shows the same number, the model is wired correctly.

Fiscal years use short labels: **FY'24** = April 2023 to March 2024, **FY'25** = April 2024 to March 2025, **FY'26** = April 2025 to March 2026 (column `DimDate[FiscalYearShort]`).

Sections 1 to 5 are the core spend, competition and master data measures. Sections 6 to 8 add category, segmentation and Pareto analysis. Section 9 adds the extra KPI card measures used in the dashboard mockups.

---

## 1. Spend basics

### Total Spend
```DAX
Total Spend = SUM ( FactContracts[ContractValue] )
```
Total value of contracts awarded, using the latest reported value (so it includes amendments). Values already include taxes, as reported by departments, so there is no separate tax column to add. Format: Currency, 0 decimals (display units "Billions" on cards).
Expected value: **$92,564,355,527** (about C$92.6B).

### Contract Count
```DAX
Contract Count = COUNTROWS ( FactContracts )
```
How many contracts. Each row in FactContracts is one contract (amendments are already rolled up into it).
Expected value: **179,829**.

### Avg Contract Value
```DAX
Avg Contract Value = DIVIDE ( [Total Spend], [Contract Count] )
```
Average value per contract. DIVIDE returns blank instead of an error when the count is zero.
Expected value: **$514,735**. A handful of very large defence and shipbuilding contracts pull this up, which is why the next measure matters.

### Median Contract Value
```DAX
Median Contract Value = MEDIAN ( FactContracts[ContractValue] )
```
The "typical" contract. Half of contracts are below this, half above.
Expected value: **$25,942**.

### Goods Spend / Services Spend / Construction Spend
```DAX
Goods Spend = CALCULATE ( [Total Spend], DimCommodityType[CommodityType] = "Goods" )
```
```DAX
Services Spend = CALCULATE ( [Total Spend], DimCommodityType[CommodityType] = "Services" )
```
```DAX
Construction Spend = CALCULATE ( [Total Spend], DimCommodityType[CommodityType] = "Construction" )
```
A split of spend into the three commodity types, good for a row of cards next to Total Spend.
Expected values: Goods **$19,857,296,409** (21.5%), Services **$60,684,999,366** (65.6%), Construction **$12,022,059,752** (13.0%).

### Active Suppliers
```DAX
Active Suppliers = COUNTROWS ( SUMMARIZE ( FactContracts, DimVendor[MasterVendorName] ) )
```
Number of distinct suppliers (grouped by suggested master vendor) with at least one contract in the current filter. Responds to every slicer.
Expected value: **38,370**.

### % of Total Spend
```DAX
% of Total Spend =
DIVIDE ( [Total Spend], CALCULATE ( [Total Spend], ALLSELECTED () ) )
```
Share of the visible total. Put it next to Total Spend in any table or tooltip (by category, department, tier and so on).

---

## 2. Time intelligence (needs DimDate marked as a date table)

### Spend PY (helper)
```DAX
Spend PY =
CALCULATE ( [Total Spend], SAMEPERIODLASTYEAR ( DimDate[Date] ) )
```
Spend for the same period one year earlier. With FY'25 selected, this returns FY'24.

### Spend YoY %
```DAX
Spend YoY % =
VAR CurrentYearSpend = [Total Spend]
VAR PriorYearSpend = [Spend PY]
RETURN
    IF (
        HASONEVALUE ( DimDate[FiscalYearShort] ) && NOT ISBLANK ( PriorYearSpend ),
        DIVIDE ( CurrentYearSpend - PriorYearSpend, PriorYearSpend )
    )
```
Year-over-year change. It only shows a value when one fiscal year is in context (pick a year in the FiscalYearShort slicer, or use FiscalYearShort on an axis or table row). With all years selected it stays blank on purpose. It is also blank for FY'24 because no earlier year is loaded. Format: Percentage, 1 decimal.
Expected values: FY'25 **+70.5%**, FY'26 **-66.9%**. Both swings come from a few multi-billion-dollar awards (see insights.md).

Watch-out: always reference a measure in square brackets, for example `[Total Spend]`. If a measure is named after a year, such as `2024`, then writing `2024` without brackets gives you the number 2024, not the measure.

---

## 3. Concentration and competition

### Top 10 Vendor Share
```DAX
Top 10 Vendor Share =
VAR TopVendors =
    TOPN ( 10, ALLSELECTED ( DimVendor[MasterVendorName] ), [Total Spend] )
RETURN
    DIVIDE (
        CALCULATE ( [Total Spend], TopVendors ),
        CALCULATE ( [Total Spend], ALLSELECTED ( DimVendor ) )
    )
```
Share of spend going to the 10 biggest suppliers, grouped by `MasterVendorName` so a supplier with several spellings counts once. Respects slicers.
Expected value: **49.2%**.

### Vendor HHI
```DAX
Vendor HHI =
VAR TotalSpend = [Total Spend]
RETURN
    SUMX (
        VALUES ( DimVendor[MasterVendorName] ),
        POWER ( DIVIDE ( [Total Spend], TotalSpend ) * 100, 2 )
    )
```
Herfindahl-Hirschman Index: square each supplier's percentage share and add them up. Near 0 = spread across many suppliers, 10,000 = one supplier gets everything. Rough guide: under 1,500 unconcentrated, 1,500 to 2,500 moderate, above 2,500 high. Format: Whole number.
Expected value: **387** government-wide. Inside Fisheries and Oceans Canada it is **3,178**.

### Non-Competitive Spend %
```DAX
Non-Competitive Spend % =
DIVIDE (
    CALCULATE ( [Total Spend], DimProcurementMethod[IsCompetitive] = 0 ),
    [Total Spend]
)
```
Share of spend awarded without a competitive process (Non-Competitive or Advance Contract Award Notice).
Expected value: **18.9%**.

### Non-Competitive Contract %
```DAX
Non-Competitive Contract % =
DIVIDE (
    CALCULATE ( [Contract Count], DimProcurementMethod[IsCompetitive] = 0 ),
    [Contract Count]
)
```
Expected value: **38.1%**.

### Single-Bid Rate (Competitive)
```DAX
Single-Bid Rate (Competitive) =
DIVIDE (
    CALCULATE (
        [Contract Count],
        DimProcurementMethod[IsCompetitive] = 1,
        FactContracts[NumberOfBids] = 1
    ),
    CALCULATE (
        [Contract Count],
        DimProcurementMethod[IsCompetitive] = 1,
        NOT ISBLANK ( FactContracts[NumberOfBids] )
    )
)
```
Of the competitive contracts that reported a bid count, how many got only one bid.
Expected value: **44.9%**.

---

## 4. Contract changes

### Amendment Rate
```DAX
Amendment Rate =
DIVIDE (
    CALCULATE ( [Contract Count], FactContracts[IsAmended] = 1 ),
    [Contract Count]
)
```
Expected value: **11.6%** (lower for FY'26 because newer contracts have had less time to be amended).

### Amendment Value Growth %
```DAX
Amendment Value Growth % =
DIVIDE (
    SUM ( FactContracts[AmendmentValue] ),
    SUM ( FactContracts[OriginalValue] )
)
```
Expected value: **11.1%** (about C$9.2B added on C$83.3B of original awards).

---

## 5. Supplier master data quality

### Active Vendors
```DAX
Active Vendors = DISTINCTCOUNT ( FactContracts[VendorKey] )
```
Distinct cleaned vendor records (before fuzzy clustering) with at least one contract.
Expected value: **40,121**.

### Duplicate Vendor Rate
```DAX
Duplicate Vendor Rate =
DIVIDE (
    CALCULATE ( DISTINCTCOUNT ( FactContracts[VendorKey] ), DimVendor[IsPotentialDuplicate] = 1 ),
    [Active Vendors]
)
```
Share of active vendor records that sit in a near-duplicate cluster (review candidates, not confirmed duplicates).
Expected value: **7.7%**.

### Spend at Risk (Duplicates)
```DAX
Spend at Risk (Duplicates) =
CALCULATE ( [Total Spend], DimVendor[IsPotentialDuplicate] = 1 )
```
Expected value: **$13,891,733,126** (about C$13.9B).

### Spend at Risk %
```DAX
Spend at Risk % = DIVIDE ( [Spend at Risk (Duplicates)], [Total Spend] )
```
Expected value: **15.0%**.

### Vendor Names Raw / Vendors After Cleansing / Vendor Reduction %
```DAX
Vendor Names Raw =
CALCULATE ( MAX ( dq_vendor_count_stages[VendorCount] ), dq_vendor_count_stages[StageOrder] = 1 )
```
```DAX
Vendors After Cleansing =
CALCULATE ( MAX ( dq_vendor_count_stages[VendorCount] ), dq_vendor_count_stages[StageOrder] = 4 )
```
```DAX
Vendor Reduction % = 1 - DIVIDE ( [Vendors After Cleansing], [Vendor Names Raw] )
```
Static before vs after counts (they do not change with slicers).
Expected values: **53,265** raw names, **38,514** after cleansing, **27.7%** reduction.

---

## 6. Categories

Categories come from the government's own spending classification (the Government-wide Chart of Accounts). The readable hierarchy is:
**Standard object** (`DimCategorySegment[StandardObject]`, 26 groups such as "SO 04 Professional and special services") > **Category group** (`DimCategorySegment[CategoryGroup]`, 85 groups such as "Informatics services") > **Object** (`DimCategory[ObjectName]`, 400 codes). Commodity type (Goods / Services / Construction) is a separate slicer.

### Category Count
```DAX
Category Count = COUNTROWS ( SUMMARIZE ( FactContracts, DimCategorySegment[CategoryGroup] ) )
```
Number of category groups with spend in the current filter.
Expected value: **85**.

---

## 7. Segmentation (Kraljic and Strategic / Tactical / Operational)

The segment of each category group is pre-computed in `DimCategorySegment` using documented, analyst-defined rules (see data_model.md). These measures summarize it.

### Strategic Tier Spend % / Tactical Tier Spend % / Operational Tier Spend %
```DAX
Strategic Tier Spend % =
DIVIDE ( CALCULATE ( [Total Spend], DimCategorySegment[ProcurementTier] = "Strategic" ), [Total Spend] )
```
```DAX
Tactical Tier Spend % =
DIVIDE ( CALCULATE ( [Total Spend], DimCategorySegment[ProcurementTier] = "Tactical" ), [Total Spend] )
```
```DAX
Operational Tier Spend % =
DIVIDE ( CALCULATE ( [Total Spend], DimCategorySegment[ProcurementTier] = "Operational" ), [Total Spend] )
```
Expected values: Strategic **27.8%**, Tactical **63.2%**, Operational **8.9%**.

### Category Supply Risk Score
```DAX
Category Supply Risk Score = AVERAGE ( DimCategorySegment[SupplyRiskScore] )
```
The 0 to 100 supply risk score for the category group in context. Use it as the Y axis of the 2x2 scatter, with Category Group in Values (Details). It is a fixed score for the whole period and does not change with slicers.

### Risk Threshold (reference line helper)
```DAX
Risk Threshold = 25
```
The analyst-defined cut-off between low and high supply risk. Handy as a constant line or for conditional formatting.

---

## 8. Pareto (80/20) and ABC class

Class A = the items that together make up the first 80% of spend, B = the next 15%, C = the last 5%. An item is placed by the cumulative share *before* it, so the item that crosses 80% is still A.

### Category Spend Rank
```DAX
Category Spend Rank =
IF (
    NOT ISBLANK ( [Total Spend] ),
    RANKX ( ALLSELECTED ( DimCategorySegment[CategoryGroup] ), [Total Spend], , DESC, Dense )
)
```

### Category Cumulative Spend %
```DAX
Category Cumulative Spend % =
VAR CurrentSpend = [Total Spend]
VAR AllCategories =
    ADDCOLUMNS ( ALLSELECTED ( DimCategorySegment[CategoryGroup] ), "@Spend", [Total Spend] )
VAR RunningSpend = SUMX ( FILTER ( AllCategories, [@Spend] >= CurrentSpend ), [@Spend] )
VAR TotalSpend = SUMX ( AllCategories, [@Spend] )
RETURN
    IF ( NOT ISBLANK ( CurrentSpend ), DIVIDE ( RunningSpend, TotalSpend ) )
```
Running total of spend from the biggest category down to the current one, divided by total spend. This is the line in a Pareto chart.
Expected value: **32.6%** for the top group (Acquisition of aircraft and ships, including parts); it passes 80% at the **10th** group.

### Category Pareto Class
```DAX
Category Pareto Class =
VAR Cum = [Category Cumulative Spend %]
VAR Share =
    DIVIDE ( [Total Spend], CALCULATE ( [Total Spend], ALLSELECTED ( DimCategorySegment[CategoryGroup] ) ) )
VAR ShareBefore = Cum - Share
RETURN
    IF ( NOT ISBLANK ( Cum ), SWITCH ( TRUE (), ShareBefore < 0.80, "A", ShareBefore < 0.95, "B", "C" ) )
```
Expected: **10** groups in A, **13** in B, **62** in C.

### Vendor Spend Rank / Vendor Cumulative Spend % / Vendor Pareto Class (dynamic)
```DAX
Vendor Spend Rank =
IF (
    NOT ISBLANK ( [Total Spend] ),
    RANKX ( ALLSELECTED ( DimVendor[MasterVendorName] ), [Total Spend], , DESC, Dense )
)
```
```DAX
Vendor Cumulative Spend % =
VAR CurrentSpend = [Total Spend]
VAR AllVendors =
    ADDCOLUMNS ( ALLSELECTED ( DimVendor[MasterVendorName] ), "@Spend", [Total Spend] )
VAR RunningSpend = SUMX ( FILTER ( AllVendors, [@Spend] >= CurrentSpend ), [@Spend] )
VAR TotalSpend = SUMX ( AllVendors, [@Spend] )
RETURN
    IF ( NOT ISBLANK ( CurrentSpend ), DIVIDE ( RunningSpend, TotalSpend ) )
```
```DAX
Vendor Pareto Class =
VAR Cum = [Vendor Cumulative Spend %]
VAR Share =
    DIVIDE ( [Total Spend], CALCULATE ( [Total Spend], ALLSELECTED ( DimVendor[MasterVendorName] ) ) )
VAR ShareBefore = Cum - Share
RETURN
    IF ( NOT ISBLANK ( Cum ), SWITCH ( TRUE (), ShareBefore < 0.80, "A", ShareBefore < 0.95, "B", "C" ) )
```
Same pattern as categories, but for suppliers. These respond to slicers (for example the Pareto inside one department). Performance note: with all 38,370 suppliers in one table visual this pattern compares every supplier with every other one and can be slow. For the full government-wide view, use the static measures below; use the dynamic ones after filtering to a department or category.

### Vendor Cumulative % (Static) and the ABC counts
```DAX
Vendor Cumulative % (Static) = MAX ( DimVendor[VendorCumulativeSpendPct] )
```
```DAX
Class A Vendors =
CALCULATE ( DISTINCTCOUNT ( DimVendor[MasterVendorName] ), DimVendor[VendorParetoClass] = "A" )
```
```DAX
Share of Vendors for 80% of Spend =
DIVIDE (
    [Class A Vendors],
    CALCULATE ( DISTINCTCOUNT ( DimVendor[MasterVendorName] ), DimVendor[VendorParetoClass] IN { "A", "B", "C" } )
)
```
```DAX
80% Line = 0.8
```
These use the pre-computed government-wide Pareto columns in DimVendor, so they are fast and do not change with slicers.
Expected values: **244** class A suppliers, which is **0.64%** of 38,370 suppliers.

---

## 9. Extra card measures used in the dashboard mockups

These feed the KPI cards shown in `mockups/`. Expected values are with no slicers applied.

### Spend YoY % Latest FY
```DAX
Spend YoY % Latest FY =
VAR CurrentYearSpend = CALCULATE ( [Total Spend], DimDate[FiscalYearShort] = "FY'26" )
VAR PriorYearSpend = CALCULATE ( [Total Spend], DimDate[FiscalYearShort] = "FY'25" )
RETURN
    DIVIDE ( CurrentYearSpend - PriorYearSpend, PriorYearSpend )
```
Always compares the latest full fiscal year (FY'26, April 2025 to March 2026) with the year before, so the Spend Overview card shows a number even when all years are selected. The Fiscal Year slicer does not change it (the department and commodity slicers still do). When a new fiscal year is added, change the two labels.
Expected value: **-66.9%**.

### Goods Share %, Services Share %, Construction Share %
```DAX
Goods Share % = DIVIDE ( [Goods Spend], [Total Spend] )
```
```DAX
Services Share % = DIVIDE ( [Services Spend], [Total Spend] )
```
```DAX
Construction Share % = DIVIDE ( [Construction Spend], [Total Spend] )
```
Used as the small grey line under the three split cards.
Expected values: **21.5%**, **65.6%**, **13.0%**.

### Top Category Share and Top 15 Category Share
```DAX
Top Category Share =
VAR TopCategory = TOPN ( 1, ALLSELECTED ( DimCategorySegment[CategoryGroup] ), [Total Spend] )
RETURN
    DIVIDE ( CALCULATE ( [Total Spend], TopCategory ), [Total Spend] )
```
```DAX
Top 15 Category Share =
VAR Top15 = TOPN ( 15, ALLSELECTED ( DimCategorySegment[CategoryGroup] ), [Total Spend] )
RETURN
    DIVIDE ( CALCULATE ( [Total Spend], Top15 ), [Total Spend] )
```
TOPN picks the biggest category groups by spend, CALCULATE adds up their spend, and DIVIDE turns it into a share of the total.
Expected values: **32.6%** (Acquisition of aircraft and ships) and **89.3%**.

### Class A Categories
```DAX
Class A Categories =
CALCULATE ( COUNTROWS ( DimCategorySegment ), DimCategorySegment[CategoryParetoClass] = "A" )
```
Number of category groups that together make up the first 80% of spend (government-wide, does not change with slicers).
Expected value: **10** (of 85).

### Class B Vendors and Class C Vendors
```DAX
Class B Vendors =
CALCULATE ( DISTINCTCOUNT ( DimVendor[MasterVendorName] ), DimVendor[VendorParetoClass] = "B" )
```
```DAX
Class C Vendors =
CALCULATE ( DISTINCTCOUNT ( DimVendor[MasterVendorName] ), DimVendor[VendorParetoClass] = "C" )
```
Expected values: **2,283** and **35,843**.

### Suppliers for Half of Spend
```DAX
Suppliers for Half of Spend =
CALCULATE ( DISTINCTCOUNT ( DimVendor[MasterVendorName] ), DimVendor[VendorCumulativeSpendPct] < 0.5 ) + 1
```
Counts the suppliers before the running total reaches 50%, plus the one that crosses it.
Expected value: **11**.

### Low-Confidence Groups
```DAX
Low-Confidence Groups =
CALCULATE ( COUNTROWS ( DimCategorySegment ), DimCategorySegment[LowDataConfidence] = 1 )
```
Category groups with fewer than 30 contracts, whose risk scores are noisy.
Expected value: **22**.

### Names Cut at 35 Characters
```DAX
Names Cut at 35 Characters =
CALCULATE ( SUM ( dq_rule_summary[RecordsFailed] ), dq_rule_summary[RuleId] = "DQ18" )
```
Vendor records whose name is exactly 35 characters long, the fingerprint of a 35-character field limit. Only 791 names are 36 characters long.
Expected value: **7,963**.

---

## Formatting checklist
- Currency measures (Total Spend, Goods/Services/Construction Spend, Spend PY, Avg/Median Contract Value, Spend at Risk): Currency, 0 decimals.
- Percentage measures (anything ending in %, Rate, Share, Cumulative): Percentage, 1 decimal.
- Vendor HHI, ranks, counts, Category Supply Risk Score: Whole number with thousands separator.
